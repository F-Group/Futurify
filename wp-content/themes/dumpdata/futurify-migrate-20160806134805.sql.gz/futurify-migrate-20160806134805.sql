# WordPress MySQL database migration
#
# Generated: Saturday 6. August 2016 13:48 UTC
# Hostname: localhost
# Database: `futurify`
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `lrpmqdj9_alm`
#

DROP TABLE IF EXISTS `lrpmqdj9_alm`;


#
# Table structure of table `lrpmqdj9_alm`
#

CREATE TABLE `lrpmqdj9_alm` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  `repeaterDefault` longtext COLLATE utf8_unicode_ci NOT NULL,
  `repeaterType` text COLLATE utf8_unicode_ci NOT NULL,
  `pluginVersion` text COLLATE utf8_unicode_ci NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `lrpmqdj9_alm`
#
INSERT INTO `lrpmqdj9_alm` ( `id`, `name`, `repeaterDefault`, `repeaterType`, `pluginVersion`) VALUES
(1, 'default', '<div class="col-xs-12 col-sm-4 col-md-4">\n	<a href="<?php the_permalink(); ?>">\n    	<div class="bl-blog-list-item">\n    		<img class="img-responsive" src="<?php the_post_thumbnail_url() ?>" alt="blog-img">\n    		<div class="bl-blog-list-item-des">      		\n                	<?php\n                        $posttags = get_the_tags();\n                         if ($posttags) {\n                         	echo \'<h3>\';\n                            foreach($posttags as $tag) {\n                                echo \'<span>\'. $tag->name . \'</span>\';\n                            }\n                            echo \'</h3>\';\n                         }\n                     ?>                \n        		<h2><?php the_title(); ?></h2>\n        		<p>by  <?php echo get_the_author(); ?> </p>\n    		</div>\n    	</div>\n	</a>\n</div>', 'default', '2.11.1') ;

#
# End of data contents of table `lrpmqdj9_alm`
# --------------------------------------------------------



#
# Delete any existing table `lrpmqdj9_commentmeta`
#

DROP TABLE IF EXISTS `lrpmqdj9_commentmeta`;


#
# Table structure of table `lrpmqdj9_commentmeta`
#

CREATE TABLE `lrpmqdj9_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `lrpmqdj9_commentmeta`
#

#
# End of data contents of table `lrpmqdj9_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `lrpmqdj9_comments`
#

DROP TABLE IF EXISTS `lrpmqdj9_comments`;


#
# Table structure of table `lrpmqdj9_comments`
#

CREATE TABLE `lrpmqdj9_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `lrpmqdj9_comments`
#

#
# End of data contents of table `lrpmqdj9_comments`
# --------------------------------------------------------



#
# Delete any existing table `lrpmqdj9_itsec_lockouts`
#

DROP TABLE IF EXISTS `lrpmqdj9_itsec_lockouts`;


#
# Table structure of table `lrpmqdj9_itsec_lockouts`
#

CREATE TABLE `lrpmqdj9_itsec_lockouts` (
  `lockout_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lockout_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `lockout_start` datetime NOT NULL,
  `lockout_start_gmt` datetime NOT NULL,
  `lockout_expire` datetime NOT NULL,
  `lockout_expire_gmt` datetime NOT NULL,
  `lockout_host` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lockout_user` bigint(20) unsigned DEFAULT NULL,
  `lockout_username` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lockout_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`lockout_id`),
  KEY `lockout_expire_gmt` (`lockout_expire_gmt`),
  KEY `lockout_host` (`lockout_host`),
  KEY `lockout_user` (`lockout_user`),
  KEY `lockout_username` (`lockout_username`),
  KEY `lockout_active` (`lockout_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `lrpmqdj9_itsec_lockouts`
#

#
# End of data contents of table `lrpmqdj9_itsec_lockouts`
# --------------------------------------------------------



#
# Delete any existing table `lrpmqdj9_itsec_log`
#

DROP TABLE IF EXISTS `lrpmqdj9_itsec_log`;


#
# Table structure of table `lrpmqdj9_itsec_log`
#

CREATE TABLE `lrpmqdj9_itsec_log` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `log_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `log_function` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `log_priority` int(2) NOT NULL DEFAULT '1',
  `log_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `log_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `log_host` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `log_username` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `log_user` bigint(20) unsigned DEFAULT NULL,
  `log_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `log_referrer` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `log_data` longtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`log_id`),
  KEY `log_type` (`log_type`),
  KEY `log_date_gmt` (`log_date_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `lrpmqdj9_itsec_log`
#
INSERT INTO `lrpmqdj9_itsec_log` ( `log_id`, `log_type`, `log_function`, `log_priority`, `log_date`, `log_date_gmt`, `log_host`, `log_username`, `log_user`, `log_url`, `log_referrer`, `log_data`) VALUES
(1, 'backup', 'Database Backup Executed', 3, '2016-08-06 04:36:15', '2016-08-06 04:36:15', '', '', 0, '', '', 'a:1:{i:0;a:2:{s:6:"status";s:5:"Error";s:7:"details";s:45:"email to backup recipients could not be sent.";}}') ;

#
# End of data contents of table `lrpmqdj9_itsec_log`
# --------------------------------------------------------



#
# Delete any existing table `lrpmqdj9_itsec_temp`
#

DROP TABLE IF EXISTS `lrpmqdj9_itsec_temp`;


#
# Table structure of table `lrpmqdj9_itsec_temp`
#

CREATE TABLE `lrpmqdj9_itsec_temp` (
  `temp_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `temp_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `temp_date` datetime NOT NULL,
  `temp_date_gmt` datetime NOT NULL,
  `temp_host` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `temp_user` bigint(20) unsigned DEFAULT NULL,
  `temp_username` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`temp_id`),
  KEY `temp_date_gmt` (`temp_date_gmt`),
  KEY `temp_host` (`temp_host`),
  KEY `temp_user` (`temp_user`),
  KEY `temp_username` (`temp_username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `lrpmqdj9_itsec_temp`
#

#
# End of data contents of table `lrpmqdj9_itsec_temp`
# --------------------------------------------------------



#
# Delete any existing table `lrpmqdj9_links`
#

DROP TABLE IF EXISTS `lrpmqdj9_links`;


#
# Table structure of table `lrpmqdj9_links`
#

CREATE TABLE `lrpmqdj9_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `lrpmqdj9_links`
#

#
# End of data contents of table `lrpmqdj9_links`
# --------------------------------------------------------



#
# Delete any existing table `lrpmqdj9_newsletter`
#

DROP TABLE IF EXISTS `lrpmqdj9_newsletter`;


#
# Table structure of table `lrpmqdj9_newsletter`
#

CREATE TABLE `lrpmqdj9_newsletter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL DEFAULT '',
  `name` varchar(100) NOT NULL DEFAULT '',
  `surname` varchar(100) NOT NULL DEFAULT '',
  `sex` char(1) NOT NULL DEFAULT 'n',
  `status` char(1) NOT NULL DEFAULT 'S',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` varchar(50) NOT NULL DEFAULT '',
  `feed` tinyint(4) NOT NULL DEFAULT '0',
  `feed_time` bigint(20) NOT NULL DEFAULT '0',
  `country` varchar(4) NOT NULL DEFAULT '',
  `list_1` tinyint(4) NOT NULL DEFAULT '0',
  `list_2` tinyint(4) NOT NULL DEFAULT '0',
  `list_3` tinyint(4) NOT NULL DEFAULT '0',
  `list_4` tinyint(4) NOT NULL DEFAULT '0',
  `list_5` tinyint(4) NOT NULL DEFAULT '0',
  `list_6` tinyint(4) NOT NULL DEFAULT '0',
  `list_7` tinyint(4) NOT NULL DEFAULT '0',
  `list_8` tinyint(4) NOT NULL DEFAULT '0',
  `list_9` tinyint(4) NOT NULL DEFAULT '0',
  `list_10` tinyint(4) NOT NULL DEFAULT '0',
  `list_11` tinyint(4) NOT NULL DEFAULT '0',
  `list_12` tinyint(4) NOT NULL DEFAULT '0',
  `list_13` tinyint(4) NOT NULL DEFAULT '0',
  `list_14` tinyint(4) NOT NULL DEFAULT '0',
  `list_15` tinyint(4) NOT NULL DEFAULT '0',
  `list_16` tinyint(4) NOT NULL DEFAULT '0',
  `list_17` tinyint(4) NOT NULL DEFAULT '0',
  `list_18` tinyint(4) NOT NULL DEFAULT '0',
  `list_19` tinyint(4) NOT NULL DEFAULT '0',
  `list_20` tinyint(4) NOT NULL DEFAULT '0',
  `profile_1` varchar(255) NOT NULL DEFAULT '',
  `profile_2` varchar(255) NOT NULL DEFAULT '',
  `profile_3` varchar(255) NOT NULL DEFAULT '',
  `profile_4` varchar(255) NOT NULL DEFAULT '',
  `profile_5` varchar(255) NOT NULL DEFAULT '',
  `profile_6` varchar(255) NOT NULL DEFAULT '',
  `profile_7` varchar(255) NOT NULL DEFAULT '',
  `profile_8` varchar(255) NOT NULL DEFAULT '',
  `profile_9` varchar(255) NOT NULL DEFAULT '',
  `profile_10` varchar(255) NOT NULL DEFAULT '',
  `profile_11` varchar(255) NOT NULL DEFAULT '',
  `profile_12` varchar(255) NOT NULL DEFAULT '',
  `profile_13` varchar(255) NOT NULL DEFAULT '',
  `profile_14` varchar(255) NOT NULL DEFAULT '',
  `profile_15` varchar(255) NOT NULL DEFAULT '',
  `profile_16` varchar(255) NOT NULL DEFAULT '',
  `profile_17` varchar(255) NOT NULL DEFAULT '',
  `profile_18` varchar(255) NOT NULL DEFAULT '',
  `profile_19` varchar(255) NOT NULL DEFAULT '',
  `profile_20` varchar(255) NOT NULL DEFAULT '',
  `referrer` varchar(50) NOT NULL DEFAULT '',
  `http_referer` varchar(255) NOT NULL DEFAULT '',
  `wp_user_id` int(11) NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `test` tinyint(4) NOT NULL DEFAULT '0',
  `flow` tinyint(4) NOT NULL DEFAULT '0',
  `unsub_email_id` int(11) NOT NULL DEFAULT '0',
  `unsub_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


#
# Data contents of table `lrpmqdj9_newsletter`
#
INSERT INTO `lrpmqdj9_newsletter` ( `id`, `email`, `name`, `surname`, `sex`, `status`, `created`, `token`, `feed`, `feed_time`, `country`, `list_1`, `list_2`, `list_3`, `list_4`, `list_5`, `list_6`, `list_7`, `list_8`, `list_9`, `list_10`, `list_11`, `list_12`, `list_13`, `list_14`, `list_15`, `list_16`, `list_17`, `list_18`, `list_19`, `list_20`, `profile_1`, `profile_2`, `profile_3`, `profile_4`, `profile_5`, `profile_6`, `profile_7`, `profile_8`, `profile_9`, `profile_10`, `profile_11`, `profile_12`, `profile_13`, `profile_14`, `profile_15`, `profile_16`, `profile_17`, `profile_18`, `profile_19`, `profile_20`, `referrer`, `http_referer`, `wp_user_id`, `ip`, `test`, `flow`, `unsub_email_id`, `unsub_time`) VALUES
(1, 'duytan1008@gmail.com', '', '', 'n', 'S', '2016-08-06 18:56:47', 'dedacf1615', 0, 0, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'widget', 'http://futurify.nguyenbui.name.vn/', 0, '::1', 0, 0, 0, 0) ;

#
# End of data contents of table `lrpmqdj9_newsletter`
# --------------------------------------------------------



#
# Delete any existing table `lrpmqdj9_newsletter_emails`
#

DROP TABLE IF EXISTS `lrpmqdj9_newsletter_emails`;


#
# Table structure of table `lrpmqdj9_newsletter_emails`
#

CREATE TABLE `lrpmqdj9_newsletter_emails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `message` longtext COLLATE utf8_unicode_ci,
  `message_text` longtext COLLATE utf8_unicode_ci,
  `subject` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `type` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('new','sending','sent','paused') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'new',
  `total` int(11) NOT NULL DEFAULT '0',
  `last_id` int(11) NOT NULL DEFAULT '0',
  `sent` int(11) NOT NULL DEFAULT '0',
  `send_on` int(11) NOT NULL DEFAULT '0',
  `track` tinyint(4) NOT NULL DEFAULT '0',
  `editor` tinyint(4) NOT NULL DEFAULT '0',
  `sex` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `query` longtext COLLATE utf8_unicode_ci,
  `preferences` longtext COLLATE utf8_unicode_ci,
  `options` longtext COLLATE utf8_unicode_ci,
  `token` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `private` tinyint(1) NOT NULL DEFAULT '0',
  `open_count` int(10) unsigned NOT NULL DEFAULT '0',
  `click_count` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `lrpmqdj9_newsletter_emails`
#

#
# End of data contents of table `lrpmqdj9_newsletter_emails`
# --------------------------------------------------------



#
# Delete any existing table `lrpmqdj9_newsletter_sent`
#

DROP TABLE IF EXISTS `lrpmqdj9_newsletter_sent`;


#
# Table structure of table `lrpmqdj9_newsletter_sent`
#

CREATE TABLE `lrpmqdj9_newsletter_sent` (
  `email_id` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `open` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  `error` varchar(100) NOT NULL DEFAULT '',
  `ip` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`email_id`,`user_id`),
  KEY `user_id` (`user_id`),
  KEY `email_id` (`email_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


#
# Data contents of table `lrpmqdj9_newsletter_sent`
#

#
# End of data contents of table `lrpmqdj9_newsletter_sent`
# --------------------------------------------------------



#
# Delete any existing table `lrpmqdj9_newsletter_stats`
#

DROP TABLE IF EXISTS `lrpmqdj9_newsletter_stats`;


#
# Table structure of table `lrpmqdj9_newsletter_stats`
#

CREATE TABLE `lrpmqdj9_newsletter_stats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `email_id` int(11) NOT NULL DEFAULT '0',
  `link_id` int(11) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `anchor` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ip` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `country` varchar(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `email_id` (`email_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `lrpmqdj9_newsletter_stats`
#

#
# End of data contents of table `lrpmqdj9_newsletter_stats`
# --------------------------------------------------------



#
# Delete any existing table `lrpmqdj9_options`
#

DROP TABLE IF EXISTS `lrpmqdj9_options`;


#
# Table structure of table `lrpmqdj9_options`
#

CREATE TABLE `lrpmqdj9_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=1700 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `lrpmqdj9_options`
#
INSERT INTO `lrpmqdj9_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://futurify.nguyenbui.name.vn', 'yes'),
(2, 'home', 'http://futurify.nguyenbui.name.vn', 'yes'),
(3, 'blogname', 'Futurify', 'yes'),
(4, 'blogdescription', 'Just another WordPress site', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'duytan1008@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/index.php/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:204:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:57:"index.php/category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:52:"index.php/category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:33:"index.php/category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:45:"index.php/category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:27:"index.php/category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:54:"index.php/tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:49:"index.php/tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:30:"index.php/tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:42:"index.php/tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:24:"index.php/tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:55:"index.php/type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:50:"index.php/type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:31:"index.php/type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:43:"index.php/type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:25:"index.php/type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:45:"index.php/project/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:55:"index.php/project/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:75:"index.php/project/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:70:"index.php/project/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:70:"index.php/project/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:51:"index.php/project/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:34:"index.php/project/([^/]+)/embed/?$";s:40:"index.php?project=$matches[1]&embed=true";s:38:"index.php/project/([^/]+)/trackback/?$";s:34:"index.php?project=$matches[1]&tb=1";s:46:"index.php/project/([^/]+)/page/?([0-9]{1,})/?$";s:47:"index.php?project=$matches[1]&paged=$matches[2]";s:53:"index.php/project/([^/]+)/comment-page-([0-9]{1,})/?$";s:47:"index.php?project=$matches[1]&cpage=$matches[2]";s:42:"index.php/project/([^/]+)(?:/([0-9]+))?/?$";s:46:"index.php?project=$matches[1]&page=$matches[2]";s:34:"index.php/project/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:44:"index.php/project/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:64:"index.php/project/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"index.php/project/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"index.php/project/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:40:"index.php/project/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:44:"index.php/member/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:54:"index.php/member/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:74:"index.php/member/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:69:"index.php/member/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:69:"index.php/member/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:50:"index.php/member/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:33:"index.php/member/([^/]+)/embed/?$";s:39:"index.php?member=$matches[1]&embed=true";s:37:"index.php/member/([^/]+)/trackback/?$";s:33:"index.php?member=$matches[1]&tb=1";s:45:"index.php/member/([^/]+)/page/?([0-9]{1,})/?$";s:46:"index.php?member=$matches[1]&paged=$matches[2]";s:52:"index.php/member/([^/]+)/comment-page-([0-9]{1,})/?$";s:46:"index.php?member=$matches[1]&cpage=$matches[2]";s:41:"index.php/member/([^/]+)(?:/([0-9]+))?/?$";s:45:"index.php?member=$matches[1]&page=$matches[2]";s:33:"index.php/member/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:43:"index.php/member/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:63:"index.php/member/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"index.php/member/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"index.php/member/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:39:"index.php/member/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:48:"index.php/home-video/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:58:"index.php/home-video/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:78:"index.php/home-video/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:73:"index.php/home-video/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:73:"index.php/home-video/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:54:"index.php/home-video/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:37:"index.php/home-video/([^/]+)/embed/?$";s:43:"index.php?home-video=$matches[1]&embed=true";s:41:"index.php/home-video/([^/]+)/trackback/?$";s:37:"index.php?home-video=$matches[1]&tb=1";s:49:"index.php/home-video/([^/]+)/page/?([0-9]{1,})/?$";s:50:"index.php?home-video=$matches[1]&paged=$matches[2]";s:56:"index.php/home-video/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?home-video=$matches[1]&cpage=$matches[2]";s:45:"index.php/home-video/([^/]+)(?:/([0-9]+))?/?$";s:49:"index.php?home-video=$matches[1]&page=$matches[2]";s:37:"index.php/home-video/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:47:"index.php/home-video/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:67:"index.php/home-video/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"index.php/home-video/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"index.php/home-video/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:43:"index.php/home-video/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:43:"index.php/staff/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:53:"index.php/staff/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:73:"index.php/staff/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:68:"index.php/staff/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:68:"index.php/staff/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:49:"index.php/staff/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:32:"index.php/staff/([^/]+)/embed/?$";s:38:"index.php?staff=$matches[1]&embed=true";s:36:"index.php/staff/([^/]+)/trackback/?$";s:32:"index.php?staff=$matches[1]&tb=1";s:44:"index.php/staff/([^/]+)/page/?([0-9]{1,})/?$";s:45:"index.php?staff=$matches[1]&paged=$matches[2]";s:51:"index.php/staff/([^/]+)/comment-page-([0-9]{1,})/?$";s:45:"index.php?staff=$matches[1]&cpage=$matches[2]";s:40:"index.php/staff/([^/]+)(?:/([0-9]+))?/?$";s:44:"index.php?staff=$matches[1]&page=$matches[2]";s:32:"index.php/staff/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:42:"index.php/staff/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:62:"index.php/staff/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:57:"index.php/staff/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:57:"index.php/staff/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:38:"index.php/staff/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:41:"index.php/mvp/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:51:"index.php/mvp/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:71:"index.php/mvp/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:66:"index.php/mvp/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:66:"index.php/mvp/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:47:"index.php/mvp/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:30:"index.php/mvp/([^/]+)/embed/?$";s:36:"index.php?mvp=$matches[1]&embed=true";s:34:"index.php/mvp/([^/]+)/trackback/?$";s:30:"index.php?mvp=$matches[1]&tb=1";s:42:"index.php/mvp/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?mvp=$matches[1]&paged=$matches[2]";s:49:"index.php/mvp/([^/]+)/comment-page-([0-9]{1,})/?$";s:43:"index.php?mvp=$matches[1]&cpage=$matches[2]";s:38:"index.php/mvp/([^/]+)(?:/([0-9]+))?/?$";s:42:"index.php?mvp=$matches[1]&page=$matches[2]";s:30:"index.php/mvp/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:40:"index.php/mvp/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:60:"index.php/mvp/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:55:"index.php/mvp/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:55:"index.php/mvp/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:36:"index.php/mvp/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:44:"index.php/career/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:54:"index.php/career/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:74:"index.php/career/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:69:"index.php/career/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:69:"index.php/career/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:50:"index.php/career/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:33:"index.php/career/([^/]+)/embed/?$";s:39:"index.php?career=$matches[1]&embed=true";s:37:"index.php/career/([^/]+)/trackback/?$";s:33:"index.php?career=$matches[1]&tb=1";s:45:"index.php/career/([^/]+)/page/?([0-9]{1,})/?$";s:46:"index.php?career=$matches[1]&paged=$matches[2]";s:52:"index.php/career/([^/]+)/comment-page-([0-9]{1,})/?$";s:46:"index.php?career=$matches[1]&cpage=$matches[2]";s:41:"index.php/career/([^/]+)(?:/([0-9]+))?/?$";s:45:"index.php?career=$matches[1]&page=$matches[2]";s:33:"index.php/career/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:43:"index.php/career/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:63:"index.php/career/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"index.php/career/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"index.php/career/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:39:"index.php/career/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:50:"index.php/vc_grid_item/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:60:"index.php/vc_grid_item/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:80:"index.php/vc_grid_item/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:75:"index.php/vc_grid_item/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:75:"index.php/vc_grid_item/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:56:"index.php/vc_grid_item/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:39:"index.php/vc_grid_item/([^/]+)/embed/?$";s:45:"index.php?vc_grid_item=$matches[1]&embed=true";s:43:"index.php/vc_grid_item/([^/]+)/trackback/?$";s:39:"index.php?vc_grid_item=$matches[1]&tb=1";s:51:"index.php/vc_grid_item/([^/]+)/page/?([0-9]{1,})/?$";s:52:"index.php?vc_grid_item=$matches[1]&paged=$matches[2]";s:58:"index.php/vc_grid_item/([^/]+)/comment-page-([0-9]{1,})/?$";s:52:"index.php?vc_grid_item=$matches[1]&cpage=$matches[2]";s:47:"index.php/vc_grid_item/([^/]+)(?:/([0-9]+))?/?$";s:51:"index.php?vc_grid_item=$matches[1]&page=$matches[2]";s:39:"index.php/vc_grid_item/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:49:"index.php/vc_grid_item/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:69:"index.php/vc_grid_item/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:64:"index.php/vc_grid_item/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:64:"index.php/vc_grid_item/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:45:"index.php/vc_grid_item/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:42:"index.php/feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:37:"index.php/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:18:"index.php/embed/?$";s:21:"index.php?&embed=true";s:30:"index.php/page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:37:"index.php/comment-page-([0-9]{1,})/?$";s:39:"index.php?&page_id=64&cpage=$matches[1]";s:51:"index.php/comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:46:"index.php/comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:27:"index.php/comments/embed/?$";s:21:"index.php?&embed=true";s:54:"index.php/search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:49:"index.php/search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:30:"index.php/search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:42:"index.php/search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:24:"index.php/search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:57:"index.php/author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:52:"index.php/author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:33:"index.php/author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:45:"index.php/author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:27:"index.php/author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:79:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:74:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:55:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:67:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:49:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:66:"index.php/([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:61:"index.php/([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:42:"index.php/([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:54:"index.php/([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:36:"index.php/([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:53:"index.php/([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:48:"index.php/([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:29:"index.php/([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:41:"index.php/([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:23:"index.php/([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:37:"index.php/.?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:47:"index.php/.?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:67:"index.php/.?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"index.php/.?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"index.php/.?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:43:"index.php/.?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:26:"index.php/(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:30:"index.php/(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:50:"index.php/(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:45:"index.php/(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:38:"index.php/(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:45:"index.php/(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:34:"index.php/(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:37:"index.php/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:47:"index.php/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:67:"index.php/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"index.php/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"index.php/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:43:"index.php/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:26:"index.php/([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:30:"index.php/([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:50:"index.php/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:45:"index.php/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:38:"index.php/([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:45:"index.php/([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:34:"index.php/([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:26:"index.php/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:36:"index.php/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:56:"index.php/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:51:"index.php/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:51:"index.php/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:32:"index.php/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:21:{i:0;s:31:"acf-accordion/acf-accordion.php";i:1;s:19:"acf-cf7/acf-cf7.php";i:2;s:33:"addthis/addthis_social_widget.php";i:3;s:60:"advanced-custom-fields-link-picker-field/acf-link_picker.php";i:4;s:30:"advanced-custom-fields/acf.php";i:5;s:33:"ajax-load-more/ajax-load-more.php";i:6;s:41:"better-wp-security/better-wp-security.php";i:7;s:53:"contact-form-7-html-editor/contact-form-7-tinymce.php";i:8;s:36:"contact-form-7/wp-contact-form-7.php";i:9;s:43:"custom-post-type-ui/custom-post-type-ui.php";i:10;s:41:"easy-theme-options/easy-theme-options.php";i:11;s:62:"featured-image-admin-thumb-fiat/featured-image-admin-thumb.php";i:12;s:65:"html-editor-syntax-highlighter/html-editor-syntax-highlighter.php";i:13;s:27:"js_composer/js_composer.php";i:14;s:21:"newsletter/plugin.php";i:15;s:37:"post-types-order/post-types-order.php";i:16;s:37:"tinymce-advanced/tinymce-advanced.php";i:17;s:39:"tinymce-templates/tinymce-templates.php";i:18;s:61:"visual-editor-custom-buttons/visual-editor-custom-buttons.php";i:19;s:41:"wordpress-importer/wordpress-importer.php";i:20;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', 'a:4:{i:0;s:96:"/www/public_html/futurify/wp-content/plugins/advanced-custom-field-repeater-collapser/readme.txt";i:1;s:112:"/www/public_html/futurify/wp-content/plugins/advanced-custom-field-repeater-collapser/acf_repeater_collapser.php";i:2;s:62:"/www/public_html/futurify/wp-content/themes/futurity/style.css";i:3;s:0:"";}', 'no'),
(40, 'template', 'futurity', 'yes'),
(41, 'stylesheet', 'futurity', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '36686', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '1', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:0:{}', 'yes'),
(80, 'widget_rss', 'a:0:{}', 'yes'),
(81, 'uninstall_plugins', 'a:1:{s:41:"better-wp-security/better-wp-security.php";a:2:{i:0;s:10:"ITSEC_Core";i:1;s:12:"on_uninstall";}}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '64', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'initial_db_version', '36686', 'yes'),
(92, 'lrpmqdj9_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(93, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(94, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'sidebars_widgets', 'a:4:{s:19:"wp_inactive_widgets";a:0:{}s:12:"main-sidebar";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:15:"contact-sidebar";a:1:{i:0;s:18:"newsletterwidget-2";}s:13:"array_version";i:3;}', 'yes'),
(99, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(100, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ;
INSERT INTO `lrpmqdj9_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(102, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'cron', 'a:6:{i:1470491490;a:1:{s:10:"newsletter";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"newsletter";s:4:"args";a:0:{}s:8:"interval";i:300;}}}i:1470496447;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1470504970;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1470505015;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1470544574;a:2:{s:16:"itsec_purge_logs";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:20:"itsec_purge_lockouts";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(115, 'can_compress_scripts', '1', 'yes'),
(133, 'theme_mods_twentysixteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1468777075;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(134, 'current_theme', 'Futurify', 'yes'),
(135, 'theme_mods_futurity', 'a:2:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:7:"primary";i:2;}}', 'yes'),
(136, 'theme_switched', '', 'yes'),
(137, 'recently_activated', 'a:5:{s:25:"add-to-any/add-to-any.php";i:1470457469;s:29:"tinymce-font/TinyMCE Font.php";i:1470240650;s:29:"loading-page/loading-page.php";i:1470240226;s:56:"acf-repeater-editor-accordion/acf-repeater-accordion.php";i:1469942782;s:67:"advanced-custom-field-repeater-collapser/acf_repeater_collapser.php";i:1469942774;}', 'yes'),
(138, 'wpcf7', 'a:2:{s:7:"version";s:5:"4.4.2";s:13:"bulk_validate";a:4:{s:9:"timestamp";i:1468777098;s:7:"version";s:5:"4.4.2";s:11:"count_valid";i:1;s:13:"count_invalid";i:0;}}', 'yes'),
(139, 'widget_akismet_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(140, 'acf_version', '4.4.8', 'yes'),
(164, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(185, 'alm_version', '2.11.1', 'yes'),
(189, 'cptui_post_types', 'a:6:{s:7:"project";a:27:{s:4:"name";s:7:"project";s:5:"label";s:8:"Projects";s:14:"singular_label";s:7:"Project";s:11:"description";s:0:"";s:6:"public";s:4:"true";s:7:"show_ui";s:4:"true";s:17:"show_in_nav_menus";s:4:"true";s:12:"show_in_rest";s:5:"false";s:9:"rest_base";s:0:"";s:11:"has_archive";s:5:"false";s:18:"has_archive_string";s:0:"";s:19:"exclude_from_search";s:5:"false";s:15:"capability_type";s:4:"post";s:12:"hierarchical";s:5:"false";s:7:"rewrite";s:4:"true";s:12:"rewrite_slug";s:0:"";s:17:"rewrite_withfront";s:4:"true";s:9:"query_var";s:4:"true";s:14:"query_var_slug";s:0:"";s:13:"menu_position";s:1:"5";s:12:"show_in_menu";s:4:"true";s:19:"show_in_menu_string";s:0:"";s:9:"menu_icon";s:0:"";s:8:"supports";a:3:{i:0;s:5:"title";i:1;s:6:"editor";i:2;s:9:"thumbnail";}s:10:"taxonomies";a:1:{i:0;s:8:"post_tag";}s:6:"labels";a:21:{s:9:"menu_name";s:0:"";s:9:"all_items";s:0:"";s:7:"add_new";s:0:"";s:12:"add_new_item";s:0:"";s:9:"edit_item";s:0:"";s:8:"new_item";s:0:"";s:9:"view_item";s:0:"";s:12:"search_items";s:0:"";s:9:"not_found";s:0:"";s:18:"not_found_in_trash";s:0:"";s:6:"parent";s:0:"";s:14:"featured_image";s:0:"";s:18:"set_featured_image";s:0:"";s:21:"remove_featured_image";s:0:"";s:18:"use_featured_image";s:0:"";s:8:"archives";s:0:"";s:16:"insert_into_item";s:0:"";s:21:"uploaded_to_this_item";s:0:"";s:17:"filter_items_list";s:0:"";s:21:"items_list_navigation";s:0:"";s:10:"items_list";s:0:"";}s:15:"custom_supports";s:0:"";}s:6:"member";a:27:{s:4:"name";s:6:"member";s:5:"label";s:7:"Members";s:14:"singular_label";s:6:"Member";s:11:"description";s:0:"";s:6:"public";s:5:"false";s:7:"show_ui";s:4:"true";s:17:"show_in_nav_menus";s:4:"true";s:12:"show_in_rest";s:5:"false";s:9:"rest_base";s:0:"";s:11:"has_archive";s:5:"false";s:18:"has_archive_string";s:0:"";s:19:"exclude_from_search";s:5:"false";s:15:"capability_type";s:4:"post";s:12:"hierarchical";s:5:"false";s:7:"rewrite";s:4:"true";s:12:"rewrite_slug";s:0:"";s:17:"rewrite_withfront";s:4:"true";s:9:"query_var";s:4:"true";s:14:"query_var_slug";s:0:"";s:13:"menu_position";s:0:"";s:12:"show_in_menu";s:4:"true";s:19:"show_in_menu_string";s:0:"";s:9:"menu_icon";s:0:"";s:8:"supports";a:3:{i:0;s:5:"title";i:1;s:6:"editor";i:2;s:9:"thumbnail";}s:10:"taxonomies";a:0:{}s:6:"labels";a:21:{s:9:"menu_name";s:0:"";s:9:"all_items";s:0:"";s:7:"add_new";s:0:"";s:12:"add_new_item";s:0:"";s:9:"edit_item";s:0:"";s:8:"new_item";s:0:"";s:9:"view_item";s:0:"";s:12:"search_items";s:0:"";s:9:"not_found";s:0:"";s:18:"not_found_in_trash";s:0:"";s:6:"parent";s:0:"";s:14:"featured_image";s:0:"";s:18:"set_featured_image";s:0:"";s:21:"remove_featured_image";s:0:"";s:18:"use_featured_image";s:0:"";s:8:"archives";s:0:"";s:16:"insert_into_item";s:0:"";s:21:"uploaded_to_this_item";s:0:"";s:17:"filter_items_list";s:0:"";s:21:"items_list_navigation";s:0:"";s:10:"items_list";s:0:"";}s:15:"custom_supports";s:0:"";}s:10:"home-video";a:27:{s:4:"name";s:10:"home-video";s:5:"label";s:11:"Home Videos";s:14:"singular_label";s:10:"Home Video";s:11:"description";s:0:"";s:6:"public";s:5:"false";s:7:"show_ui";s:4:"true";s:17:"show_in_nav_menus";s:4:"true";s:12:"show_in_rest";s:5:"false";s:9:"rest_base";s:0:"";s:11:"has_archive";s:5:"false";s:18:"has_archive_string";s:0:"";s:19:"exclude_from_search";s:5:"false";s:15:"capability_type";s:4:"post";s:12:"hierarchical";s:5:"false";s:7:"rewrite";s:4:"true";s:12:"rewrite_slug";s:0:"";s:17:"rewrite_withfront";s:4:"true";s:9:"query_var";s:4:"true";s:14:"query_var_slug";s:0:"";s:13:"menu_position";s:0:"";s:12:"show_in_menu";s:4:"true";s:19:"show_in_menu_string";s:0:"";s:9:"menu_icon";s:0:"";s:8:"supports";a:3:{i:0;s:5:"title";i:1;s:6:"editor";i:2;s:9:"thumbnail";}s:10:"taxonomies";a:0:{}s:6:"labels";a:21:{s:9:"menu_name";s:0:"";s:9:"all_items";s:0:"";s:7:"add_new";s:0:"";s:12:"add_new_item";s:0:"";s:9:"edit_item";s:0:"";s:8:"new_item";s:0:"";s:9:"view_item";s:0:"";s:12:"search_items";s:0:"";s:9:"not_found";s:0:"";s:18:"not_found_in_trash";s:0:"";s:6:"parent";s:0:"";s:14:"featured_image";s:0:"";s:18:"set_featured_image";s:0:"";s:21:"remove_featured_image";s:0:"";s:18:"use_featured_image";s:0:"";s:8:"archives";s:0:"";s:16:"insert_into_item";s:0:"";s:21:"uploaded_to_this_item";s:0:"";s:17:"filter_items_list";s:0:"";s:21:"items_list_navigation";s:0:"";s:10:"items_list";s:0:"";}s:15:"custom_supports";s:0:"";}s:5:"staff";a:27:{s:4:"name";s:5:"staff";s:5:"label";s:8:"Staffing";s:14:"singular_label";s:8:"Staffing";s:11:"description";s:0:"";s:6:"public";s:5:"false";s:7:"show_ui";s:4:"true";s:17:"show_in_nav_menus";s:4:"true";s:12:"show_in_rest";s:5:"false";s:9:"rest_base";s:0:"";s:11:"has_archive";s:5:"false";s:18:"has_archive_string";s:0:"";s:19:"exclude_from_search";s:5:"false";s:15:"capability_type";s:4:"post";s:12:"hierarchical";s:5:"false";s:7:"rewrite";s:4:"true";s:12:"rewrite_slug";s:0:"";s:17:"rewrite_withfront";s:4:"true";s:9:"query_var";s:4:"true";s:14:"query_var_slug";s:0:"";s:13:"menu_position";s:0:"";s:12:"show_in_menu";s:4:"true";s:19:"show_in_menu_string";s:0:"";s:9:"menu_icon";s:0:"";s:8:"supports";a:3:{i:0;s:5:"title";i:1;s:6:"editor";i:2;s:9:"thumbnail";}s:10:"taxonomies";a:0:{}s:6:"labels";a:21:{s:9:"menu_name";s:0:"";s:9:"all_items";s:0:"";s:7:"add_new";s:0:"";s:12:"add_new_item";s:0:"";s:9:"edit_item";s:0:"";s:8:"new_item";s:0:"";s:9:"view_item";s:0:"";s:12:"search_items";s:0:"";s:9:"not_found";s:0:"";s:18:"not_found_in_trash";s:0:"";s:6:"parent";s:0:"";s:14:"featured_image";s:0:"";s:18:"set_featured_image";s:0:"";s:21:"remove_featured_image";s:0:"";s:18:"use_featured_image";s:0:"";s:8:"archives";s:0:"";s:16:"insert_into_item";s:0:"";s:21:"uploaded_to_this_item";s:0:"";s:17:"filter_items_list";s:0:"";s:21:"items_list_navigation";s:0:"";s:10:"items_list";s:0:"";}s:15:"custom_supports";s:0:"";}s:3:"mvp";a:27:{s:4:"name";s:3:"mvp";s:5:"label";s:3:"MVP";s:14:"singular_label";s:3:"MVP";s:11:"description";s:0:"";s:6:"public";s:4:"true";s:7:"show_ui";s:4:"true";s:17:"show_in_nav_menus";s:4:"true";s:12:"show_in_rest";s:5:"false";s:9:"rest_base";s:0:"";s:11:"has_archive";s:5:"false";s:18:"has_archive_string";s:0:"";s:19:"exclude_from_search";s:5:"false";s:15:"capability_type";s:4:"post";s:12:"hierarchical";s:5:"false";s:7:"rewrite";s:4:"true";s:12:"rewrite_slug";s:0:"";s:17:"rewrite_withfront";s:4:"true";s:9:"query_var";s:4:"true";s:14:"query_var_slug";s:0:"";s:13:"menu_position";s:0:"";s:12:"show_in_menu";s:4:"true";s:19:"show_in_menu_string";s:0:"";s:9:"menu_icon";s:0:"";s:8:"supports";a:3:{i:0;s:5:"title";i:1;s:6:"editor";i:2;s:9:"thumbnail";}s:10:"taxonomies";a:0:{}s:6:"labels";a:21:{s:9:"menu_name";s:0:"";s:9:"all_items";s:0:"";s:7:"add_new";s:0:"";s:12:"add_new_item";s:0:"";s:9:"edit_item";s:0:"";s:8:"new_item";s:0:"";s:9:"view_item";s:0:"";s:12:"search_items";s:0:"";s:9:"not_found";s:0:"";s:18:"not_found_in_trash";s:0:"";s:6:"parent";s:0:"";s:14:"featured_image";s:0:"";s:18:"set_featured_image";s:0:"";s:21:"remove_featured_image";s:0:"";s:18:"use_featured_image";s:0:"";s:8:"archives";s:0:"";s:16:"insert_into_item";s:0:"";s:21:"uploaded_to_this_item";s:0:"";s:17:"filter_items_list";s:0:"";s:21:"items_list_navigation";s:0:"";s:10:"items_list";s:0:"";}s:15:"custom_supports";s:0:"";}s:6:"career";a:27:{s:4:"name";s:6:"career";s:5:"label";s:6:"Career";s:14:"singular_label";s:6:"Career";s:11:"description";s:0:"";s:6:"public";s:4:"true";s:7:"show_ui";s:4:"true";s:17:"show_in_nav_menus";s:4:"true";s:12:"show_in_rest";s:5:"false";s:9:"rest_base";s:0:"";s:11:"has_archive";s:5:"false";s:18:"has_archive_string";s:0:"";s:19:"exclude_from_search";s:5:"false";s:15:"capability_type";s:4:"post";s:12:"hierarchical";s:5:"false";s:7:"rewrite";s:4:"true";s:12:"rewrite_slug";s:0:"";s:17:"rewrite_withfront";s:4:"true";s:9:"query_var";s:4:"true";s:14:"query_var_slug";s:0:"";s:13:"menu_position";s:0:"";s:12:"show_in_menu";s:4:"true";s:19:"show_in_menu_string";s:0:"";s:9:"menu_icon";s:0:"";s:8:"supports";a:3:{i:0;s:5:"title";i:1;s:6:"editor";i:2;s:9:"thumbnail";}s:10:"taxonomies";a:1:{i:0;s:8:"post_tag";}s:6:"labels";a:21:{s:9:"menu_name";s:0:"";s:9:"all_items";s:0:"";s:7:"add_new";s:0:"";s:12:"add_new_item";s:0:"";s:9:"edit_item";s:0:"";s:8:"new_item";s:0:"";s:9:"view_item";s:0:"";s:12:"search_items";s:0:"";s:9:"not_found";s:0:"";s:18:"not_found_in_trash";s:0:"";s:6:"parent";s:0:"";s:14:"featured_image";s:0:"";s:18:"set_featured_image";s:0:"";s:21:"remove_featured_image";s:0:"";s:18:"use_featured_image";s:0:"";s:8:"archives";s:0:"";s:16:"insert_into_item";s:0:"";s:21:"uploaded_to_this_item";s:0:"";s:17:"filter_items_list";s:0:"";s:21:"items_list_navigation";s:0:"";s:10:"items_list";s:0:"";}s:15:"custom_supports";s:0:"";}}', 'yes'),
(197, 'newsletter_logger_secret', 'c4329769', 'yes'),
(198, 'newsletter_dismissed', 'a:1:{s:6:"wpmail";i:1;}', 'yes'),
(199, 'newsletter_main', 'a:8:{s:11:"return_path";s:0:"";s:8:"reply_to";s:0:"";s:12:"sender_email";s:20:"newsletter@localhost";s:11:"sender_name";s:8:"Futurify";s:6:"editor";i:0;s:13:"scheduler_max";i:100;s:9:"phpmailer";i:0;s:7:"api_key";s:10:"8318755074";}', 'yes'),
(200, 'newsletter_extension_versions', 'a:0:{}', 'no'),
(201, 'newsletter_main_smtp', 'a:7:{s:7:"enabled";i:0;s:4:"host";s:0:"";s:4:"user";s:0:"";s:4:"pass";s:0:"";s:4:"port";i:25;s:6:"secure";s:0:"";s:12:"ssl_insecure";i:0;}', 'yes'),
(202, 'newsletter_main_version', '1.2.9', 'yes'),
(203, 'newsletter', 'a:20:{s:14:"noconfirmation";i:0;s:12:"profile_text";s:301:"<p>Change your subscription preferences to get what you are most interested in.</p>\n    <p>If you change your email address, a confirmation email will be sent to activate it.</p>\n    </p>\n    {profile_form}\n    <p>To cancel your subscription, <a href=\'{unsubscription_confirm_url}\'>click here</a>.</p>";s:21:"profile_email_changed";s:123:"Your email has been changed, an activation email has been sent. Please follow the instructions to activate the new address.";s:13:"profile_error";s:147:"Your email is not valid or already in use by another subscriber or another generic error has been found. Check your data or contact the site owner.";s:10:"error_text";s:173:"<p>This subscription can\'t be completed, sorry. The email address is blocked or already subscribed. You should contact the owner to unlock that email address. Thank you.</p>";s:18:"subscribe_wp_users";i:0;s:17:"subscription_text";s:19:"{subscription_form}";s:17:"confirmation_text";s:267:"<p>You have successfully subscribed to the newsletter. You\'ll\nreceive a confirmation email in few minutes. Please follow the\nlink in it to confirm your subscription. If the email takes\nmore than 15 minutes to appear in your mailbox, please check\nyour spam folder.</p>";s:20:"confirmation_subject";s:53:"Please confirm subscription - {blog_title} newsletter";s:21:"confirmation_tracking";s:0:"";s:20:"confirmation_message";s:424:"<p>Hi {name},</p>\n<p>A newsletter subscription request for this email address was\nreceived. Please confirm it by <a href="{subscription_confirm_url}"><strong>clicking here</strong></a>. If you cannot\nclick the link, please use the following link:</p>\n\n<p>{subscription_confirm_url}</p>\n\n<p>If you did not make this subscription request, just ignore this\nmessage.</p>\n<p>Thank you!<br>\n<a href=\'{blog_url}\'>{blog_url}</a></p>";s:14:"confirmed_text";s:62:"<p>Your subscription has been confirmed! Thank you {name}!</p>";s:17:"confirmed_subject";s:22:"Welcome aboard, {name}";s:17:"confirmed_message";s:277:"<p>This message confirms your subscription to the {blog_title} newsletter.</p>\n<p>Thank you!<br>\n<a href=\'{blog_url}\'>{blog_url}</a></p>\n<p>To unsubscribe, <a href=\'{unsubscription_url}\'>click here</a>.  To change subscriber options,\n<a href=\'{profile_url}\'>click here</a>.</p>";s:18:"confirmed_tracking";s:0:"";s:19:"unsubscription_text";s:111:"<p>Please confirm that you want to unsubscribe by <a href=\'{unsubscription_confirm_url}\'>clicking here</a>.</p>";s:25:"unsubscription_error_text";s:118:"<p>The subscriber was not found, it probably has already been removed. No further actions are required. Thank you.</p>";s:17:"unsubscribed_text";s:53:"<p>Your subscription has been deleted. Thank you.</p>";s:20:"unsubscribed_subject";s:8:"Goodbye!";s:20:"unsubscribed_message";s:195:"<p>This message confirms that you have unsubscribed from the {blog_title} newsletter.</p>\n<p>You\'re welcome to sign up again anytime.</p>\n<p>Thank you!<br>\n<a href=\'{blog_url}\'>{blog_url}</a></p>";}', 'yes'),
(204, 'newsletter_profile', 'a:207:{s:5:"email";s:13:"Email Address";s:11:"email_error";s:24:"The email is not correct";s:4:"name";s:4:"Name";s:10:"name_error";s:23:"The name is not correct";s:11:"name_status";s:1:"0";s:10:"name_rules";s:1:"0";s:7:"surname";s:9:"Last name";s:13:"surname_error";s:28:"The last name is not correct";s:14:"surname_status";s:1:"0";s:3:"sex";s:3:"I\'m";s:7:"privacy";s:51:"Subscribing I accept the privacy rules of this site";s:13:"privacy_error";s:37:"You must accept the privacy statement";s:14:"privacy_status";s:1:"0";s:11:"privacy_url";s:0:"";s:9:"subscribe";s:9:"Subscribe";s:4:"save";s:4:"Save";s:12:"title_female";s:4:"Mrs.";s:10:"title_male";s:3:"Mr.";s:10:"title_none";s:4:"Dear";s:8:"sex_male";s:3:"Man";s:10:"sex_female";s:5:"Woman";s:8:"sex_none";s:4:"None";s:6:"list_1";s:0:"";s:13:"list_1_status";i:0;s:14:"list_1_checked";i:0;s:6:"list_2";s:0:"";s:13:"list_2_status";i:0;s:14:"list_2_checked";i:0;s:6:"list_3";s:0:"";s:13:"list_3_status";i:0;s:14:"list_3_checked";i:0;s:6:"list_4";s:0:"";s:13:"list_4_status";i:0;s:14:"list_4_checked";i:0;s:6:"list_5";s:0:"";s:13:"list_5_status";i:0;s:14:"list_5_checked";i:0;s:6:"list_6";s:0:"";s:13:"list_6_status";i:0;s:14:"list_6_checked";i:0;s:6:"list_7";s:0:"";s:13:"list_7_status";i:0;s:14:"list_7_checked";i:0;s:6:"list_8";s:0:"";s:13:"list_8_status";i:0;s:14:"list_8_checked";i:0;s:6:"list_9";s:0:"";s:13:"list_9_status";i:0;s:14:"list_9_checked";i:0;s:7:"list_10";s:0:"";s:14:"list_10_status";i:0;s:15:"list_10_checked";i:0;s:7:"list_11";s:0:"";s:14:"list_11_status";i:0;s:15:"list_11_checked";i:0;s:7:"list_12";s:0:"";s:14:"list_12_status";i:0;s:15:"list_12_checked";i:0;s:7:"list_13";s:0:"";s:14:"list_13_status";i:0;s:15:"list_13_checked";i:0;s:7:"list_14";s:0:"";s:14:"list_14_status";i:0;s:15:"list_14_checked";i:0;s:7:"list_15";s:0:"";s:14:"list_15_status";i:0;s:15:"list_15_checked";i:0;s:7:"list_16";s:0:"";s:14:"list_16_status";i:0;s:15:"list_16_checked";i:0;s:7:"list_17";s:0:"";s:14:"list_17_status";i:0;s:15:"list_17_checked";i:0;s:7:"list_18";s:0:"";s:14:"list_18_status";i:0;s:15:"list_18_checked";i:0;s:7:"list_19";s:0:"";s:14:"list_19_status";i:0;s:15:"list_19_checked";i:0;s:7:"list_20";s:0:"";s:14:"list_20_status";i:0;s:15:"list_20_checked";i:0;s:16:"profile_1_status";s:1:"0";s:9:"profile_1";s:0:"";s:14:"profile_1_type";s:4:"text";s:21:"profile_1_placeholder";s:0:"";s:15:"profile_1_rules";s:1:"0";s:17:"profile_1_options";s:0:"";s:16:"profile_2_status";s:1:"0";s:9:"profile_2";s:0:"";s:14:"profile_2_type";s:4:"text";s:21:"profile_2_placeholder";s:0:"";s:15:"profile_2_rules";s:1:"0";s:17:"profile_2_options";s:0:"";s:16:"profile_3_status";s:1:"0";s:9:"profile_3";s:0:"";s:14:"profile_3_type";s:4:"text";s:21:"profile_3_placeholder";s:0:"";s:15:"profile_3_rules";s:1:"0";s:17:"profile_3_options";s:0:"";s:16:"profile_4_status";s:1:"0";s:9:"profile_4";s:0:"";s:14:"profile_4_type";s:4:"text";s:21:"profile_4_placeholder";s:0:"";s:15:"profile_4_rules";s:1:"0";s:17:"profile_4_options";s:0:"";s:16:"profile_5_status";s:1:"0";s:9:"profile_5";s:0:"";s:14:"profile_5_type";s:4:"text";s:21:"profile_5_placeholder";s:0:"";s:15:"profile_5_rules";s:1:"0";s:17:"profile_5_options";s:0:"";s:16:"profile_6_status";s:1:"0";s:9:"profile_6";s:0:"";s:14:"profile_6_type";s:4:"text";s:21:"profile_6_placeholder";s:0:"";s:15:"profile_6_rules";s:1:"0";s:17:"profile_6_options";s:0:"";s:16:"profile_7_status";s:1:"0";s:9:"profile_7";s:0:"";s:14:"profile_7_type";s:4:"text";s:21:"profile_7_placeholder";s:0:"";s:15:"profile_7_rules";s:1:"0";s:17:"profile_7_options";s:0:"";s:16:"profile_8_status";s:1:"0";s:9:"profile_8";s:0:"";s:14:"profile_8_type";s:4:"text";s:21:"profile_8_placeholder";s:0:"";s:15:"profile_8_rules";s:1:"0";s:17:"profile_8_options";s:0:"";s:16:"profile_9_status";s:1:"0";s:9:"profile_9";s:0:"";s:14:"profile_9_type";s:4:"text";s:21:"profile_9_placeholder";s:0:"";s:15:"profile_9_rules";s:1:"0";s:17:"profile_9_options";s:0:"";s:17:"profile_10_status";s:1:"0";s:10:"profile_10";s:0:"";s:15:"profile_10_type";s:4:"text";s:22:"profile_10_placeholder";s:0:"";s:16:"profile_10_rules";s:1:"0";s:18:"profile_10_options";s:0:"";s:17:"profile_11_status";s:1:"0";s:10:"profile_11";s:0:"";s:15:"profile_11_type";s:4:"text";s:22:"profile_11_placeholder";s:0:"";s:16:"profile_11_rules";s:1:"0";s:18:"profile_11_options";s:0:"";s:17:"profile_12_status";s:1:"0";s:10:"profile_12";s:0:"";s:15:"profile_12_type";s:4:"text";s:22:"profile_12_placeholder";s:0:"";s:16:"profile_12_rules";s:1:"0";s:18:"profile_12_options";s:0:"";s:17:"profile_13_status";s:1:"0";s:10:"profile_13";s:0:"";s:15:"profile_13_type";s:4:"text";s:22:"profile_13_placeholder";s:0:"";s:16:"profile_13_rules";s:1:"0";s:18:"profile_13_options";s:0:"";s:17:"profile_14_status";s:1:"0";s:10:"profile_14";s:0:"";s:15:"profile_14_type";s:4:"text";s:22:"profile_14_placeholder";s:0:"";s:16:"profile_14_rules";s:1:"0";s:18:"profile_14_options";s:0:"";s:17:"profile_15_status";s:1:"0";s:10:"profile_15";s:0:"";s:15:"profile_15_type";s:4:"text";s:22:"profile_15_placeholder";s:0:"";s:16:"profile_15_rules";s:1:"0";s:18:"profile_15_options";s:0:"";s:17:"profile_16_status";s:1:"0";s:10:"profile_16";s:0:"";s:15:"profile_16_type";s:4:"text";s:22:"profile_16_placeholder";s:0:"";s:16:"profile_16_rules";s:1:"0";s:18:"profile_16_options";s:0:"";s:17:"profile_17_status";s:1:"0";s:10:"profile_17";s:0:"";s:15:"profile_17_type";s:4:"text";s:22:"profile_17_placeholder";s:0:"";s:16:"profile_17_rules";s:1:"0";s:18:"profile_17_options";s:0:"";s:17:"profile_18_status";s:1:"0";s:10:"profile_18";s:0:"";s:15:"profile_18_type";s:4:"text";s:22:"profile_18_placeholder";s:0:"";s:16:"profile_18_rules";s:1:"0";s:18:"profile_18_options";s:0:"";s:17:"profile_19_status";s:1:"0";s:10:"profile_19";s:0:"";s:15:"profile_19_type";s:4:"text";s:22:"profile_19_placeholder";s:0:"";s:16:"profile_19_rules";s:1:"0";s:18:"profile_19_options";s:0:"";s:17:"profile_20_status";s:1:"0";s:10:"profile_20";s:0:"";s:15:"profile_20_type";s:4:"text";s:22:"profile_20_placeholder";s:0:"";s:16:"profile_20_rules";s:1:"0";s:18:"profile_20_options";s:0:"";s:13:"surname_rules";s:1:"0";s:10:"sex_status";s:1:"0";s:13:"profile_error";s:0:"";s:5:"style";s:0:"";s:12:"widget_style";s:0:"";}', 'yes'),
(205, 'newsletter_subscription_lists', 'a:60:{s:6:"list_1";s:0:"";s:13:"list_1_status";i:0;s:14:"list_1_checked";i:0;s:6:"list_2";s:0:"";s:13:"list_2_status";i:0;s:14:"list_2_checked";i:0;s:6:"list_3";s:0:"";s:13:"list_3_status";i:0;s:14:"list_3_checked";i:0;s:6:"list_4";s:0:"";s:13:"list_4_status";i:0;s:14:"list_4_checked";i:0;s:6:"list_5";s:0:"";s:13:"list_5_status";i:0;s:14:"list_5_checked";i:0;s:6:"list_6";s:0:"";s:13:"list_6_status";i:0;s:14:"list_6_checked";i:0;s:6:"list_7";s:0:"";s:13:"list_7_status";i:0;s:14:"list_7_checked";i:0;s:6:"list_8";s:0:"";s:13:"list_8_status";i:0;s:14:"list_8_checked";i:0;s:6:"list_9";s:0:"";s:13:"list_9_status";i:0;s:14:"list_9_checked";i:0;s:7:"list_10";s:0:"";s:14:"list_10_status";i:0;s:15:"list_10_checked";i:0;s:7:"list_11";s:0:"";s:14:"list_11_status";i:0;s:15:"list_11_checked";i:0;s:7:"list_12";s:0:"";s:14:"list_12_status";i:0;s:15:"list_12_checked";i:0;s:7:"list_13";s:0:"";s:14:"list_13_status";i:0;s:15:"list_13_checked";i:0;s:7:"list_14";s:0:"";s:14:"list_14_status";i:0;s:15:"list_14_checked";i:0;s:7:"list_15";s:0:"";s:14:"list_15_status";i:0;s:15:"list_15_checked";i:0;s:7:"list_16";s:0:"";s:14:"list_16_status";i:0;s:15:"list_16_checked";i:0;s:7:"list_17";s:0:"";s:14:"list_17_status";i:0;s:15:"list_17_checked";i:0;s:7:"list_18";s:0:"";s:14:"list_18_status";i:0;s:15:"list_18_checked";i:0;s:7:"list_19";s:0:"";s:14:"list_19_status";i:0;s:15:"list_19_checked";i:0;s:7:"list_20";s:0:"";s:14:"list_20_status";i:0;s:15:"list_20_checked";i:0;}', 'yes'),
(206, 'newsletter_subscription_template', 'a:2:{s:7:"enabled";i:0;s:8:"template";s:1829:"<!DOCTYPE html>\n<html>\n    <head>\n        <!-- General styles, not used by all email clients -->\n        <style type="text/css" media="all">\n            a {\n                text-decoration: none;\n                color: #0088cc;\n            }\n        </style>\n    </head>\n    \n    <!-- KEEP THE TAMPLE SIMPLE: THOSE ARE SERVICE MESSAGES. -->\n    <body style="margin: 0;">\n        <!-- Top title with dark background #333, font color #fff, font size 32px -->\n        <table style="background-color: #333; width: 100%; color: #fff; font-size: 32px">\n            <tr>\n                <td style="padding: 25px; text-align: center">\n                    {blog_title}\n                </td>\n            </tr>\n        </table>\n\n        <!-- Main table 100% wide with background color #eee -->    \n        <table style="background-color: #eee; width: 100%;">\n            <tr>\n                <td align="center"  style="padding: 25px;">\n\n                    <!-- Content table with backgdound color #fff, width 500px -->\n                    <table style="background-color: #fff; width: 500px; border: 1px solid #ddd;">\n                        <tr>\n                            <td style="padding: 25px; font-size: 16px; font-family: sans-serif">\n                                <!-- The {message} tag is replaced with one of confirmation, welcome or goodbye messages -->\n                                <!-- Messages content can be configured on Newsletter List Building panels --> \n\n                                {message}\n                                \n                                <!-- Signature if not already added to single messages (surround with <p>) -->\n\n                            </td>\n                        </tr>\n                    </table>\n\n                </td>\n            </tr>\n        </table>\n\n    </body>\n</html>";}', 'no'),
(207, 'newsletter_subscription_version', '2.0.2', 'yes'),
(208, 'newsletter_emails', 'a:1:{s:5:"theme";s:7:"default";}', 'yes'),
(209, 'newsletter_emails_theme_default', 'a:0:{}', 'no'),
(210, 'newsletter_emails_version', '1.1.4', 'yes'),
(211, 'newsletter_users', 'a:0:{}', 'yes'),
(213, 'newsletter_users_version', '1.0.5', 'yes'),
(215, 'newsletter_statistics', 'a:1:{s:3:"key";s:32:"6f1bdd1cda3e8ef098e953a6d8478d39";}', 'yes'),
(216, 'newsletter_statistics_version', '1.1.6', 'yes'),
(218, 'newsletter_lock', 'a:4:{s:3:"ids";s:0:"";s:3:"url";s:0:"";s:7:"message";s:89:"<p>Subscribe to our newsletter and get access to the full article.</p>[subscription_form]";s:7:"enabled";i:0;}', 'yes'),
(219, 'newsletter_lock_version', '1.0.3', 'yes'),
(221, 'newsletter_wp', 'a:5:{s:15:"subscribe_label";s:24:"Subscribe our newsletter";s:9:"subscribe";i:0;s:12:"confirmation";i:0;s:7:"welcome";i:0;s:6:"delete";i:0;}', 'yes'),
(222, 'newsletter_wp_version', '1.0.1', 'yes'),
(224, 'newsletter_feed', 'a:0:{}', 'yes'),
(225, 'newsletter_feed_version', '1.0.0', 'yes'),
(228, 'widget_newsletterwidget', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:4:"text";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(230, 'newsletter_diagnostic_cron_calls', 'a:300:{i:0;i:1470069168;i:1;i:1470103699;i:2;i:1470104211;i:3;i:1470104554;i:4;i:1470104823;i:5;i:1470108461;i:6;i:1470112560;i:7;i:1470113178;i:8;i:1470126259;i:9;i:1470126404;i:10;i:1470126477;i:11;i:1470126546;i:12;i:1470126702;i:13;i:1470126802;i:14;i:1470127048;i:15;i:1470127411;i:16;i:1470127592;i:17;i:1470127955;i:18;i:1470128197;i:19;i:1470128584;i:20;i:1470128614;i:21;i:1470128722;i:22;i:1470128804;i:23;i:1470129130;i:24;i:1470129152;i:25;i:1470129234;i:26;i:1470129268;i:27;i:1470129291;i:28;i:1470129296;i:29;i:1470149634;i:30;i:1470149801;i:31;i:1470150152;i:32;i:1470150390;i:33;i:1470150690;i:34;i:1470150858;i:35;i:1470150994;i:36;i:1470151324;i:37;i:1470151337;i:38;i:1470151595;i:39;i:1470151617;i:40;i:1470151901;i:41;i:1470152238;i:42;i:1470152565;i:43;i:1470152819;i:44;i:1470153179;i:45;i:1470153419;i:46;i:1470153701;i:47;i:1470154025;i:48;i:1470154314;i:49;i:1470154601;i:50;i:1470154916;i:51;i:1470155220;i:52;i:1470155564;i:53;i:1470155804;i:54;i:1470156107;i:55;i:1470156469;i:56;i:1470156922;i:57;i:1470157019;i:58;i:1470157301;i:59;i:1470157623;i:60;i:1470157962;i:61;i:1470158043;i:62;i:1470158125;i:63;i:1470158193;i:64;i:1470158233;i:65;i:1470158313;i:66;i:1470158555;i:67;i:1470158806;i:68;i:1470159144;i:69;i:1470159451;i:70;i:1470159710;i:71;i:1470159990;i:72;i:1470160311;i:73;i:1470234097;i:74;i:1470234546;i:75;i:1470234836;i:76;i:1470235349;i:77;i:1470235623;i:78;i:1470235996;i:79;i:1470236274;i:80;i:1470236497;i:81;i:1470236849;i:82;i:1470237099;i:83;i:1470237340;i:84;i:1470237438;i:85;i:1470237690;i:86;i:1470238065;i:87;i:1470238306;i:88;i:1470238597;i:89;i:1470238909;i:90;i:1470239270;i:91;i:1470239511;i:92;i:1470239875;i:93;i:1470240133;i:94;i:1470240465;i:95;i:1470240719;i:96;i:1470241001;i:97;i:1470241361;i:98;i:1470241601;i:99;i:1470241961;i:100;i:1470242201;i:101;i:1470242490;i:102;i:1470242801;i:103;i:1470243119;i:104;i:1470243401;i:105;i:1470243753;i:106;i:1470270029;i:107;i:1470270173;i:108;i:1470270426;i:109;i:1470270749;i:110;i:1470270995;i:111;i:1470271331;i:112;i:1470271679;i:113;i:1470271895;i:114;i:1470272233;i:115;i:1470272501;i:116;i:1470272838;i:117;i:1470273119;i:118;i:1470273608;i:119;i:1470273708;i:120;i:1470318698;i:121;i:1470319039;i:122;i:1470319291;i:123;i:1470319591;i:124;i:1470319952;i:125;i:1470320260;i:126;i:1470320497;i:127;i:1470320795;i:128;i:1470321127;i:129;i:1470321421;i:130;i:1470321725;i:131;i:1470322035;i:132;i:1470322296;i:133;i:1470322644;i:134;i:1470323061;i:135;i:1470323303;i:136;i:1470323492;i:137;i:1470323665;i:138;i:1470323829;i:139;i:1470324093;i:140;i:1470324392;i:141;i:1470324690;i:142;i:1470325002;i:143;i:1470325290;i:144;i:1470325601;i:145;i:1470325963;i:146;i:1470326198;i:147;i:1470326515;i:148;i:1470326810;i:149;i:1470327097;i:150;i:1470327395;i:151;i:1470327732;i:152;i:1470328003;i:153;i:1470328311;i:154;i:1470328618;i:155;i:1470328890;i:156;i:1470329204;i:157;i:1470329553;i:158;i:1470329794;i:159;i:1470330094;i:160;i:1470330396;i:161;i:1470330717;i:162;i:1470331001;i:163;i:1470331292;i:164;i:1470409861;i:165;i:1470409977;i:166;i:1470410333;i:167;i:1470410503;i:168;i:1470410800;i:169;i:1470411110;i:170;i:1470411413;i:171;i:1470411702;i:172;i:1470411993;i:173;i:1470412300;i:174;i:1470412630;i:175;i:1470412908;i:176;i:1470413205;i:177;i:1470413513;i:178;i:1470413794;i:179;i:1470414095;i:180;i:1470414457;i:181;i:1470414742;i:182;i:1470415016;i:183;i:1470415317;i:184;i:1470415591;i:185;i:1470415898;i:186;i:1470416259;i:187;i:1470416501;i:188;i:1470416863;i:189;i:1470417095;i:190;i:1470417464;i:191;i:1470447564;i:192;i:1470447704;i:193;i:1470448066;i:194;i:1470448308;i:195;i:1470449962;i:196;i:1470450098;i:197;i:1470450424;i:198;i:1470450695;i:199;i:1470451030;i:200;i:1470451307;i:201;i:1470451641;i:202;i:1470452002;i:203;i:1470452197;i:204;i:1470452494;i:205;i:1470456351;i:206;i:1470456416;i:207;i:1470456694;i:208;i:1470457021;i:209;i:1470457307;i:210;i:1470457666;i:211;i:1470457894;i:212;i:1470458175;i:213;i:1470458237;i:214;i:1470458494;i:215;i:1470458823;i:216;i:1470459185;i:217;i:1470461674;i:218;i:1470461775;i:219;i:1470461854;i:220;i:1470462095;i:221;i:1470462395;i:222;i:1470462693;i:223;i:1470463023;i:224;i:1470463385;i:225;i:1470463629;i:226;i:1470464280;i:227;i:1470464771;i:228;i:1470464981;i:229;i:1470467886;i:230;i:1470468143;i:231;i:1470468413;i:232;i:1470469171;i:233;i:1470469306;i:234;i:1470469669;i:235;i:1470469897;i:236;i:1470470225;i:237;i:1470470492;i:238;i:1470470831;i:239;i:1470471134;i:240;i:1470471393;i:241;i:1470471755;i:242;i:1470472035;i:243;i:1470472304;i:244;i:1470472605;i:245;i:1470472895;i:246;i:1470473202;i:247;i:1470473571;i:248;i:1470473798;i:249;i:1470474132;i:250;i:1470474530;i:251;i:1470474718;i:252;i:1470475151;i:253;i:1470475358;i:254;i:1470475640;i:255;i:1470475943;i:256;i:1470476191;i:257;i:1470476541;i:258;i:1470476902;i:259;i:1470477149;i:260;i:1470477390;i:261;i:1470477752;i:262;i:1470477994;i:263;i:1470478345;i:264;i:1470478635;i:265;i:1470478996;i:266;i:1470479237;i:267;i:1470479599;i:268;i:1470481059;i:269;i:1470481300;i:270;i:1470481661;i:271;i:1470481903;i:272;i:1470483156;i:273;i:1470483399;i:274;i:1470483701;i:275;i:1470483995;i:276;i:1470484317;i:277;i:1470484606;i:278;i:1470484926;i:279;i:1470485198;i:280;i:1470485497;i:281;i:1470485803;i:282;i:1470486105;i:283;i:1470486408;i:284;i:1470486722;i:285;i:1470486990;i:286;i:1470487348;i:287;i:1470487681;i:288;i:1470487929;i:289;i:1470488235;i:290;i:1470488490;i:291;i:1470488879;i:292;i:1470489121;i:293;i:1470489419;i:294;i:1470489708;i:295;i:1470489993;i:296;i:1470490328;i:297;i:1470490610;i:298;i:1470490933;i:299;i:1470491196;}', 'no'),
(385, 'alm_settings', 'a:10:{s:19:"_alm_container_type";s:1:"2";s:14:"_alm_classname";s:0:"";s:16:"_alm_disable_css";s:1:"0";s:14:"_alm_btn_color";s:7:"default";s:18:"_alm_btn_classname";s:0:"";s:19:"_alm_nonce_security";s:1:"0";s:15:"_alm_scroll_top";s:1:"0";s:20:"_alm_disable_dynamic";s:1:"0";s:13:"_alm_hide_btn";s:1:"1";s:18:"_alm_error_notices";s:1:"1";}', 'yes'),
(453, 'category_children', 'a:0:{}', 'yes'),
(571, 'cpto_options', 'a:6:{s:23:"show_reorder_interfaces";a:3:{s:4:"post";s:4:"show";s:10:"attachment";s:4:"show";s:7:"project";s:4:"show";}s:8:"autosort";i:1;s:9:"adminsort";i:1;s:17:"archive_drag_drop";i:1;s:10:"capability";s:13:"switch_themes";s:21:"navigation_sort_apply";i:1;}', 'yes'),
(575, 'CPT_configured', 'TRUE', 'yes'),
(656, 'addthis_shared_settings', 'a:21:{s:25:"addthis_anonymous_profile";s:35:"wp-327218f8ba5913332c3840b41e6998e4";s:28:"addthis_asynchronous_loading";b:1;s:19:"addthis_environment";s:0:"";s:24:"addthis_per_post_enabled";b:1;s:23:"addthis_plugin_controls";s:9:"WordPress";s:15:"addthis_profile";s:0:"";s:15:"addthis_rate_us";s:0:"";s:28:"credential_validation_status";i:0;s:8:"wpfooter";b:1;s:31:"sharing_buttons_feature_enabled";s:1:"1";s:24:"addthis_twitter_template";s:0:"";s:13:"addthis_bitly";b:0;s:18:"addthis_share_json";s:0:"";s:19:"addthis_layers_json";s:0:"";s:16:"data_ga_property";s:0:"";s:16:"addthis_language";s:0:"";s:9:"atversion";i:300;s:19:"addthis_append_data";b:1;s:18:"addthis_addressbar";b:0;s:11:"addthis_508";s:0:"";s:19:"addthis_config_json";s:0:"";}', 'yes'),
(657, 'addthis_sharing_buttons_settings', 'a:54:{s:5:"above";s:13:"large_toolbox";s:17:"above_chosen_list";s:0:"";s:19:"above_auto_services";b:1;s:17:"above_custom_more";s:0:"";s:22:"above_custom_preferred";s:0:"";s:21:"above_custom_services";s:0:"";s:17:"above_custom_size";s:0:"";s:19:"above_custom_string";s:0:"";s:21:"addthis_above_enabled";b:0;s:18:"addthis_aftertitle";b:0;s:22:"addthis_beforecomments";b:0;s:21:"addthis_below_enabled";b:0;s:21:"addthis_sidebar_count";s:1:"5";s:23:"addthis_sidebar_enabled";b:0;s:24:"addthis_sidebar_position";s:4:"left";s:30:"addthis_mobile_toolbar_enabled";b:0;s:43:"addthis_mobile_toolbar_numPreferredServices";s:1:"4";s:31:"addthis_mobile_toolbar_position";s:6:"bottom";s:29:"addthis_mobile_toolbar_counts";b:1;s:23:"atversion_update_status";i:0;s:5:"below";s:13:"large_toolbox";s:17:"below_chosen_list";s:0:"";s:19:"below_auto_services";b:1;s:17:"below_custom_more";s:0:"";s:22:"below_custom_preferred";s:0:"";s:21:"below_custom_services";s:0:"";s:17:"below_custom_size";s:0:"";s:19:"below_custom_string";s:0:"";s:8:"location";s:5:"below";s:5:"style";s:11:"fb_tw_p1_sc";s:7:"toolbox";s:0:"";s:25:"addthis_above_showon_home";b:1;s:26:"addthis_above_showon_posts";b:1;s:26:"addthis_above_showon_pages";b:1;s:29:"addthis_above_showon_archives";b:1;s:31:"addthis_above_showon_categories";b:1;s:29:"addthis_above_showon_excerpts";b:1;s:25:"addthis_below_showon_home";b:1;s:26:"addthis_below_showon_posts";b:1;s:26:"addthis_below_showon_pages";b:1;s:29:"addthis_below_showon_archives";b:1;s:31:"addthis_below_showon_categories";b:1;s:29:"addthis_below_showon_excerpts";b:1;s:27:"addthis_sidebar_showon_home";b:1;s:28:"addthis_sidebar_showon_posts";b:1;s:28:"addthis_sidebar_showon_pages";b:1;s:31:"addthis_sidebar_showon_archives";b:1;s:33:"addthis_sidebar_showon_categories";b:1;s:34:"addthis_mobile_toolbar_showon_home";b:1;s:35:"addthis_mobile_toolbar_showon_posts";b:1;s:35:"addthis_mobile_toolbar_showon_pages";b:1;s:38:"addthis_mobile_toolbar_showon_archives";b:1;s:40:"addthis_mobile_toolbar_showon_categories";b:1;s:22:"addthis_plugin_version";s:5:"5.3.3";}', 'yes'),
(658, 'widget_addthis-widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(659, 'addthis_run_once', '1', 'yes'),
(772, 'tadv_settings', 'a:6:{s:9:"toolbar_1";s:153:"fontselect,fontsizeselect,underline,bold,italic,blockquote,bullist,numlist,alignleft,aligncenter,alignright,link,unlink,table,fullscreen,undo,redo,wp_adv";s:9:"toolbar_2";s:145:"formatselect,alignjustify,strikethrough,outdent,indent,pastetext,removeformat,charmap,wp_more,emoticons,forecolor,wp_help,wp_page,backcolor,image";s:9:"toolbar_3";s:0:"";s:9:"toolbar_4";s:0:"";s:7:"options";s:21:"advlist,menubar,image";s:7:"plugins";s:117:"anchor,code,insertdatetime,nonbreaking,print,searchreplace,table,visualblocks,visualchars,emoticons,advlist,importcss";}', 'yes'),
(773, 'tadv_admin_settings', 'a:3:{s:7:"options";s:9:"importcss";s:16:"disabled_plugins";s:0:"";s:16:"disabled_editors";s:0:"";}', 'yes'),
(774, 'tadv_version', '4000', 'yes'),
(814, 'vc_version', '4.11.2.1', 'yes'),
(1374, 'widget_a2a_share_save_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(1375, 'widget_a2a_follow_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(1470, 'itsec_data', 'a:5:{s:5:"build";i:4041;s:20:"activation_timestamp";i:1470458174;s:17:"already_supported";b:0;s:15:"setup_completed";b:0;s:18:"tooltips_dismissed";b:0;}', 'yes'),
(1471, 'itsec_free_just_activated', '1', 'yes'),
(1472, 'itsec_malware', 'a:2:{s:7:"enabled";b:0;s:7:"api_key";s:0:"";}', 'yes'),
(1473, 'itsec_initials', 'a:0:{}', 'yes'),
(1474, 'itsec_api_nag', '1', 'yes'),
(1475, 'itsec_global', 'a:24:{s:18:"notification_email";a:1:{i:0;s:20:"duytan1008@gmail.com";}s:12:"backup_email";a:1:{i:0;s:20:"duytan1008@gmail.com";}s:15:"lockout_message";s:5:"error";s:20:"user_lockout_message";s:64:"You have been locked out due to too many invalid login attempts.";s:25:"community_lockout_message";s:77:"Your IP address has been flagged as a threat by the iThemes Security network.";s:9:"blacklist";b:1;s:15:"blacklist_count";i:3;s:16:"blacklist_period";i:7;s:19:"email_notifications";b:1;s:14:"lockout_period";i:15;s:18:"lockout_white_list";a:0:{}s:12:"log_rotation";i:14;s:8:"log_type";i:0;s:12:"log_location";s:66:"/www/public_html/futurify/wp-content/uploads/ithemes-security/logs";s:14:"allow_tracking";b:0;s:11:"write_files";b:0;s:10:"nginx_file";s:36:"/www/public_html/futurify/nginx.conf";s:24:"infinitewp_compatibility";b:0;s:11:"did_upgrade";b:0;s:9:"lock_file";b:0;s:12:"digest_email";b:0;s:14:"proxy_override";b:0;s:14:"hide_admin_bar";b:0;s:8:"log_info";s:39:"futurify-CwNQGeZD5EGGT38MlDZrGqPEsO33DQ";}', 'yes'),
(1476, 'itsec_temp_whitelist_ip', 'a:1:{s:3:"::1";i:1470576781;}', 'yes'),
(1478, 'itsec-storage', 'a:5:{s:6:"backup";a:9:{s:9:"all_sites";b:0;s:6:"method";i:1;s:8:"location";s:69:"/www/public_html/futurify/wp-content/uploads/ithemes-security/backups";s:6:"retain";i:0;s:3:"zip";b:1;s:7:"exclude";a:3:{i:0;s:9:"itsec_log";i:1;s:10:"itsec_temp";i:2;s:14:"itsec_lockouts";}s:7:"enabled";b:0;s:8:"interval";i:3;s:8:"last_run";i:1470458175;}s:6:"global";a:27:{s:18:"notification_email";a:1:{i:0;s:20:"duytan1008@gmail.com";}s:12:"backup_email";a:1:{i:0;s:20:"duytan1008@gmail.com";}s:15:"lockout_message";s:5:"error";s:20:"user_lockout_message";s:64:"You have been locked out due to too many invalid login attempts.";s:25:"community_lockout_message";s:77:"Your IP address has been flagged as a threat by the iThemes Security network.";s:9:"blacklist";b:1;s:15:"blacklist_count";i:3;s:16:"blacklist_period";i:7;s:19:"email_notifications";b:1;s:14:"lockout_period";i:15;s:18:"lockout_white_list";a:0:{}s:12:"log_rotation";i:14;s:8:"log_type";s:8:"database";s:12:"log_location";s:66:"/www/public_html/futurify/wp-content/uploads/ithemes-security/logs";s:8:"log_info";s:39:"futurify-ERjnIQrI6ihmjONFDbXaAYuSLyPruR";s:14:"allow_tracking";b:0;s:11:"write_files";b:1;s:10:"nginx_file";s:36:"/www/public_html/futurify/nginx.conf";s:24:"infinitewp_compatibility";b:0;s:11:"did_upgrade";b:0;s:9:"lock_file";b:0;s:12:"digest_email";b:0;s:14:"proxy_override";b:0;s:14:"hide_admin_bar";b:0;s:16:"show_error_codes";b:0;s:25:"show_new_dashboard_notice";b:0;s:19:"show_security_check";b:0;}s:12:"hide-backend";a:6:{s:4:"slug";s:8:"fr-admin";s:12:"theme_compat";b:1;s:17:"theme_compat_slug";s:9:"not_found";s:16:"post_logout_slug";s:0:"";s:7:"enabled";b:0;s:8:"register";s:15:"wp-register-php";}s:16:"wordpress-tweaks";a:11:{s:18:"wlwmanifest_header";b:0;s:14:"edituri_header";b:0;s:12:"comment_spam";b:0;s:11:"file_editor";b:1;s:14:"disable_xmlrpc";i:0;s:22:"allow_xmlrpc_multiauth";b:0;s:11:"safe_jquery";b:0;s:12:"login_errors";b:0;s:21:"force_unique_nicename";b:0;s:27:"disable_unused_author_pages";b:0;s:14:"jquery_version";s:6:"1.12.4";}s:19:"network-brute-force";a:5:{s:7:"api_key";s:0:"";s:10:"api_secret";s:0:"";s:10:"enable_ban";b:1;s:13:"updates_optin";b:1;s:7:"api_nag";b:0;}}', 'yes') ;

#
# End of data contents of table `lrpmqdj9_options`
# --------------------------------------------------------



#
# Delete any existing table `lrpmqdj9_postmeta`
#

DROP TABLE IF EXISTS `lrpmqdj9_postmeta`;


#
# Table structure of table `lrpmqdj9_postmeta`
#

CREATE TABLE `lrpmqdj9_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=1121 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `lrpmqdj9_postmeta`
#
INSERT INTO `lrpmqdj9_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'templates/page-about-template.php'),
(2, 4, '_form', '<h1>SEND US A<br />MESSAGE.</h1>\n<p>[text* your-name placeholder "Type your full name*"]</p>\n<p>[email* your-email placeholder "Email address*"]</p>\n<p>[tel your-phone placeholder "Phone Number"]</p>\n<p>[text your-cpmpany placeholder "Company name*"]</p>\n<p>[textarea your-message placeholder "Tell us about you, your business and requirements of a new project you want to start with us!"]</p>\n<p><span class="service-choice">Service you\'re interested in</span> [radio service default:1 "Staffing" "MVP" "Customize"]</p>\n<p>[response]</p>\n<p>[submit "SEND TO US"]</p>'),
(3, 4, '_mail', 'a:8:{s:7:"subject";s:25:"Futurify "[your-subject]"";s:6:"sender";s:34:"[your-name] <duytan1008@gmail.com>";s:4:"body";s:179:"From: [your-name] <[your-email]>\nSubject: [your-subject]\n\nMessage Body:\n[your-message]\n\n--\nThis e-mail was sent from a contact form on Futurify (http://futurify.nguyenbui.name.vn)";s:9:"recipient";s:20:"duytan1008@gmail.com";s:18:"additional_headers";s:22:"Reply-To: [your-email]";s:11:"attachments";s:0:"";s:8:"use_html";b:0;s:13:"exclude_blank";b:0;}'),
(4, 4, '_mail_2', 'a:9:{s:6:"active";b:0;s:7:"subject";s:25:"Futurify "[your-subject]"";s:6:"sender";s:31:"Futurify <duytan1008@gmail.com>";s:4:"body";s:121:"Message Body:\n[your-message]\n\n--\nThis e-mail was sent from a contact form on Futurify (http://futurify.nguyenbui.name.vn)";s:9:"recipient";s:12:"[your-email]";s:18:"additional_headers";s:30:"Reply-To: duytan1008@gmail.com";s:11:"attachments";s:0:"";s:8:"use_html";b:0;s:13:"exclude_blank";b:0;}'),
(5, 4, '_messages', 'a:23:{s:12:"mail_sent_ok";s:45:"Thank you for your message. It has been sent.";s:12:"mail_sent_ng";s:71:"There was an error trying to send your message. Please try again later.";s:16:"validation_error";s:61:"One or more fields have an error. Please check and try again.";s:4:"spam";s:71:"There was an error trying to send your message. Please try again later.";s:12:"accept_terms";s:69:"You must accept the terms and conditions before sending your message.";s:16:"invalid_required";s:22:"The field is required.";s:16:"invalid_too_long";s:22:"The field is too long.";s:17:"invalid_too_short";s:23:"The field is too short.";s:12:"invalid_date";s:29:"The date format is incorrect.";s:14:"date_too_early";s:44:"The date is before the earliest one allowed.";s:13:"date_too_late";s:41:"The date is after the latest one allowed.";s:13:"upload_failed";s:46:"There was an unknown error uploading the file.";s:24:"upload_file_type_invalid";s:49:"You are not allowed to upload files of this type.";s:21:"upload_file_too_large";s:20:"The file is too big.";s:23:"upload_failed_php_error";s:38:"There was an error uploading the file.";s:14:"invalid_number";s:29:"The number format is invalid.";s:16:"number_too_small";s:47:"The number is smaller than the minimum allowed.";s:16:"number_too_large";s:46:"The number is larger than the maximum allowed.";s:23:"quiz_answer_not_correct";s:36:"The answer to the quiz is incorrect.";s:17:"captcha_not_match";s:31:"Your entered code is incorrect.";s:13:"invalid_email";s:38:"The e-mail address entered is invalid.";s:11:"invalid_url";s:19:"The URL is invalid.";s:11:"invalid_tel";s:32:"The telephone number is invalid.";}'),
(6, 4, '_additional_settings', ''),
(7, 4, '_locale', 'en_US'),
(8, 2, '_edit_lock', '1470330258:1'),
(9, 2, '_edit_last', '1'),
(10, 6, '_edit_last', '1'),
(11, 6, '_edit_lock', '1470328348:1'),
(12, 6, '_wp_page_template', 'templates/page-our-project.php'),
(13, 8, '_edit_last', '1'),
(14, 8, '_edit_lock', '1470243761:1'),
(15, 8, '_wp_page_template', 'templates/page-about-template.php'),
(16, 10, '_edit_last', '1'),
(17, 10, '_edit_lock', '1470329342:1'),
(18, 10, '_wp_page_template', 'templates/page-blog-list-template.php'),
(19, 12, '_edit_last', '1'),
(20, 12, '_wp_page_template', 'templates/page-contact-template.php'),
(21, 12, '_edit_lock', '1470240465:1'),
(22, 15, '_menu_item_type', 'custom'),
(23, 15, '_menu_item_menu_item_parent', '0'),
(24, 15, '_menu_item_object_id', '15'),
(25, 15, '_menu_item_object', 'custom'),
(26, 15, '_menu_item_target', ''),
(27, 15, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(28, 15, '_menu_item_xfn', ''),
(29, 15, '_menu_item_url', 'http://futurify.nguyenbui.name.vn/'),
(30, 15, '_menu_item_orphaned', '1469459756'),
(31, 16, '_menu_item_type', 'post_type'),
(32, 16, '_menu_item_menu_item_parent', '0'),
(33, 16, '_menu_item_object_id', '2'),
(34, 16, '_menu_item_object', 'page'),
(35, 16, '_menu_item_target', ''),
(36, 16, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(37, 16, '_menu_item_xfn', ''),
(38, 16, '_menu_item_url', ''),
(40, 17, '_menu_item_type', 'post_type'),
(41, 17, '_menu_item_menu_item_parent', '0'),
(42, 17, '_menu_item_object_id', '12'),
(43, 17, '_menu_item_object', 'page'),
(44, 17, '_menu_item_target', ''),
(45, 17, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(46, 17, '_menu_item_xfn', ''),
(47, 17, '_menu_item_url', ''),
(49, 18, '_menu_item_type', 'post_type'),
(50, 18, '_menu_item_menu_item_parent', '0'),
(51, 18, '_menu_item_object_id', '6'),
(52, 18, '_menu_item_object', 'page'),
(53, 18, '_menu_item_target', ''),
(54, 18, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(55, 18, '_menu_item_xfn', ''),
(56, 18, '_menu_item_url', ''),
(58, 19, '_menu_item_type', 'post_type'),
(59, 19, '_menu_item_menu_item_parent', '0'),
(60, 19, '_menu_item_object_id', '8'),
(61, 19, '_menu_item_object', 'page'),
(62, 19, '_menu_item_target', ''),
(63, 19, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(64, 19, '_menu_item_xfn', ''),
(65, 19, '_menu_item_url', ''),
(67, 20, '_menu_item_type', 'post_type'),
(68, 20, '_menu_item_menu_item_parent', '0'),
(69, 20, '_menu_item_object_id', '10'),
(70, 20, '_menu_item_object', 'page'),
(71, 20, '_menu_item_target', ''),
(72, 20, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(73, 20, '_menu_item_xfn', ''),
(74, 20, '_menu_item_url', ''),
(76, 22, '_edit_last', '1'),
(77, 22, 'field_579630ec7ab31', 'a:11:{s:3:"key";s:19:"field_579630ec7ab31";s:5:"label";s:12:"Contact Form";s:4:"name";s:12:"contact_form";s:4:"type";s:3:"cf7";s:12:"instructions";s:0:"";s:8:"required";s:1:"1";s:10:"allow_null";s:1:"0";s:8:"multiple";s:1:"0";s:7:"disable";a:1:{i:0;s:1:"0";}s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}'),
(78, 22, 'field_5796313c7ab32', 'a:12:{s:3:"key";s:19:"field_5796313c7ab32";s:5:"label";s:10:"Google Map";s:4:"name";s:10:"google_map";s:4:"type";s:10:"google_map";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:10:"center_lat";s:0:"";s:10:"center_lng";s:0:"";s:4:"zoom";s:2:"16";s:6:"height";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:1;}'),
(79, 22, 'field_579631527ab33', 'a:15:{s:3:"key";s:19:"field_579631527ab33";s:5:"label";s:10:"Zoom level";s:4:"name";s:10:"zoom_level";s:4:"type";s:6:"number";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:2:"16";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:4:"step";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:2:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:2;}'),
(81, 22, 'position', 'normal'),
(82, 22, 'layout', 'no_box'),
(83, 22, 'hide_on_screen', ''),
(84, 22, '_edit_lock', '1469953637:1'),
(85, 12, 'contact_form', '4'),
(86, 12, '_contact_form', 'field_579630ec7ab31'),
(87, 12, 'google_map', 'a:3:{s:7:"address";s:69:"21A Gò Dầu, Tân Quý, Tân Phú, HO CHI MINH CITY 700000, Vietnam";s:3:"lat";s:10:"10.7952549";s:3:"lng";s:18:"106.62840000000006";}'),
(88, 12, '_google_map', 'field_5796313c7ab32'),
(89, 12, '_', 'field_579631527ab33'),
(90, 23, '_edit_last', '1'),
(91, 23, '_edit_lock', '1470240492:1'),
(92, 23, '_wp_page_template', 'templates/page-staff-template.php'),
(93, 25, '_edit_last', '1'),
(94, 25, '_edit_lock', '1470064012:1'),
(95, 25, '_wp_page_template', 'templates/page-mvp-template.php'),
(96, 27, '_menu_item_type', 'post_type'),
(97, 27, '_menu_item_menu_item_parent', '19'),
(98, 27, '_menu_item_object_id', '25'),
(99, 27, '_menu_item_object', 'page'),
(100, 27, '_menu_item_target', ''),
(101, 27, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(102, 27, '_menu_item_xfn', ''),
(103, 27, '_menu_item_url', ''),
(105, 28, '_menu_item_type', 'post_type'),
(106, 28, '_menu_item_menu_item_parent', '19'),
(107, 28, '_menu_item_object_id', '23') ;
INSERT INTO `lrpmqdj9_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(108, 28, '_menu_item_object', 'page'),
(109, 28, '_menu_item_target', ''),
(110, 28, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(111, 28, '_menu_item_xfn', ''),
(112, 28, '_menu_item_url', ''),
(121, 34, '_edit_lock', '1470150488:1'),
(122, 34, '_edit_last', '1'),
(124, 34, 'position', 'normal'),
(125, 34, 'layout', 'no_box'),
(126, 34, 'hide_on_screen', ''),
(127, 34, 'field_5796e48c6a441', 'a:12:{s:3:"key";s:19:"field_5796e48c6a441";s:5:"label";s:8:"Position";s:4:"name";s:8:"position";s:4:"type";s:6:"select";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:7:"choices";a:4:{s:15:"Product Manager";s:15:"Product Manager";s:11:"Team Leader";s:11:"Team Leader";s:11:"Team Member";s:11:"Team Member";s:0:"";s:0:"";}s:13:"default_value";s:0:"";s:10:"allow_null";s:1:"0";s:8:"multiple";s:1:"0";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:2:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}'),
(128, 34, 'rule', 'a:5:{s:5:"param";s:7:"ef_user";s:8:"operator";s:2:"==";s:5:"value";s:3:"all";s:8:"order_no";i:0;s:8:"group_no";i:0;}'),
(129, 36, '_edit_lock', '1470129157:1'),
(130, 36, '_edit_last', '1'),
(131, 37, '_wp_attached_file', '2016/07/blg-list-1.png'),
(132, 37, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:322;s:6:"height";i:242;s:4:"file";s:22:"2016/07/blg-list-1.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"blg-list-1-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:22:"blg-list-1-300x225.png";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:9:"image/png";}s:13:"alm-thumbnail";a:4:{s:4:"file";s:22:"blg-list-1-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(133, 36, '_thumbnail_id', '37'),
(136, 39, '_edit_lock', '1470129159:1'),
(137, 39, '_edit_last', '1'),
(138, 40, '_wp_attached_file', '2016/07/group-4-copy-3.png'),
(139, 40, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:322;s:6:"height";i:242;s:4:"file";s:26:"2016/07/group-4-copy-3.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"group-4-copy-3-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:26:"group-4-copy-3-300x225.png";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:9:"image/png";}s:13:"alm-thumbnail";a:4:{s:4:"file";s:26:"group-4-copy-3-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(140, 39, '_thumbnail_id', '40'),
(143, 42, '_edit_lock', '1470129140:1'),
(146, 44, '_wp_attached_file', '2016/07/group-4-copy-6@3x.png'),
(147, 44, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:966;s:6:"height";i:726;s:4:"file";s:29:"2016/07/group-4-copy-6@3x.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:29:"group-4-copy-6@3x-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:29:"group-4-copy-6@3x-300x225.png";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:29:"group-4-copy-6@3x-768x577.png";s:5:"width";i:768;s:6:"height";i:577;s:9:"mime-type";s:9:"image/png";}s:13:"alm-thumbnail";a:4:{s:4:"file";s:29:"group-4-copy-6@3x-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(148, 42, '_thumbnail_id', '44'),
(149, 42, '_edit_last', '1'),
(156, 47, '_edit_lock', '1470129137:1'),
(157, 47, '_edit_last', '1'),
(158, 48, '_wp_attached_file', '2016/07/2@3x.png'),
(159, 48, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:966;s:6:"height";i:726;s:4:"file";s:16:"2016/07/2@3x.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:16:"2@3x-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:16:"2@3x-300x225.png";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:16:"2@3x-768x577.png";s:5:"width";i:768;s:6:"height";i:577;s:9:"mime-type";s:9:"image/png";}s:13:"alm-thumbnail";a:4:{s:4:"file";s:16:"2@3x-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(160, 47, '_thumbnail_id', '48'),
(163, 50, '_edit_lock', '1470129110:1'),
(164, 50, '_edit_last', '1'),
(165, 51, '_wp_attached_file', '2016/07/3@3x.png'),
(166, 51, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:966;s:6:"height";i:726;s:4:"file";s:16:"2016/07/3@3x.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:16:"3@3x-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:16:"3@3x-300x225.png";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:16:"3@3x-768x577.png";s:5:"width";i:768;s:6:"height";i:577;s:9:"mime-type";s:9:"image/png";}s:13:"alm-thumbnail";a:4:{s:4:"file";s:16:"3@3x-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(167, 50, '_thumbnail_id', '51'),
(170, 53, '_edit_lock', '1470128923:1'),
(171, 53, '_edit_last', '1'),
(172, 54, '_wp_attached_file', '2016/07/group-4-copy-4@3x.png'),
(173, 54, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:966;s:6:"height";i:726;s:4:"file";s:29:"2016/07/group-4-copy-4@3x.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:29:"group-4-copy-4@3x-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:29:"group-4-copy-4@3x-300x225.png";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:29:"group-4-copy-4@3x-768x577.png";s:5:"width";i:768;s:6:"height";i:577;s:9:"mime-type";s:9:"image/png";}s:13:"alm-thumbnail";a:4:{s:4:"file";s:29:"group-4-copy-4@3x-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(174, 53, '_thumbnail_id', '54'),
(181, 61, '_edit_lock', '1470319354:1'),
(182, 61, '_edit_last', '1'),
(183, 61, '_thumbnail_id', '54'),
(185, 64, '_edit_lock', '1470489577:1'),
(186, 64, '_edit_last', '1'),
(187, 64, '_wp_page_template', 'default'),
(191, 69, '_edit_lock', '1469953662:1'),
(192, 69, '_edit_last', '1'),
(193, 69, 'field_579ab128af74a', 'a:10:{s:3:"key";s:19:"field_579ab128af74a";s:5:"label";s:5:"Video";s:4:"name";s:5:"video";s:4:"type";s:4:"file";s:12:"instructions";s:0:"";s:8:"required";s:1:"1";s:11:"save_format";s:3:"url";s:7:"library";s:3:"all";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}'),
(195, 69, 'position', 'acf_after_title'),
(196, 69, 'layout', 'no_box'),
(197, 69, 'hide_on_screen', ''),
(198, 70, '_edit_lock', '1469804173:1'),
(199, 70, '_edit_last', '1'),
(200, 71, '_wp_attached_file', '2016/07/project-10.png'),
(201, 71, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:322;s:6:"height";i:242;s:4:"file";s:22:"2016/07/project-10.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"project-10-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:22:"project-10-300x225.png";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:9:"image/png";}s:14:"post-thumbnail";a:4:{s:4:"file";s:22:"project-10-200x200.png";s:5:"width";i:200;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";}s:13:"alm-thumbnail";a:4:{s:4:"file";s:22:"project-10-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(202, 70, '_thumbnail_id', '71'),
(203, 72, '_edit_lock', '1469804762:1'),
(204, 72, '_edit_last', '1'),
(205, 73, '_wp_attached_file', '2016/07/project-9.png'),
(206, 73, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:322;s:6:"height";i:242;s:4:"file";s:21:"2016/07/project-9.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"project-9-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:21:"project-9-300x225.png";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:9:"image/png";}s:14:"post-thumbnail";a:4:{s:4:"file";s:21:"project-9-200x200.png";s:5:"width";i:200;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";}s:13:"alm-thumbnail";a:4:{s:4:"file";s:21:"project-9-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(207, 72, '_thumbnail_id', '73'),
(208, 74, '_edit_lock', '1469804783:1'),
(209, 74, '_edit_last', '1'),
(210, 75, '_wp_attached_file', '2016/07/project-8.png'),
(211, 75, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:322;s:6:"height";i:242;s:4:"file";s:21:"2016/07/project-8.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"project-8-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:21:"project-8-300x225.png";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:9:"image/png";}s:14:"post-thumbnail";a:4:{s:4:"file";s:21:"project-8-200x200.png";s:5:"width";i:200;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";}s:13:"alm-thumbnail";a:4:{s:4:"file";s:21:"project-8-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(212, 74, '_thumbnail_id', '75'),
(213, 76, '_edit_lock', '1469804826:1'),
(214, 76, '_edit_last', '1'),
(215, 77, '_wp_attached_file', '2016/07/project-7.png'),
(216, 77, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:322;s:6:"height";i:242;s:4:"file";s:21:"2016/07/project-7.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"project-7-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:21:"project-7-300x225.png";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:9:"image/png";}s:14:"post-thumbnail";a:4:{s:4:"file";s:21:"project-7-200x200.png";s:5:"width";i:200;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";}s:13:"alm-thumbnail";a:4:{s:4:"file";s:21:"project-7-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(217, 76, '_thumbnail_id', '77'),
(218, 78, '_edit_last', '1'),
(219, 78, '_edit_lock', '1469804877:1'),
(220, 79, '_wp_attached_file', '2016/07/project-5.png'),
(221, 79, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:322;s:6:"height";i:242;s:4:"file";s:21:"2016/07/project-5.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"project-5-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:21:"project-5-300x225.png";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:9:"image/png";}s:14:"post-thumbnail";a:4:{s:4:"file";s:21:"project-5-200x200.png";s:5:"width";i:200;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";}s:13:"alm-thumbnail";a:4:{s:4:"file";s:21:"project-5-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(222, 78, '_thumbnail_id', '79'),
(223, 80, '_edit_lock', '1470149666:1'),
(224, 80, '_edit_last', '1'),
(225, 81, '_wp_attached_file', '2016/07/project-4.png'),
(226, 81, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:324;s:6:"height";i:243;s:4:"file";s:21:"2016/07/project-4.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"project-4-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:21:"project-4-300x225.png";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:9:"image/png";}s:14:"post-thumbnail";a:4:{s:4:"file";s:21:"project-4-200x200.png";s:5:"width";i:200;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";}s:13:"alm-thumbnail";a:4:{s:4:"file";s:21:"project-4-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(227, 80, '_thumbnail_id', '81'),
(228, 82, '_edit_lock', '1469804911:1'),
(229, 82, '_edit_last', '1'),
(230, 83, '_wp_attached_file', '2016/07/project-3.png'),
(231, 83, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:322;s:6:"height";i:242;s:4:"file";s:21:"2016/07/project-3.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"project-3-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:21:"project-3-300x225.png";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:9:"image/png";}s:14:"post-thumbnail";a:4:{s:4:"file";s:21:"project-3-200x200.png";s:5:"width";i:200;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";}s:13:"alm-thumbnail";a:4:{s:4:"file";s:21:"project-3-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(232, 82, '_thumbnail_id', '83'),
(233, 84, '_edit_lock', '1469804928:1'),
(234, 84, '_edit_last', '1'),
(235, 85, '_wp_attached_file', '2016/07/project-2.png'),
(236, 85, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:322;s:6:"height";i:242;s:4:"file";s:21:"2016/07/project-2.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"project-2-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:21:"project-2-300x225.png";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:9:"image/png";}s:14:"post-thumbnail";a:4:{s:4:"file";s:21:"project-2-200x200.png";s:5:"width";i:200;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";}s:13:"alm-thumbnail";a:4:{s:4:"file";s:21:"project-2-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(237, 84, '_thumbnail_id', '85'),
(238, 86, '_edit_lock', '1470483144:1'),
(239, 86, '_edit_last', '1'),
(240, 87, '_wp_attached_file', '2016/07/project-1.png'),
(241, 87, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:322;s:6:"height";i:242;s:4:"file";s:21:"2016/07/project-1.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"project-1-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:21:"project-1-300x225.png";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:9:"image/png";}s:14:"post-thumbnail";a:4:{s:4:"file";s:21:"project-1-200x200.png";s:5:"width";i:200;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";}s:13:"alm-thumbnail";a:4:{s:4:"file";s:21:"project-1-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(242, 86, '_thumbnail_id', '87'),
(243, 88, '_edit_lock', '1469895352:1') ;
INSERT INTO `lrpmqdj9_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(244, 89, '_edit_lock', '1470239443:1'),
(245, 89, '_edit_last', '1'),
(246, 92, 'contact_form', '4'),
(247, 92, '_contact_form', 'field_579630ec7ab31'),
(248, 92, 'google_map', 'a:3:{s:7:"address";s:69:"21A Gò Dầu, Tân Quý, Tân Phú, HO CHI MINH CITY 700000, Vietnam";s:3:"lat";s:10:"10.7952549";s:3:"lng";s:18:"106.62840000000006";}'),
(249, 92, '_google_map', 'field_5796313c7ab32'),
(250, 92, '_', 'field_579631527ab33'),
(252, 93, 'contact_form', '4'),
(253, 93, '_contact_form', 'field_579630ec7ab31'),
(254, 93, 'google_map', 'a:3:{s:7:"address";s:69:"21A Gò Dầu, Tân Quý, Tân Phú, HO CHI MINH CITY 700000, Vietnam";s:3:"lat";s:10:"10.7952549";s:3:"lng";s:18:"106.62840000000006";}'),
(255, 93, '_google_map', 'field_5796313c7ab32'),
(256, 93, '_', 'field_579631527ab33'),
(257, 22, 'rule', 'a:5:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:35:"templates/page-contact-template.php";s:8:"order_no";i:0;s:8:"group_no";i:0;}'),
(258, 94, 'contact_form', '4'),
(259, 94, '_contact_form', 'field_579630ec7ab31'),
(260, 94, 'google_map', 'a:3:{s:7:"address";s:69:"21A Gò Dầu, Tân Quý, Tân Phú, HO CHI MINH CITY 700000, Vietnam";s:3:"lat";s:10:"10.7952549";s:3:"lng";s:18:"106.62840000000006";}'),
(261, 94, '_google_map', 'field_5796313c7ab32'),
(262, 94, 'zoom_level', '16'),
(263, 94, '_zoom_level', 'field_579631527ab33'),
(264, 12, 'zoom_level', '16'),
(265, 12, '_zoom_level', 'field_579631527ab33'),
(266, 95, 'contact_form', '4'),
(267, 95, '_contact_form', 'field_579630ec7ab31'),
(268, 95, 'google_map', 'a:3:{s:7:"address";s:69:"21A Gò Dầu, Tân Quý, Tân Phú, HO CHI MINH CITY 700000, Vietnam";s:3:"lat";s:10:"10.7952549";s:3:"lng";s:18:"106.62840000000006";}'),
(269, 95, '_google_map', 'field_5796313c7ab32'),
(270, 95, 'zoom_level', '18'),
(271, 95, '_zoom_level', 'field_579631527ab33'),
(272, 96, 'contact_form', '4'),
(273, 96, '_contact_form', 'field_579630ec7ab31'),
(274, 96, 'google_map', 'a:3:{s:7:"address";s:69:"21A Gò Dầu, Tân Quý, Tân Phú, HO CHI MINH CITY 700000, Vietnam";s:3:"lat";s:10:"10.7952549";s:3:"lng";s:18:"106.62840000000006";}'),
(275, 96, '_google_map', 'field_5796313c7ab32'),
(276, 96, 'zoom_level', '20'),
(277, 96, '_zoom_level', 'field_579631527ab33'),
(278, 97, 'contact_form', '4'),
(279, 97, '_contact_form', 'field_579630ec7ab31'),
(280, 97, 'google_map', 'a:3:{s:7:"address";s:69:"21A Gò Dầu, Tân Quý, Tân Phú, HO CHI MINH CITY 700000, Vietnam";s:3:"lat";s:10:"10.7952549";s:3:"lng";s:18:"106.62840000000006";}'),
(281, 97, '_google_map', 'field_5796313c7ab32'),
(282, 97, 'zoom_level', '16'),
(283, 97, '_zoom_level', 'field_579631527ab33'),
(284, 98, '_edit_lock', '1470150598:1'),
(285, 98, '_edit_last', '1'),
(286, 99, '_wp_attached_file', '2016/07/team-people.png'),
(287, 99, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:236;s:6:"height";i:236;s:4:"file";s:23:"2016/07/team-people.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"team-people-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:10:"fiat_thumb";a:4:{s:4:"file";s:21:"team-people-60x60.png";s:5:"width";i:60;s:6:"height";i:60;s:9:"mime-type";s:9:"image/png";}s:13:"alm-thumbnail";a:4:{s:4:"file";s:23:"team-people-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(288, 98, '_thumbnail_id', '99'),
(289, 98, '_at_widget', '0'),
(290, 100, '_edit_lock', '1470150618:1'),
(291, 100, '_edit_last', '1'),
(293, 100, '_at_widget', '1'),
(294, 101, '_edit_lock', '1470150643:1'),
(295, 101, '_edit_last', '1'),
(296, 102, '_wp_attached_file', '2016/07/0F0C1AF0-536D-4B4E-8856-0323C452BE54.png'),
(297, 102, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:236;s:6:"height";i:236;s:4:"file";s:48:"2016/07/0F0C1AF0-536D-4B4E-8856-0323C452BE54.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:48:"0F0C1AF0-536D-4B4E-8856-0323C452BE54-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:10:"fiat_thumb";a:4:{s:4:"file";s:46:"0F0C1AF0-536D-4B4E-8856-0323C452BE54-60x60.png";s:5:"width";i:60;s:6:"height";i:60;s:9:"mime-type";s:9:"image/png";}s:13:"alm-thumbnail";a:4:{s:4:"file";s:48:"0F0C1AF0-536D-4B4E-8856-0323C452BE54-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(298, 103, '_wp_attached_file', '2016/07/1CEA7C56-2503-4399-99F4-BDF36BB8035D.png'),
(299, 103, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:236;s:6:"height";i:236;s:4:"file";s:48:"2016/07/1CEA7C56-2503-4399-99F4-BDF36BB8035D.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:48:"1CEA7C56-2503-4399-99F4-BDF36BB8035D-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:10:"fiat_thumb";a:4:{s:4:"file";s:46:"1CEA7C56-2503-4399-99F4-BDF36BB8035D-60x60.png";s:5:"width";i:60;s:6:"height";i:60;s:9:"mime-type";s:9:"image/png";}s:13:"alm-thumbnail";a:4:{s:4:"file";s:48:"1CEA7C56-2503-4399-99F4-BDF36BB8035D-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(300, 104, '_wp_attached_file', '2016/07/7C9E320B-01DC-4E64-B2F5-E064D8B79E35.png'),
(301, 104, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:236;s:6:"height";i:236;s:4:"file";s:48:"2016/07/7C9E320B-01DC-4E64-B2F5-E064D8B79E35.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:48:"7C9E320B-01DC-4E64-B2F5-E064D8B79E35-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:10:"fiat_thumb";a:4:{s:4:"file";s:46:"7C9E320B-01DC-4E64-B2F5-E064D8B79E35-60x60.png";s:5:"width";i:60;s:6:"height";i:60;s:9:"mime-type";s:9:"image/png";}s:13:"alm-thumbnail";a:4:{s:4:"file";s:48:"7C9E320B-01DC-4E64-B2F5-E064D8B79E35-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(302, 105, '_wp_attached_file', '2016/07/28B6543B-5ED4-4B44-8A79-6715CC92381E.png'),
(303, 105, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:236;s:6:"height";i:236;s:4:"file";s:48:"2016/07/28B6543B-5ED4-4B44-8A79-6715CC92381E.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:48:"28B6543B-5ED4-4B44-8A79-6715CC92381E-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:10:"fiat_thumb";a:4:{s:4:"file";s:46:"28B6543B-5ED4-4B44-8A79-6715CC92381E-60x60.png";s:5:"width";i:60;s:6:"height";i:60;s:9:"mime-type";s:9:"image/png";}s:13:"alm-thumbnail";a:4:{s:4:"file";s:48:"28B6543B-5ED4-4B44-8A79-6715CC92381E-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(304, 101, '_thumbnail_id', '105'),
(305, 101, '_at_widget', '1'),
(306, 106, '_edit_lock', '1470150694:1'),
(307, 106, '_edit_last', '1'),
(308, 106, '_thumbnail_id', '102'),
(309, 106, '_at_widget', '1'),
(310, 107, '_edit_lock', '1470150724:1'),
(311, 107, '_edit_last', '1'),
(312, 107, '_thumbnail_id', '103'),
(313, 107, '_at_widget', '1'),
(314, 100, '_thumbnail_id', '104'),
(315, 108, '_edit_lock', '1470150881:1'),
(316, 108, '_edit_last', '1'),
(317, 108, '_thumbnail_id', '105'),
(318, 108, '_at_widget', '1'),
(319, 109, '_edit_lock', '1470150744:1'),
(320, 109, '_edit_last', '1'),
(321, 109, '_thumbnail_id', '102'),
(322, 109, '_at_widget', '1'),
(323, 110, '_edit_lock', '1470150803:1'),
(324, 110, '_edit_last', '1'),
(325, 110, '_thumbnail_id', '103'),
(326, 110, '_at_widget', '1'),
(327, 111, '_edit_lock', '1470150852:1'),
(328, 111, '_edit_last', '1'),
(329, 111, '_thumbnail_id', '104'),
(330, 111, '_at_widget', '1'),
(331, 112, '_edit_lock', '1470150832:1'),
(332, 112, '_edit_last', '1'),
(333, 112, '_thumbnail_id', '99'),
(334, 112, '_at_widget', '1'),
(335, 113, '_edit_lock', '1469938124:1'),
(336, 113, '_edit_last', '1'),
(337, 113, '_at_widget', '1'),
(338, 114, '_edit_lock', '1469938631:1'),
(339, 114, '_edit_last', '1'),
(340, 114, '_at_widget', '1'),
(341, 115, '_edit_lock', '1469943083:1'),
(342, 116, '_edit_lock', '1469944158:1'),
(343, 116, '_edit_last', '1'),
(345, 69, '_at_widget', '1'),
(350, 117, '_wp_attached_file', '2016/07/video-1.mp4') ;
INSERT INTO `lrpmqdj9_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(351, 117, '_wp_attachment_metadata', 'a:9:{s:8:"filesize";i:11481209;s:9:"mime_type";s:15:"video/quicktime";s:6:"length";i:22;s:16:"length_formatted";s:4:"0:22";s:5:"width";i:1920;s:6:"height";i:1080;s:10:"fileformat";s:3:"mp4";s:10:"dataformat";s:9:"quicktime";s:5:"audio";a:7:{s:10:"dataformat";s:3:"mp4";s:5:"codec";s:19:"ISO/IEC 14496-3 AAC";s:11:"sample_rate";d:44100;s:8:"channels";i:2;s:15:"bits_per_sample";i:16;s:8:"lossless";b:0;s:11:"channelmode";s:6:"stereo";}}'),
(352, 118, '_wp_attached_file', '2016/07/video-2.mp4'),
(353, 118, '_wp_attachment_metadata', 'a:9:{s:8:"filesize";i:9536711;s:9:"mime_type";s:15:"video/quicktime";s:6:"length";i:13;s:16:"length_formatted";s:4:"0:13";s:5:"width";i:1920;s:6:"height";i:1080;s:10:"fileformat";s:3:"mp4";s:10:"dataformat";s:9:"quicktime";s:5:"audio";a:7:{s:10:"dataformat";s:3:"mp4";s:5:"codec";s:19:"ISO/IEC 14496-3 AAC";s:11:"sample_rate";d:44100;s:8:"channels";i:2;s:15:"bits_per_sample";i:16;s:8:"lossless";b:0;s:11:"channelmode";s:6:"stereo";}}'),
(354, 119, '_wp_attached_file', '2016/07/video-3.mp4'),
(355, 119, '_wp_attachment_metadata', 'a:9:{s:8:"filesize";i:11200686;s:9:"mime_type";s:15:"video/quicktime";s:6:"length";i:34;s:16:"length_formatted";s:4:"0:34";s:5:"width";i:1920;s:6:"height";i:1080;s:10:"fileformat";s:3:"mp4";s:10:"dataformat";s:9:"quicktime";s:5:"audio";a:7:{s:10:"dataformat";s:3:"mp4";s:5:"codec";s:19:"ISO/IEC 14496-3 AAC";s:11:"sample_rate";d:44100;s:8:"channels";i:2;s:15:"bits_per_sample";i:16;s:8:"lossless";b:0;s:11:"channelmode";s:6:"stereo";}}'),
(356, 120, '_wp_attached_file', '2016/07/video-4.mp4'),
(357, 120, '_wp_attachment_metadata', 'a:9:{s:8:"filesize";i:6613332;s:9:"mime_type";s:15:"video/quicktime";s:6:"length";i:13;s:16:"length_formatted";s:4:"0:13";s:5:"width";i:1920;s:6:"height";i:1080;s:10:"fileformat";s:3:"mp4";s:10:"dataformat";s:9:"quicktime";s:5:"audio";a:7:{s:10:"dataformat";s:3:"mp4";s:5:"codec";s:19:"ISO/IEC 14496-3 AAC";s:11:"sample_rate";d:44100;s:8:"channels";i:2;s:15:"bits_per_sample";i:16;s:8:"lossless";b:0;s:11:"channelmode";s:6:"stereo";}}'),
(358, 121, '_wp_attached_file', '2016/07/video-5.mp4'),
(359, 121, '_wp_attachment_metadata', 'a:9:{s:8:"filesize";i:45408182;s:9:"mime_type";s:15:"video/quicktime";s:6:"length";i:68;s:16:"length_formatted";s:4:"1:08";s:5:"width";i:1920;s:6:"height";i:1080;s:10:"fileformat";s:3:"mp4";s:10:"dataformat";s:9:"quicktime";s:5:"audio";a:7:{s:10:"dataformat";s:3:"mp4";s:5:"codec";s:19:"ISO/IEC 14496-3 AAC";s:11:"sample_rate";d:44100;s:8:"channels";i:2;s:15:"bits_per_sample";i:16;s:8:"lossless";b:0;s:11:"channelmode";s:6:"stereo";}}'),
(360, 116, 'video', '121'),
(361, 116, '_video', 'field_579ab128af74a'),
(362, 116, 'caption', ''),
(363, 116, '_caption', 'field_579d8e0245e64'),
(364, 116, '_at_widget', '1'),
(365, 122, '_edit_lock', '1469944184:1'),
(366, 122, '_edit_last', '1'),
(367, 122, 'video', '120'),
(368, 122, '_video', 'field_579ab128af74a'),
(369, 122, 'caption', ''),
(370, 122, '_caption', 'field_579d8e0245e64'),
(371, 122, '_at_widget', '1'),
(372, 123, '_edit_lock', '1469944199:1'),
(373, 123, '_edit_last', '1'),
(374, 123, 'video', '119'),
(375, 123, '_video', 'field_579ab128af74a'),
(376, 123, 'caption', ''),
(377, 123, '_caption', 'field_579d8e0245e64'),
(378, 123, '_at_widget', '1'),
(379, 124, '_edit_last', '1'),
(380, 124, 'video', '118'),
(381, 124, '_video', 'field_579ab128af74a'),
(382, 124, 'caption', ''),
(383, 124, '_caption', 'field_579d8e0245e64'),
(384, 124, '_at_widget', '1'),
(385, 124, '_edit_lock', '1469944214:1'),
(386, 125, '_edit_lock', '1469954495:1'),
(387, 125, '_edit_last', '1'),
(388, 125, 'video', '117'),
(389, 125, '_video', 'field_579ab128af74a'),
(390, 125, 'caption', '<div class="caption-content">\r\n<h2>OUR MISSION</h2>\r\nWe offer remote world-class engineers and build reliable, scalable and measurable solutions to help you grow and succeed\r\n\r\n</div>'),
(391, 125, '_caption', 'field_579d8e0245e64'),
(392, 125, '_at_widget', '1'),
(395, 127, '_edit_lock', '1470452118:1'),
(396, 127, '_edit_last', '1'),
(397, 127, '_at_widget', '1'),
(398, 69, 'rule', 'a:5:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:10:"home-video";s:8:"order_no";i:0;s:8:"group_no";i:0;}'),
(399, 129, '_edit_lock', '1469954496:1'),
(400, 129, '_edit_last', '1'),
(401, 129, '_at_widget', '1'),
(402, 23, '_at_widget', '1'),
(403, 23, '_wpb_vc_js_status', 'false'),
(404, 23, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(405, 25, '_at_widget', '1'),
(406, 25, '_wpb_vc_js_status', 'false'),
(407, 25, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(408, 16, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(409, 18, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(410, 19, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(411, 28, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(412, 27, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(413, 20, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(414, 17, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(415, 132, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(416, 132, '_edit_lock', '1470058103:1'),
(417, 133, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(418, 133, '_edit_lock', '1470058217:1'),
(419, 133, '_edit_last', '1'),
(422, 133, 'position', 'acf_after_title'),
(423, 133, 'layout', 'no_box'),
(424, 133, 'hide_on_screen', ''),
(425, 133, '_at_widget', '1'),
(426, 133, 'field_579f4ed52cf8f', 'a:11:{s:3:"key";s:19:"field_579f4ed52cf8f";s:5:"label";s:11:"Normal Icon";s:4:"name";s:11:"normal_icon";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";s:1:"1";s:11:"save_format";s:3:"url";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}'),
(427, 133, 'field_579f4f072cf90', 'a:11:{s:3:"key";s:19:"field_579f4f072cf90";s:5:"label";s:10:"Hover Icon";s:4:"name";s:10:"hover_icon";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:11:"save_format";s:3:"url";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:1;}'),
(432, 134, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(433, 134, '_edit_lock', '1470058412:1'),
(434, 134, '_edit_last', '1'),
(437, 133, 'rule', 'a:5:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:5:"staff";s:8:"order_no";i:0;s:8:"group_no";i:0;}'),
(438, 133, 'rule', 'a:5:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:3:"mvp";s:8:"order_no";i:0;s:8:"group_no";i:1;}'),
(439, 135, '_wp_attached_file', '2016/08/line-models.png'),
(440, 135, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:63;s:6:"height";i:63;s:4:"file";s:23:"2016/08/line-models.png";s:5:"sizes";a:1:{s:10:"fiat_thumb";a:4:{s:4:"file";s:21:"line-models-60x60.png";s:5:"width";i:60;s:6:"height";i:60;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(441, 136, '_wp_attached_file', '2016/08/red-models.png'),
(442, 136, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:64;s:6:"height";i:63;s:4:"file";s:22:"2016/08/red-models.png";s:5:"sizes";a:1:{s:10:"fiat_thumb";a:4:{s:4:"file";s:20:"red-models-60x59.png";s:5:"width";i:60;s:6:"height";i:59;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(443, 134, 'normal_icon', '135'),
(444, 134, '_normal_icon', 'field_579f4ed52cf8f'),
(445, 134, 'hover_icon', '136'),
(446, 134, '_hover_icon', 'field_579f4f072cf90'),
(447, 134, '_at_widget', '1'),
(448, 137, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(449, 137, '_edit_lock', '1470058549:1'),
(450, 137, '_edit_last', '1'),
(451, 138, '_wp_attached_file', '2016/08/line-star-talented.png'),
(452, 138, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:63;s:6:"height";i:63;s:4:"file";s:30:"2016/08/line-star-talented.png";s:5:"sizes";a:1:{s:10:"fiat_thumb";a:4:{s:4:"file";s:28:"line-star-talented-60x60.png";s:5:"width";i:60;s:6:"height";i:60;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(453, 139, '_wp_attached_file', '2016/08/red-star-talented.png'),
(454, 139, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:64;s:6:"height";i:63;s:4:"file";s:29:"2016/08/red-star-talented.png";s:5:"sizes";a:1:{s:10:"fiat_thumb";a:4:{s:4:"file";s:27:"red-star-talented-60x59.png";s:5:"width";i:60;s:6:"height";i:59;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(455, 137, 'normal_icon', '138'),
(456, 137, '_normal_icon', 'field_579f4ed52cf8f'),
(457, 137, 'hover_icon', '139'),
(458, 137, '_hover_icon', 'field_579f4f072cf90'),
(459, 137, '_at_widget', '1'),
(460, 140, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}') ;
INSERT INTO `lrpmqdj9_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(461, 140, '_edit_lock', '1470060394:1'),
(462, 140, '_edit_last', '1'),
(463, 141, '_wp_attached_file', '2016/08/line-gear.png'),
(464, 141, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:62;s:6:"height";i:63;s:4:"file";s:21:"2016/08/line-gear.png";s:5:"sizes";a:1:{s:10:"fiat_thumb";a:4:{s:4:"file";s:19:"line-gear-60x61.png";s:5:"width";i:60;s:6:"height";i:61;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(465, 142, '_wp_attached_file', '2016/08/red-gear.png'),
(466, 142, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:62;s:6:"height";i:63;s:4:"file";s:20:"2016/08/red-gear.png";s:5:"sizes";a:1:{s:10:"fiat_thumb";a:4:{s:4:"file";s:18:"red-gear-60x61.png";s:5:"width";i:60;s:6:"height";i:61;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(467, 140, 'normal_icon', '141'),
(468, 140, '_normal_icon', 'field_579f4ed52cf8f'),
(469, 140, 'hover_icon', '142'),
(470, 140, '_hover_icon', 'field_579f4f072cf90'),
(471, 140, '_at_widget', '1'),
(472, 143, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(473, 143, '_edit_lock', '1470058699:1'),
(474, 143, '_edit_last', '1'),
(475, 144, '_wp_attached_file', '2016/08/line-repeat.png'),
(476, 144, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:61;s:6:"height";i:60;s:4:"file";s:23:"2016/08/line-repeat.png";s:5:"sizes";a:1:{s:10:"fiat_thumb";a:4:{s:4:"file";s:21:"line-repeat-60x59.png";s:5:"width";i:60;s:6:"height";i:59;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(477, 145, '_wp_attached_file', '2016/08/red-repeat.png'),
(478, 145, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:60;s:6:"height";i:60;s:4:"file";s:22:"2016/08/red-repeat.png";s:5:"sizes";a:1:{s:10:"fiat_thumb";a:4:{s:4:"file";s:20:"red-repeat-60x60.png";s:5:"width";i:60;s:6:"height";i:60;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(479, 143, 'normal_icon', '144'),
(480, 143, '_normal_icon', 'field_579f4ed52cf8f'),
(481, 143, 'hover_icon', '145'),
(482, 143, '_hover_icon', 'field_579f4f072cf90'),
(483, 143, '_at_widget', '1'),
(484, 146, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(485, 146, '_edit_lock', '1470058787:1'),
(486, 146, '_edit_last', '1'),
(487, 147, '_wp_attached_file', '2016/08/line-hand.png'),
(488, 147, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:71;s:6:"height";i:70;s:4:"file";s:21:"2016/08/line-hand.png";s:5:"sizes";a:1:{s:10:"fiat_thumb";a:4:{s:4:"file";s:19:"line-hand-60x59.png";s:5:"width";i:60;s:6:"height";i:59;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(489, 148, '_wp_attached_file', '2016/08/red-hand.png'),
(490, 148, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:71;s:6:"height";i:70;s:4:"file";s:20:"2016/08/red-hand.png";s:5:"sizes";a:1:{s:10:"fiat_thumb";a:4:{s:4:"file";s:18:"red-hand-60x59.png";s:5:"width";i:60;s:6:"height";i:59;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(491, 146, 'normal_icon', '147'),
(492, 146, '_normal_icon', 'field_579f4ed52cf8f'),
(493, 146, 'hover_icon', '148'),
(494, 146, '_hover_icon', 'field_579f4f072cf90'),
(495, 146, '_at_widget', '1'),
(496, 149, '_wp_attached_file', '2016/08/project-6.png'),
(497, 149, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:322;s:6:"height";i:242;s:4:"file";s:21:"2016/08/project-6.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"project-6-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:21:"project-6-300x225.png";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:9:"image/png";}s:10:"fiat_thumb";a:4:{s:4:"file";s:19:"project-6-60x45.png";s:5:"width";i:60;s:6:"height";i:45;s:9:"mime-type";s:9:"image/png";}s:13:"alm-thumbnail";a:4:{s:4:"file";s:21:"project-6-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(500, 155, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(501, 155, '_edit_lock', '1470061795:1'),
(502, 155, '_edit_last', '1'),
(503, 156, '_wp_attached_file', '2016/08/line-tag.png'),
(504, 156, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:47;s:6:"height";i:48;s:4:"file";s:20:"2016/08/line-tag.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(505, 157, '_wp_attached_file', '2016/08/red-tag.png'),
(506, 157, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:47;s:6:"height";i:48;s:4:"file";s:19:"2016/08/red-tag.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(507, 155, 'normal_icon', '156'),
(508, 155, '_normal_icon', 'field_579f4ed52cf8f'),
(509, 155, 'hover_icon', '157'),
(510, 155, '_hover_icon', 'field_579f4f072cf90'),
(511, 155, '_at_widget', '1'),
(512, 158, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(513, 158, '_edit_lock', '1470062501:1'),
(514, 158, '_edit_last', '1'),
(517, 160, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(518, 161, '_wp_attached_file', '2016/08/red-browser.png'),
(519, 161, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:41;s:6:"height";i:30;s:4:"file";s:23:"2016/08/red-browser.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(520, 160, '_edit_lock', '1470062700:1'),
(521, 162, '_wp_attached_file', '2016/08/line-calendar.png'),
(522, 162, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:46;s:6:"height";i:41;s:4:"file";s:25:"2016/08/line-calendar.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(523, 158, 'normal_icon', '162'),
(524, 158, '_normal_icon', 'field_579f4ed52cf8f'),
(525, 158, 'hover_icon', '161'),
(526, 158, '_hover_icon', 'field_579f4f072cf90'),
(527, 158, '_at_widget', '1'),
(528, 163, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(529, 163, '_edit_lock', '1470062632:1'),
(530, 163, '_edit_last', '1'),
(531, 164, '_wp_attached_file', '2016/08/line-tshirt.png'),
(532, 164, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:42;s:6:"height";i:45;s:4:"file";s:23:"2016/08/line-tshirt.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(533, 165, '_wp_attached_file', '2016/08/red-tshirt.png'),
(534, 165, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:45;s:6:"height";i:48;s:4:"file";s:22:"2016/08/red-tshirt.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(535, 163, 'normal_icon', '164'),
(536, 163, '_normal_icon', 'field_579f4ed52cf8f'),
(537, 163, 'hover_icon', '165'),
(538, 163, '_hover_icon', 'field_579f4f072cf90'),
(539, 163, '_at_widget', '1'),
(540, 166, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(541, 166, '_edit_lock', '1470062828:1'),
(542, 166, '_edit_last', '1'),
(543, 167, '_wp_attached_file', '2016/08/red-steps.png'),
(544, 167, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:41;s:6:"height";i:40;s:4:"file";s:21:"2016/08/red-steps.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(545, 168, '_wp_attached_file', '2016/08/line-steps.png'),
(546, 168, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:41;s:6:"height";i:40;s:4:"file";s:22:"2016/08/line-steps.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(547, 166, 'normal_icon', '168'),
(548, 166, '_normal_icon', 'field_579f4ed52cf8f'),
(549, 166, 'hover_icon', '167'),
(550, 166, '_hover_icon', 'field_579f4f072cf90'),
(551, 166, '_at_widget', '1'),
(552, 169, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(553, 169, '_edit_lock', '1470062908:1'),
(554, 169, '_edit_last', '1'),
(555, 170, '_wp_attached_file', '2016/08/line-browser.png'),
(556, 170, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:41;s:6:"height";i:30;s:4:"file";s:24:"2016/08/line-browser.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(557, 171, '_wp_attached_file', '2016/08/red-browser-1.png'),
(558, 171, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:41;s:6:"height";i:30;s:4:"file";s:25:"2016/08/red-browser-1.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(559, 169, 'normal_icon', '170'),
(560, 169, '_normal_icon', 'field_579f4ed52cf8f'),
(561, 169, 'hover_icon', '171'),
(562, 169, '_hover_icon', 'field_579f4f072cf90'),
(563, 169, '_at_widget', '1'),
(564, 172, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}') ;
INSERT INTO `lrpmqdj9_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(565, 172, '_edit_lock', '1470062998:1'),
(566, 172, '_edit_last', '1'),
(567, 173, '_wp_attached_file', '2016/08/red-magnifying.png'),
(568, 173, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:39;s:6:"height";i:39;s:4:"file";s:26:"2016/08/red-magnifying.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(569, 174, '_wp_attached_file', '2016/08/line-magnifying.png'),
(570, 174, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:39;s:6:"height";i:39;s:4:"file";s:27:"2016/08/line-magnifying.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(571, 172, 'normal_icon', '174'),
(572, 172, '_normal_icon', 'field_579f4ed52cf8f'),
(573, 172, 'hover_icon', '173'),
(574, 172, '_hover_icon', 'field_579f4f072cf90'),
(575, 172, '_at_widget', '1'),
(576, 175, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(577, 175, '_edit_lock', '1470063065:1'),
(578, 175, '_edit_last', '1'),
(579, 176, '_wp_attached_file', '2016/08/line-star.png'),
(580, 176, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:45;s:6:"height";i:45;s:4:"file";s:21:"2016/08/line-star.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(581, 177, '_wp_attached_file', '2016/08/red-star.png'),
(582, 177, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:45;s:6:"height";i:45;s:4:"file";s:20:"2016/08/red-star.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(583, 175, 'normal_icon', '176'),
(584, 175, '_normal_icon', 'field_579f4ed52cf8f'),
(585, 175, 'hover_icon', '177'),
(586, 175, '_hover_icon', 'field_579f4f072cf90'),
(587, 175, '_at_widget', '1'),
(588, 178, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(589, 178, '_edit_lock', '1470159930:1'),
(590, 178, '_edit_last', '1'),
(593, 61, '_at_widget', '1'),
(594, 61, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(597, 182, '_wp_attached_file', '2016/07/group-1.png'),
(598, 182, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1002;s:6:"height";i:564;s:4:"file";s:19:"2016/07/group-1.png";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"group-1-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:19:"group-1-300x169.png";s:5:"width";i:300;s:6:"height";i:169;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:19:"group-1-768x432.png";s:5:"width";i:768;s:6:"height";i:432;s:9:"mime-type";s:9:"image/png";}s:10:"fiat_thumb";a:4:{s:4:"file";s:17:"group-1-60x34.png";s:5:"width";i:60;s:6:"height";i:34;s:9:"mime-type";s:9:"image/png";}s:13:"alm-thumbnail";a:4:{s:4:"file";s:19:"group-1-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(605, 53, '_at_widget', '1'),
(606, 53, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(609, 50, '_at_widget', '1'),
(610, 50, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(613, 42, '_at_widget', '1'),
(614, 42, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(617, 47, '_at_widget', '1'),
(618, 47, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(621, 39, '_at_widget', '1'),
(622, 39, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(625, 36, '_at_widget', '1'),
(626, 36, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(627, 98, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(628, 191, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(629, 191, '_edit_lock', '1470159822:1'),
(630, 191, '_edit_last', '1'),
(631, 191, 'field_57a0b7f4a5a6d', 'a:14:{s:3:"key";s:19:"field_57a0b7f4a5a6d";s:5:"label";s:8:"Position";s:4:"name";s:8:"position";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:2:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}'),
(633, 191, 'position', 'acf_after_title'),
(634, 191, 'layout', 'no_box'),
(635, 191, 'hide_on_screen', ''),
(636, 98, 'position', 'Product Manager'),
(637, 98, '_position', 'field_57a0b7f4a5a6d'),
(638, 100, 'position', 'Member'),
(639, 100, '_position', 'field_57a0b7f4a5a6d'),
(640, 100, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(641, 101, 'position', 'Team Leader'),
(642, 101, '_position', 'field_57a0b7f4a5a6d'),
(643, 101, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(644, 106, 'position', 'Designer'),
(645, 106, '_position', 'field_57a0b7f4a5a6d'),
(646, 106, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(647, 107, 'position', 'Tester'),
(648, 107, '_position', 'field_57a0b7f4a5a6d'),
(649, 107, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(650, 109, 'position', 'Member'),
(651, 109, '_position', 'field_57a0b7f4a5a6d'),
(652, 109, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(653, 110, 'position', 'Member'),
(654, 110, '_position', 'field_57a0b7f4a5a6d'),
(655, 110, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(656, 112, 'position', 'Team Leader'),
(657, 112, '_position', 'field_57a0b7f4a5a6d'),
(658, 112, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(659, 111, 'position', 'Technical Leader'),
(660, 111, '_position', 'field_57a0b7f4a5a6d'),
(661, 111, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(662, 108, 'position', 'Project Manager'),
(663, 108, '_position', 'field_57a0b7f4a5a6d'),
(664, 108, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(669, 4, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(670, 194, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(671, 195, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(672, 195, '_edit_lock', '1470159779:1'),
(673, 195, '_edit_last', '1'),
(675, 191, 'rule', 'a:5:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:6:"member";s:8:"order_no";i:0;s:8:"group_no";i:0;}'),
(676, 195, 'position', ''),
(677, 195, '_position', 'field_57a0b7f4a5a6d'),
(678, 178, 'position', ''),
(679, 178, '_position', 'field_57a0b7f4a5a6d'),
(680, 197, 'contact_form', '4'),
(681, 197, '_contact_form', 'field_579630ec7ab31'),
(682, 197, 'google_map', 'a:3:{s:7:"address";s:69:"21A Gò Dầu, Tân Quý, Tân Phú, HO CHI MINH CITY 700000, Vietnam";s:3:"lat";s:10:"10.7952549";s:3:"lng";s:18:"106.62840000000006";}'),
(683, 197, '_google_map', 'field_5796313c7ab32'),
(684, 197, 'zoom_level', '16'),
(685, 197, '_zoom_level', 'field_579631527ab33'),
(686, 12, '_wpb_vc_js_status', 'false'),
(687, 12, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(688, 198, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(689, 198, '_edit_lock', '1470488387:1'),
(690, 198, '_edit_last', '1') ;
INSERT INTO `lrpmqdj9_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(691, 198, 'field_57a34eaa52028', 'a:14:{s:3:"key";s:19:"field_57a34eaa52028";s:5:"label";s:23:"Tittle (Action To Call)";s:4:"name";s:6:"tittle";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:52:"WE\'RE EXCITED TO LEARN MORE ABOUT YOU AND YOUR NEEDS";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}'),
(693, 198, 'position', 'acf_after_title'),
(694, 198, 'layout', 'no_box'),
(695, 198, 'hide_on_screen', ''),
(696, 199, '_wp_attached_file', '2016/07/home-introdution-img.png'),
(697, 199, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:406;s:6:"height";i:502;s:4:"file";s:32:"2016/07/home-introdution-img.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:32:"home-introdution-img-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:32:"home-introdution-img-243x300.png";s:5:"width";i:243;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:10:"fiat_thumb";a:4:{s:4:"file";s:30:"home-introdution-img-60x74.png";s:5:"width";i:60;s:6:"height";i:74;s:9:"mime-type";s:9:"image/png";}s:13:"alm-thumbnail";a:4:{s:4:"file";s:32:"home-introdution-img-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(698, 64, '_thumbnail_id', '199'),
(699, 64, 'tittle', 'WE\'RE EXCITED TO LEARN MORE ABOUT YOU AND YOUR NEEDS'),
(700, 64, '_tittle', 'field_57a34eaa52028'),
(701, 64, '_wpb_vc_js_status', 'false'),
(702, 64, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(703, 200, 'tittle', 'WE\'RE EXCITED TO LEARN MORE ABOUT YOU AND YOUR NEEDS'),
(704, 200, '_tittle', 'field_57a34eaa52028'),
(705, 201, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(706, 201, '_edit_lock', '1470328770:1'),
(707, 201, '_edit_last', '1'),
(711, 201, 'field_57a35af12d28b', 'a:8:{s:3:"key";s:19:"field_57a35af12d28b";s:5:"label";s:3:"Top";s:4:"name";s:0:"";s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}'),
(713, 201, 'position', 'normal'),
(714, 201, 'layout', 'no_box'),
(715, 201, 'hide_on_screen', 'a:2:{i:0;s:11:"the_content";i:1;s:14:"featured_image";}'),
(716, 201, 'field_57a35b4a053af', 'a:14:{s:3:"key";s:19:"field_57a35b4a053af";s:5:"label";s:9:"Top Title";s:4:"name";s:9:"top_title";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:1;}'),
(720, 202, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(721, 202, '_edit_lock', '1470324349:1'),
(722, 202, '_edit_last', '1'),
(723, 202, 'field_57a35eee46300', 'a:8:{s:3:"key";s:19:"field_57a35eee46300";s:5:"label";s:4:"Tab2";s:4:"name";s:0:"";s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:2:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}'),
(724, 202, 'rule', 'a:5:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:33:"templates/page-about-template.php";s:8:"order_no";i:0;s:8:"group_no";i:0;}'),
(725, 202, 'position', 'normal'),
(726, 202, 'layout', 'no_box'),
(727, 202, 'hide_on_screen', ''),
(728, 202, '_wp_trash_meta_status', 'publish'),
(729, 202, '_wp_trash_meta_time', '1470324522'),
(730, 202, '_wp_desired_post_slug', 'acf_about2'),
(732, 201, 'field_57a35f3ddfaaa', 'a:11:{s:3:"key";s:19:"field_57a35f3ddfaaa";s:5:"label";s:11:"Editor Left";s:4:"name";s:10:"e_top_left";s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:7:"toolbar";s:4:"full";s:12:"media_upload";s:3:"yes";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:2;}'),
(733, 201, 'field_57a35fa5dfaab', 'a:11:{s:3:"key";s:19:"field_57a35fa5dfaab";s:5:"label";s:5:"Image";s:4:"name";s:9:"image_top";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:11:"save_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:4;}'),
(735, 201, 'field_57a3621c24e7b', 'a:11:{s:3:"key";s:19:"field_57a3621c24e7b";s:5:"label";s:12:"Editor Right";s:4:"name";s:11:"e_top_right";s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:7:"toolbar";s:4:"full";s:12:"media_upload";s:3:"yes";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:3;}'),
(738, 203, 'top_title', ''),
(739, 203, '_top_title', 'field_57a35b4a053af'),
(740, 203, 'e_top_left', '<section class="section-left">\r\n<h2>We gonna tell you a story about Futurify where we call our second home. Say hello with a young software engineer, Tri Ho, version 2012. After 3 years of working for University of Ottawa while studying and 8 months at Koneka after graduation as a web developer, he went back to Vietnam. Flame of desire and passion of youth inspirit him to build something.</h2>\r\n</section>'),
(741, 203, '_e_top_left', 'field_57a35f3ddfaaa'),
(742, 203, 'e_top-right', '<section class="section-right">\r\n<h2>“Behind every success there is a story</h2>\r\n<h2>with a humble start, some failures, some</h2>\r\n<h2>successes and an ongoing happiness.”</h2>\r\n<h5>JOHN VU - PRODUCT MANANGER</h5>\r\n</section>'),
(743, 203, '_e_top-right', 'field_57a3621c24e7b'),
(744, 203, 'image', '149'),
(745, 203, '_image', 'field_57a35fa5dfaab'),
(746, 2, '_wpb_vc_js_status', 'false'),
(747, 2, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(748, 2, 'top_title', 'THE<br>FUTURIFY<br>STORIES'),
(749, 2, '_top_title', 'field_57a35b4a053af'),
(750, 2, 'e_top_left', '<section class="section-left">\r\n<h2>We gonna tell you a story about Futurify where we call our second home. Say hello with a young software engineer, Tri Ho, version 2012. After 3 years of working for University of Ottawa while studying and 8 months at Koneka after graduation as a web developer, he went back to Vietnam. Flame of desire and passion of youth inspirit him to build something.</h2>\r\n</section>'),
(751, 2, '_e_top_left', 'field_57a35f3ddfaaa'),
(752, 2, 'e_top-right', '<section class="section-right">\r\n<h2>“Behind every success there is a story</h2>\r\n<h2>with a humble start, some failures, some</h2>\r\n<h2>successes and an ongoing happiness.”</h2>\r\n<h5>JOHN VU - PRODUCT MANANGER</h5>\r\n</section>'),
(753, 2, '_e_top-right', 'field_57a3621c24e7b'),
(754, 2, 'image', '149'),
(755, 2, '_image', 'field_57a35fa5dfaab'),
(757, 204, 'top_title', 'THE FUTURIFY STORIES'),
(758, 204, '_top_title', 'field_57a35b4a053af'),
(759, 204, 'e_top_left', '<section class="section-left">\r\n<h2>We gonna tell you a story about Futurify where we call our second home. Say hello with a young software engineer, Tri Ho, version 2012. After 3 years of working for University of Ottawa while studying and 8 months at Koneka after graduation as a web developer, he went back to Vietnam. Flame of desire and passion of youth inspirit him to build something.</h2>\r\n</section>'),
(760, 204, '_e_top_left', 'field_57a35f3ddfaaa'),
(761, 204, 'e_top-right', '<section class="section-right">\r\n<h2>“Behind every success there is a story</h2>\r\n<h2>with a humble start, some failures, some</h2>\r\n<h2>successes and an ongoing happiness.”</h2>\r\n<h5>JOHN VU - PRODUCT MANANGER</h5>\r\n</section>'),
(762, 204, '_e_top-right', 'field_57a3621c24e7b'),
(763, 204, 'image', '149'),
(764, 204, '_image', 'field_57a35fa5dfaab'),
(765, 205, 'top_title', 'THE<br>FUTURIFY STORIES'),
(766, 205, '_top_title', 'field_57a35b4a053af'),
(767, 205, 'e_top_left', '<section class="section-left">\r\n<h2>We gonna tell you a story about Futurify where we call our second home. Say hello with a young software engineer, Tri Ho, version 2012. After 3 years of working for University of Ottawa while studying and 8 months at Koneka after graduation as a web developer, he went back to Vietnam. Flame of desire and passion of youth inspirit him to build something.</h2>\r\n</section>'),
(768, 205, '_e_top_left', 'field_57a35f3ddfaaa'),
(769, 205, 'e_top-right', '<section class="section-right">\r\n<h2>“Behind every success there is a story</h2>\r\n<h2>with a humble start, some failures, some</h2>\r\n<h2>successes and an ongoing happiness.”</h2>\r\n<h5>JOHN VU - PRODUCT MANANGER</h5>\r\n</section>'),
(770, 205, '_e_top-right', 'field_57a3621c24e7b'),
(771, 205, 'image', '149'),
(772, 205, '_image', 'field_57a35fa5dfaab'),
(773, 206, 'top_title', 'THE<br>FUTURIFY<br>STORIES'),
(774, 206, '_top_title', 'field_57a35b4a053af'),
(775, 206, 'e_top_left', '<section class="section-left">\r\n<h2>We gonna tell you a story about Futurify where we call our second home. Say hello with a young software engineer, Tri Ho, version 2012. After 3 years of working for University of Ottawa while studying and 8 months at Koneka after graduation as a web developer, he went back to Vietnam. Flame of desire and passion of youth inspirit him to build something.</h2>\r\n</section>'),
(776, 206, '_e_top_left', 'field_57a35f3ddfaaa'),
(777, 206, 'e_top-right', '<section class="section-right">\r\n<h2>“Behind every success there is a story</h2>\r\n<h2>with a humble start, some failures, some</h2>\r\n<h2>successes and an ongoing happiness.”</h2>\r\n<h5>JOHN VU - PRODUCT MANANGER</h5>\r\n</section>'),
(778, 206, '_e_top-right', 'field_57a3621c24e7b'),
(779, 206, 'image', '149'),
(780, 206, '_image', 'field_57a35fa5dfaab'),
(782, 207, 'top_title', 'THE<br>FUTURIFY<br>STORIES'),
(783, 207, '_top_title', 'field_57a35b4a053af'),
(784, 207, 'e_top_left', '<section class="section-left">\r\n<h2>We gonna tell you a story about Futurify where we call our second home. Say hello with a young software engineer, Tri Ho, version 2012. After 3 years of working for University of Ottawa while studying and 8 months at Koneka after graduation as a web developer, he went back to Vietnam. Flame of desire and passion of youth inspirit him to build something.</h2>\r\n</section>'),
(785, 207, '_e_top_left', 'field_57a35f3ddfaaa'),
(786, 207, 'e_top_right', '<section class="section-right">\r\n<h2>“Behind every success there is a story</h2>\r\n<h2>with a humble start, some failures, some</h2>\r\n<h2>successes and an ongoing happiness.”</h2>\r\n<h5>JOHN VU - PRODUCT MANANGER</h5>\r\n</section>'),
(787, 207, '_e_top_right', 'field_57a3621c24e7b'),
(788, 207, 'image', '149'),
(789, 207, '_image', 'field_57a35fa5dfaab'),
(790, 2, 'e_top_right', '<section class="section-right">\r\n<h2>“Behind every success there is a story</h2>\r\n<h2>with a humble start, some failures, some</h2>\r\n<h2>successes and an ongoing happiness.”</h2>\r\n<h5>JOHN VU - PRODUCT MANANGER</h5>\r\n</section>'),
(791, 2, '_e_top_right', 'field_57a3621c24e7b'),
(793, 208, 'top_title', 'THE<br>FUTURIFY<br>STORIES'),
(794, 208, '_top_title', 'field_57a35b4a053af'),
(795, 208, 'e_top_left', '<section class="section-left">\r\n<h2>We gonna tell you a story about Futurify where we call our second home. Say hello with a young software engineer, Tri Ho, version 2012. After 3 years of working for University of Ottawa while studying and 8 months at Koneka after graduation as a web developer, he went back to Vietnam. Flame of desire and passion of youth inspirit him to build something.</h2>\r\n</section>'),
(796, 208, '_e_top_left', 'field_57a35f3ddfaaa'),
(797, 208, 'e_top_right', '<section class="section-right">\r\n<h2>“Behind every success there is a story</h2>\r\n<h2>with a humble start, some failures, some</h2>\r\n<h2>successes and an ongoing happiness.”</h2>\r\n<h5>JOHN VU - PRODUCT MANANGER</h5>\r\n</section>'),
(798, 208, '_e_top_right', 'field_57a3621c24e7b'),
(799, 208, 'image_top', '149'),
(800, 208, '_image_top', 'field_57a35fa5dfaab'),
(801, 2, 'image_top', '182'),
(802, 2, '_image_top', 'field_57a35fa5dfaab'),
(803, 201, 'field_57a367129bbef', 'a:8:{s:3:"key";s:19:"field_57a367129bbef";s:5:"label";s:6:"Middle";s:4:"name";s:0:"";s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:5;}'),
(806, 201, 'field_57a3676dfe130', 'a:11:{s:3:"key";s:19:"field_57a3676dfe130";s:5:"label";s:11:"Editor Left";s:4:"name";s:13:"e_middle_left";s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:7:"toolbar";s:4:"full";s:12:"media_upload";s:3:"yes";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:6;}'),
(807, 201, 'field_57a36853fe131', 'a:11:{s:3:"key";s:19:"field_57a36853fe131";s:5:"label";s:12:"Editor Right";s:4:"name";s:14:"e_middle_right";s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:7:"toolbar";s:4:"full";s:12:"media_upload";s:3:"yes";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:7;}') ;
INSERT INTO `lrpmqdj9_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(808, 201, 'field_57a36873fe132', 'a:11:{s:3:"key";s:19:"field_57a36873fe132";s:5:"label";s:5:"Image";s:4:"name";s:12:"image_middle";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:11:"save_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:8;}'),
(809, 201, 'field_57a3689efe133', 'a:11:{s:3:"key";s:19:"field_57a3689efe133";s:5:"label";s:13:"Editor Middle";s:4:"name";s:8:"e_middle";s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:7:"toolbar";s:4:"full";s:12:"media_upload";s:3:"yes";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:9;}'),
(811, 209, '_wp_attached_file', '2016/07/main-people.png'),
(812, 209, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:404;s:6:"height";i:538;s:4:"file";s:23:"2016/07/main-people.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"main-people-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:23:"main-people-225x300.png";s:5:"width";i:225;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:10:"fiat_thumb";a:4:{s:4:"file";s:21:"main-people-60x80.png";s:5:"width";i:60;s:6:"height";i:80;s:9:"mime-type";s:9:"image/png";}s:13:"alm-thumbnail";a:4:{s:4:"file";s:23:"main-people-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(813, 210, 'top_title', 'THE<br>FUTURIFY<br>STORIES'),
(814, 210, '_top_title', 'field_57a35b4a053af'),
(815, 210, 'e_top_left', '<section class="section-left">\r\n<h2>We gonna tell you a story about Futurify where we call our second home. Say hello with a young software engineer, Tri Ho, version 2012. After 3 years of working for University of Ottawa while studying and 8 months at Koneka after graduation as a web developer, he went back to Vietnam. Flame of desire and passion of youth inspirit him to build something.</h2>\r\n</section>'),
(816, 210, '_e_top_left', 'field_57a35f3ddfaaa'),
(817, 210, 'e_top_right', '<section class="section-right">\r\n<h2>“Behind every success there is a story</h2>\r\n<h2>with a humble start, some failures, some</h2>\r\n<h2>successes and an ongoing happiness.”</h2>\r\n<h5>JOHN VU - PRODUCT MANANGER</h5>\r\n</section>'),
(818, 210, '_e_top_right', 'field_57a3621c24e7b'),
(819, 210, 'image_top', '149'),
(820, 210, '_image_top', 'field_57a35fa5dfaab'),
(821, 210, 'e_middle_left', '<section class="bl-des-left">\r\n<h2>Of course, Tri understood that he could not run a long and challenging road by himself. Dung Dang, one of his close friends since they were in high school, would be the perfect missing piece of the puzzle. Dung is a talented, quick-witted and hard-working software engineer who was working as a team lead at ELCA, a large and well-known technology company in Vietnam. However, Dung believes in the vision, “building world-class engineering team.</h2>\r\n</section>'),
(822, 210, '_e_middle_left', 'field_57a3676dfe130'),
(823, 210, 'e_middle_right', '<section class="bl-des-right">\r\n<h2>A great opportunity came from his employer Koneka, who wanted to start a remote team in Vietnam at that time. With the mindset “always start with a customer”, he told himself, “It\'s time to kickoff a new and exciting journey."</h2>\r\n</section>'),
(824, 210, '_e_middle_right', 'field_57a36853fe131'),
(825, 210, 'image_middle', '209'),
(826, 210, '_image_middle', 'field_57a36873fe132'),
(827, 210, 'e_middle', '<div class="bl-about-main-people-des-content">\r\n<h2>Having a paying customer and smart,</h2>\r\n<h2>dedicated and determined founders,</h2>\r\n<h2>Futurify was formed on June 1st, 2012.</h2>\r\n<h5>JOHN VU - PRODUCT MANANGER</h5>\r\nNot only our customers but also our members want to be successful. If our members are talented and are success hunters, our customers would be benefit from these talents tremendously. It has shown to our elite management team: Vu Le, head of Human Resource and company culture, Tan Hoang, head of outsource team, and Khoa Nguyen, head of our amazing Point of Sales system department.\r\n\r\n</div>'),
(828, 210, '_e_middle', 'field_57a3689efe133'),
(829, 2, 'e_middle_left', '<section class="bl-des-left">\r\n<h2>Of course, Tri understood that he could not run a long and challenging road by himself. Dung Dang, one of his close friends since they were in high school, would be the perfect missing piece of the puzzle. Dung is a talented, quick-witted and hard-working software engineer who was working as a team lead at ELCA, a large and well-known technology company in Vietnam. However, Dung believes in the vision, “building world-class engineering team.</h2>\r\n</section>'),
(830, 2, '_e_middle_left', 'field_57a3676dfe130'),
(831, 2, 'e_middle_right', '<section class="bl-des-right">\r\n<h2>A great opportunity came from his employer Koneka, who wanted to start a remote team in Vietnam at that time. With the mindset “always start with a customer”, he told himself, <span class="uline">“It\'s time to kickoff a new and exciting journey."</span></h2>\r\n</section>'),
(832, 2, '_e_middle_right', 'field_57a36853fe131'),
(833, 2, 'image_middle', '209'),
(834, 2, '_image_middle', 'field_57a36873fe132'),
(835, 2, 'e_middle', '<div class="bl-about-main-people-des-content">\r\n<h2>Having a paying customer and smart,</h2>\r\n<h2>dedicated and determined founders,</h2>\r\n<h2>Futurify was formed on June 1st, 2012.</h2>\r\n<h5>JOHN VU - PRODUCT MANANGER</h5>\r\nNot only our customers but also our members want to be successful. If our members are talented and are success hunters, our customers would be benefit from these talents tremendously. It has shown to our elite management team: Vu Le, head of Human Resource and company culture, Tan Hoang, head of outsource team, and Khoa Nguyen, head of our amazing Point of Sales system department.\r\n\r\n</div>'),
(836, 2, '_e_middle', 'field_57a3689efe133'),
(837, 211, 'top_title', 'THE<br>FUTURIFY<br>STORIES'),
(838, 211, '_top_title', 'field_57a35b4a053af'),
(839, 211, 'e_top_left', '<section class="section-left">\r\n<h2>We gonna tell you a story about Futurify where we call our second home. Say hello with a young software engineer, Tri Ho, version 2012. After 3 years of working for University of Ottawa while studying and 8 months at Koneka after graduation as a web developer, he went back to Vietnam. Flame of desire and passion of youth inspirit him to build something.</h2>\r\n</section>'),
(840, 211, '_e_top_left', 'field_57a35f3ddfaaa'),
(841, 211, 'e_top_right', '<section class="section-right">\r\n<h2>“Behind every success there is a story</h2>\r\n<h2>with a humble start, some failures, some</h2>\r\n<h2>successes and an ongoing happiness.”</h2>\r\n<h5>JOHN VU - PRODUCT MANANGER</h5>\r\n</section>'),
(842, 211, '_e_top_right', 'field_57a3621c24e7b'),
(843, 211, 'image_top', '149'),
(844, 211, '_image_top', 'field_57a35fa5dfaab'),
(845, 211, 'e_middle_left', '<section class="bl-des-left">\r\n<h2>Of course, Tri understood that he could not run a long and challenging road by himself. Dung Dang, one of his close friends since they were in high school, would be the perfect missing piece of the puzzle. Dung is a talented, quick-witted and hard-working software engineer who was working as a team lead at ELCA, a large and well-known technology company in Vietnam. However, Dung believes in the vision, “building world-class engineering team.</h2>\r\n</section>'),
(846, 211, '_e_middle_left', 'field_57a3676dfe130'),
(847, 211, 'e_middle_right', '<section class="bl-des-right">\r\n<h2>A great opportunity came from his employer Koneka, who wanted to start a remote team in Vietnam at that time. With the mindset “always start with a customer”, he told himself, <span class="uline">“It\'s time to kickoff a new and exciting journey."</span></h2>\r\n</section>'),
(848, 211, '_e_middle_right', 'field_57a36853fe131'),
(849, 211, 'image_middle', '209'),
(850, 211, '_image_middle', 'field_57a36873fe132'),
(851, 211, 'e_middle', '<div class="bl-about-main-people-des-content">\r\n<h2>Having a paying customer and smart,</h2>\r\n<h2>dedicated and determined founders,</h2>\r\n<h2>Futurify was formed on June 1st, 2012.</h2>\r\n<h5>JOHN VU - PRODUCT MANANGER</h5>\r\nNot only our customers but also our members want to be successful. If our members are talented and are success hunters, our customers would be benefit from these talents tremendously. It has shown to our elite management team: Vu Le, head of Human Resource and company culture, Tan Hoang, head of outsource team, and Khoa Nguyen, head of our amazing Point of Sales system department.\r\n\r\n</div>'),
(852, 211, '_e_middle', 'field_57a3689efe133'),
(853, 212, 'top_title', 'THE<br>FUTURIFY<br>STORIES'),
(854, 212, '_top_title', 'field_57a35b4a053af'),
(855, 212, 'e_top_left', '<section class="section-left">\r\n<h2>We gonna tell you a story about Futurify where we call our second home. Say hello with a young software engineer, Tri Ho, version 2012. After 3 years of working for University of Ottawa while studying and 8 months at Koneka after graduation as a web developer, he went back to Vietnam. Flame of desire and passion of youth inspirit him to build something.</h2>\r\n</section>'),
(856, 212, '_e_top_left', 'field_57a35f3ddfaaa'),
(857, 212, 'e_top_right', '<section class="section-right">\r\n<h2>“Behind every success there is a story</h2>\r\n<h2>with a humble start, some failures, some</h2>\r\n<h2>successes and an ongoing happiness.”</h2>\r\n<h5>JOHN VU - PRODUCT MANANGER</h5>\r\n</section>'),
(858, 212, '_e_top_right', 'field_57a3621c24e7b'),
(859, 212, 'image_top', '182'),
(860, 212, '_image_top', 'field_57a35fa5dfaab'),
(861, 212, 'e_middle_left', '<section class="bl-des-left">\r\n<h2>Of course, Tri understood that he could not run a long and challenging road by himself. Dung Dang, one of his close friends since they were in high school, would be the perfect missing piece of the puzzle. Dung is a talented, quick-witted and hard-working software engineer who was working as a team lead at ELCA, a large and well-known technology company in Vietnam. However, Dung believes in the vision, “building world-class engineering team.</h2>\r\n</section>'),
(862, 212, '_e_middle_left', 'field_57a3676dfe130'),
(863, 212, 'e_middle_right', '<section class="bl-des-right">\r\n<h2>A great opportunity came from his employer Koneka, who wanted to start a remote team in Vietnam at that time. With the mindset “always start with a customer”, he told himself, <span class="uline">“It\'s time to kickoff a new and exciting journey."</span></h2>\r\n</section>'),
(864, 212, '_e_middle_right', 'field_57a36853fe131'),
(865, 212, 'image_middle', '209'),
(866, 212, '_image_middle', 'field_57a36873fe132'),
(867, 212, 'e_middle', '<div class="bl-about-main-people-des-content">\r\n<h2>Having a paying customer and smart,</h2>\r\n<h2>dedicated and determined founders,</h2>\r\n<h2>Futurify was formed on June 1st, 2012.</h2>\r\n<h5>JOHN VU - PRODUCT MANANGER</h5>\r\nNot only our customers but also our members want to be successful. If our members are talented and are success hunters, our customers would be benefit from these talents tremendously. It has shown to our elite management team: Vu Le, head of Human Resource and company culture, Tan Hoang, head of outsource team, and Khoa Nguyen, head of our amazing Point of Sales system department.\r\n\r\n</div>'),
(868, 212, '_e_middle', 'field_57a3689efe133'),
(869, 201, 'field_57a36bc3cfab5', 'a:8:{s:3:"key";s:19:"field_57a36bc3cfab5";s:5:"label";s:6:"Bottom";s:4:"name";s:0:"";s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:10;}'),
(870, 201, 'field_57a36bddcfab6', 'a:11:{s:3:"key";s:19:"field_57a36bddcfab6";s:5:"label";s:5:"Image";s:4:"name";s:12:"image_bottom";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:11:"save_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:11;}'),
(872, 201, 'field_57a36c0806213', 'a:11:{s:3:"key";s:19:"field_57a36c0806213";s:5:"label";s:6:"Editor";s:4:"name";s:13:"editor_bottom";s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:7:"toolbar";s:4:"full";s:12:"media_upload";s:3:"yes";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:12;}'),
(874, 213, '_wp_attached_file', '2016/07/group-copy.png'),
(875, 213, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:342;s:6:"height";i:456;s:4:"file";s:22:"2016/07/group-copy.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"group-copy-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:22:"group-copy-225x300.png";s:5:"width";i:225;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:10:"fiat_thumb";a:4:{s:4:"file";s:20:"group-copy-60x80.png";s:5:"width";i:60;s:6:"height";i:80;s:9:"mime-type";s:9:"image/png";}s:13:"alm-thumbnail";a:4:{s:4:"file";s:22:"group-copy-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(876, 214, 'top_title', 'THE<br>FUTURIFY<br>STORIES'),
(877, 214, '_top_title', 'field_57a35b4a053af'),
(878, 214, 'e_top_left', '<section class="section-left">\r\n<h2>We gonna tell you a story about Futurify where we call our second home. Say hello with a young software engineer, Tri Ho, version 2012. After 3 years of working for University of Ottawa while studying and 8 months at Koneka after graduation as a web developer, he went back to Vietnam. Flame of desire and passion of youth inspirit him to build something.</h2>\r\n</section>'),
(879, 214, '_e_top_left', 'field_57a35f3ddfaaa'),
(880, 214, 'e_top_right', '<section class="section-right">\r\n<h2>“Behind every success there is a story</h2>\r\n<h2>with a humble start, some failures, some</h2>\r\n<h2>successes and an ongoing happiness.”</h2>\r\n<h5>JOHN VU - PRODUCT MANANGER</h5>\r\n</section>'),
(881, 214, '_e_top_right', 'field_57a3621c24e7b'),
(882, 214, 'image_top', '182'),
(883, 214, '_image_top', 'field_57a35fa5dfaab'),
(884, 214, 'e_middle_left', '<section class="bl-des-left">\r\n<h2>Of course, Tri understood that he could not run a long and challenging road by himself. Dung Dang, one of his close friends since they were in high school, would be the perfect missing piece of the puzzle. Dung is a talented, quick-witted and hard-working software engineer who was working as a team lead at ELCA, a large and well-known technology company in Vietnam. However, Dung believes in the vision, “building world-class engineering team.</h2>\r\n</section>'),
(885, 214, '_e_middle_left', 'field_57a3676dfe130'),
(886, 214, 'e_middle_right', '<section class="bl-des-right">\r\n<h2>A great opportunity came from his employer Koneka, who wanted to start a remote team in Vietnam at that time. With the mindset “always start with a customer”, he told himself, <span class="uline">“It\'s time to kickoff a new and exciting journey."</span></h2>\r\n</section>'),
(887, 214, '_e_middle_right', 'field_57a36853fe131'),
(888, 214, 'image_middle', '209'),
(889, 214, '_image_middle', 'field_57a36873fe132'),
(890, 214, 'e_middle', '<div class="bl-about-main-people-des-content">\r\n<h2>Having a paying customer and smart,</h2>\r\n<h2>dedicated and determined founders,</h2>\r\n<h2>Futurify was formed on June 1st, 2012.</h2>\r\n<h5>JOHN VU - PRODUCT MANANGER</h5>\r\nNot only our customers but also our members want to be successful. If our members are talented and are success hunters, our customers would be benefit from these talents tremendously. It has shown to our elite management team: Vu Le, head of Human Resource and company culture, Tan Hoang, head of outsource team, and Khoa Nguyen, head of our amazing Point of Sales system department.\r\n\r\n</div>'),
(891, 214, '_e_middle', 'field_57a3689efe133'),
(892, 214, 'image_bottom', '213'),
(893, 214, '_image_bottom', 'field_57a36bddcfab6'),
(894, 214, 'editor_bottom', '<div class="bl-about-our-mission-content">\r\n<h1 class="black-title">OUR MISSION</h1>\r\n<h5>JOHN VU - PRODUCT MANANGER</h5>\r\nOur focus is to build highly innovative, interactive reliable web-based solutions to bring maximum values to our clients and users on time and on budget.\r\n\r\n</div>'),
(895, 214, '_editor_bottom', 'field_57a36c0806213'),
(896, 2, 'image_bottom', '213'),
(897, 2, '_image_bottom', 'field_57a36bddcfab6'),
(898, 2, 'editor_bottom', '<div class="bl-about-our-mission-content">\r\n<h1 class="black-title">OUR MISSION</h1>\r\n<h5>JOHN VU - PRODUCT MANANGER</h5>\r\nOur focus is to build highly <span class="red-txt">innovative</span>, <span class="red-txt">interactive</span> <span class="red-txt">reliable</span> web-based solutions to bring maximum values to our clients and users on time and on budget.\r\n\r\n</div>'),
(899, 2, '_editor_bottom', 'field_57a36c0806213'),
(900, 215, 'top_title', 'THE<br>FUTURIFY<br>STORIES'),
(901, 215, '_top_title', 'field_57a35b4a053af'),
(902, 215, 'e_top_left', '<section class="section-left">\r\n<h2>We gonna tell you a story about Futurify where we call our second home. Say hello with a young software engineer, Tri Ho, version 2012. After 3 years of working for University of Ottawa while studying and 8 months at Koneka after graduation as a web developer, he went back to Vietnam. Flame of desire and passion of youth inspirit him to build something.</h2>\r\n</section>'),
(903, 215, '_e_top_left', 'field_57a35f3ddfaaa'),
(904, 215, 'e_top_right', '<section class="section-right">\r\n<h2>“Behind every success there is a story</h2>\r\n<h2>with a humble start, some failures, some</h2>\r\n<h2>successes and an ongoing happiness.”</h2>\r\n<h5>JOHN VU - PRODUCT MANANGER</h5>\r\n</section>'),
(905, 215, '_e_top_right', 'field_57a3621c24e7b'),
(906, 215, 'image_top', '182'),
(907, 215, '_image_top', 'field_57a35fa5dfaab'),
(908, 215, 'e_middle_left', '<section class="bl-des-left">\r\n<h2>Of course, Tri understood that he could not run a long and challenging road by himself. Dung Dang, one of his close friends since they were in high school, would be the perfect missing piece of the puzzle. Dung is a talented, quick-witted and hard-working software engineer who was working as a team lead at ELCA, a large and well-known technology company in Vietnam. However, Dung believes in the vision, “building world-class engineering team.</h2>\r\n</section>'),
(909, 215, '_e_middle_left', 'field_57a3676dfe130'),
(910, 215, 'e_middle_right', '<section class="bl-des-right">\r\n<h2>A great opportunity came from his employer Koneka, who wanted to start a remote team in Vietnam at that time. With the mindset “always start with a customer”, he told himself, <span class="uline">“It\'s time to kickoff a new and exciting journey."</span></h2>\r\n</section>') ;
INSERT INTO `lrpmqdj9_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(911, 215, '_e_middle_right', 'field_57a36853fe131'),
(912, 215, 'image_middle', '209'),
(913, 215, '_image_middle', 'field_57a36873fe132'),
(914, 215, 'e_middle', '<div class="bl-about-main-people-des-content">\r\n<h2>Having a paying customer and smart,</h2>\r\n<h2>dedicated and determined founders,</h2>\r\n<h2>Futurify was formed on June 1st, 2012.</h2>\r\n<h5>JOHN VU - PRODUCT MANANGER</h5>\r\nNot only our customers but also our members want to be successful. If our members are talented and are success hunters, our customers would be benefit from these talents tremendously. It has shown to our elite management team: Vu Le, head of Human Resource and company culture, Tan Hoang, head of outsource team, and Khoa Nguyen, head of our amazing Point of Sales system department.\r\n\r\n</div>'),
(915, 215, '_e_middle', 'field_57a3689efe133'),
(916, 215, 'image_bottom', '213'),
(917, 215, '_image_bottom', 'field_57a36bddcfab6'),
(918, 215, 'editor_bottom', '<div class="bl-about-our-mission-content">\r\n<h1 class="black-title">OUR MISSION</h1>\r\n<h5>JOHN VU - PRODUCT MANANGER</h5>\r\nOur focus is to build highly <span class="red-txt">innovative</span>, <span class="red-txt">interactive</span> <span class="red-txt">reliable</span> web-based solutions to bring maximum values to our clients and users on time and on budget.\r\n\r\n</div>'),
(919, 215, '_editor_bottom', 'field_57a36c0806213'),
(920, 10, '_wpb_vc_js_status', 'false'),
(921, 10, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(923, 201, 'rule', 'a:5:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:33:"templates/page-about-template.php";s:8:"order_no";i:0;s:8:"group_no";i:0;}'),
(924, 218, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(925, 218, '_edit_lock', '1470467770:1'),
(926, 218, '_edit_last', '1'),
(927, 218, 'field_57a370e92c81d', 'a:11:{s:3:"key";s:19:"field_57a370e92c81d";s:5:"label";s:4:"Link";s:4:"name";s:4:"link";s:4:"type";s:9:"page_link";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:9:"post_type";a:1:{i:0;s:4:"page";}s:10:"allow_null";s:1:"0";s:8:"multiple";s:1:"0";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}'),
(928, 218, 'field_57a371a72c81e', 'a:11:{s:3:"key";s:19:"field_57a371a72c81e";s:5:"label";s:5:"Image";s:4:"name";s:5:"image";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:11:"save_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:1;}'),
(930, 218, 'position', 'normal'),
(931, 218, 'layout', 'no_box'),
(932, 218, 'hide_on_screen', ''),
(933, 219, 'link', '2'),
(934, 219, '_link', 'field_57a370e92c81d'),
(935, 219, 'image', '37'),
(936, 219, '_image', 'field_57a371a72c81e'),
(937, 10, 'link', '2'),
(938, 10, '_link', 'field_57a370e92c81d'),
(939, 10, 'image', '37'),
(940, 10, '_image', 'field_57a371a72c81e'),
(943, 221, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(944, 221, '_edit_lock', '1470490006:1'),
(945, 221, '_edit_last', '1'),
(946, 221, '_wp_page_template', 'templates/page-career-template.php'),
(947, 221, '_wpb_vc_js_status', 'false'),
(948, 223, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(949, 223, '_edit_lock', '1470450637:1'),
(950, 223, '_edit_last', '1'),
(951, 223, 'field_57a374918d19b', 'a:8:{s:3:"key";s:19:"field_57a374918d19b";s:5:"label";s:5:"Step1";s:4:"name";s:0:"";s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:2;}'),
(953, 223, 'position', 'acf_after_title'),
(954, 223, 'layout', 'no_box'),
(955, 223, 'hide_on_screen', 'a:1:{i:0;s:11:"the_content";}'),
(958, 223, 'field_57a375f097b76', 'a:14:{s:3:"key";s:19:"field_57a375f097b76";s:5:"label";s:10:"Step Title";s:4:"name";s:13:"step_title_s1";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:3;}'),
(960, 223, 'field_57a37679d1fcb', 'a:8:{s:3:"key";s:19:"field_57a37679d1fcb";s:5:"label";s:5:"Step2";s:4:"name";s:0:"";s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:6;}'),
(961, 223, 'field_57a3768ad1fcc', 'a:8:{s:3:"key";s:19:"field_57a3768ad1fcc";s:5:"label";s:5:"Step3";s:4:"name";s:0:"";s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:10;}'),
(962, 223, 'field_57a37695d1fcd', 'a:8:{s:3:"key";s:19:"field_57a37695d1fcd";s:5:"label";s:5:"Step4";s:4:"name";s:0:"";s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:13;}'),
(965, 224, 'tittle', 'WE\'RE EXCITED TO LEARN MORE ABOUT YOU AND YOUR NEEDS'),
(966, 224, '_tittle', 'field_57a34eaa52028'),
(967, 198, 'field_57a3786ce83f3', 'a:11:{s:3:"key";s:19:"field_57a3786ce83f3";s:5:"label";s:21:"Link (Action To Call)";s:4:"name";s:4:"link";s:4:"type";s:9:"page_link";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:9:"post_type";a:1:{i:0;s:4:"page";}s:10:"allow_null";s:1:"0";s:8:"multiple";s:1:"0";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:1;}'),
(969, 225, 'tittle', 'WE\'RE EXCITED TO LEARN MORE ABOUT YOU AND YOUR NEEDS'),
(970, 225, '_tittle', 'field_57a34eaa52028'),
(971, 225, 'link', '221'),
(972, 225, '_link', 'field_57a3786ce83f3'),
(973, 64, 'link', '221'),
(974, 64, '_link', 'field_57a3786ce83f3'),
(975, 226, 'tittle', 'WE\'RE EXCITED TO LEARN MORE ABOUT YOU AND YOUR NEEDS'),
(976, 226, '_tittle', 'field_57a34eaa52028'),
(977, 226, 'link', '221'),
(978, 226, '_link', 'field_57a3786ce83f3'),
(979, 223, 'field_57a4af021bcd6', 'a:11:{s:3:"key";s:19:"field_57a4af021bcd6";s:5:"label";s:6:"Editor";s:4:"name";s:9:"editor_s1";s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:7:"toolbar";s:4:"full";s:12:"media_upload";s:3:"yes";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:4;}'),
(983, 223, 'field_57a4af6951055', 'a:14:{s:3:"key";s:19:"field_57a4af6951055";s:5:"label";s:10:"Step Title";s:4:"name";s:13:"step_title_s2";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:7;}'),
(984, 223, 'field_57a4af9351056', 'a:11:{s:3:"key";s:19:"field_57a4af9351056";s:5:"label";s:11:"Editor Left";s:4:"name";s:14:"editor_s2_left";s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:7:"toolbar";s:4:"full";s:12:"media_upload";s:3:"yes";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:8;}'),
(985, 223, 'field_57a4afc351057', 'a:11:{s:3:"key";s:19:"field_57a4afc351057";s:5:"label";s:12:"Editor Right";s:4:"name";s:15:"editor_s2_right";s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:7:"toolbar";s:4:"full";s:12:"media_upload";s:3:"yes";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:9;}'),
(987, 223, 'field_57a4afff2855a', 'a:14:{s:3:"key";s:19:"field_57a4afff2855a";s:5:"label";s:10:"Step Title";s:4:"name";s:13:"step_title_s3";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:11;}'),
(988, 223, 'field_57a4b0412855b', 'a:11:{s:3:"key";s:19:"field_57a4b0412855b";s:5:"label";s:6:"Editor";s:4:"name";s:9:"editor_s3";s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:7:"toolbar";s:4:"full";s:12:"media_upload";s:3:"yes";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:12;}'),
(990, 223, 'field_57a4b05d4cad1', 'a:14:{s:3:"key";s:19:"field_57a4b05d4cad1";s:5:"label";s:10:"Step Title";s:4:"name";s:13:"step_title_s4";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:14;}'),
(991, 223, 'field_57a4b06a4cad2', 'a:11:{s:3:"key";s:19:"field_57a4b06a4cad2";s:5:"label";s:6:"Editor";s:4:"name";s:9:"editor_s4";s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:7:"toolbar";s:4:"full";s:12:"media_upload";s:3:"yes";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:15;}'),
(993, 86, 'step_title_s1', 'THE CHALLENGE'),
(994, 86, '_step_title_s1', 'field_57a375f097b76'),
(995, 86, 'editor_s1', '<p class="heading">Wanna develop a new idea or improve on the existing software? Although your organization have their internal development team or not, our honest, quick-witted and hard-working will help you to fulfill your needs to accomplish high-functioning products.</p>'),
(996, 86, '_editor_s1', 'field_57a4af021bcd6'),
(997, 86, 'step_title_s2', 'OUR APPROACH'),
(998, 86, '_step_title_s2', 'field_57a4af6951055'),
(999, 86, 'editor_s2_left', 'We gonna tell you a story about Futurify where we call our second home. Say hello with a young software engineer, Tri Ho, version 2012. After 3 years of working for University of Ottawa while studying and 8 months at Koneka after graduation as a web developer, he went back to Vietnam. Flame of desire and passion of youth inspirit him to build something.'),
(1000, 86, '_editor_s2_left', 'field_57a4af9351056'),
(1001, 86, 'editor_s2_right', '<h2><span class="red-text">“The FUTURIFY team refined our brand, created a rockin\' style guide and brand book, and designed a web site that we\'re extremely proud of.”</span></h2>\r\n<h4>JOHN VU - PRODUCT MANANGER</h4>'),
(1002, 86, '_editor_s2_right', 'field_57a4afc351057'),
(1003, 86, 'step_title_s3', 'THE RESULT'),
(1004, 86, '_step_title_s3', 'field_57a4afff2855a'),
(1005, 86, 'editor_s3', '<img id="__wp-temp-img-id" title="" src="http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/08/project-6.png" alt="" width="322" height="242" />\r\n\r\n<img class="alignnone size-medium wp-image-228" src="http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/phone-195x300.png" alt="phone" width="195" height="300" />\r\n\r\n<img class="alignnone size-medium wp-image-230" src="http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/case2-300x225.png" alt="case2" width="300" height="225" />\r\n\r\n<img class="alignnone size-medium wp-image-231" src="http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/case3-300x225.png" alt="case3" width="300" height="225" />\r\n\r\n<img class="alignnone size-medium wp-image-229" src="http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/case1-300x225.png" alt="case1" width="300" height="225" />'),
(1006, 86, '_editor_s3', 'field_57a4b0412855b'),
(1007, 86, 'step_title_s4', ''),
(1008, 86, '_step_title_s4', 'field_57a4b05d4cad1'),
(1009, 86, 'editor_s4', ''),
(1010, 86, '_editor_s4', 'field_57a4b06a4cad2'),
(1011, 86, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(1013, 228, '_wp_attached_file', '2016/07/phone.png'),
(1014, 228, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:491;s:6:"height";i:755;s:4:"file";s:17:"2016/07/phone.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"phone-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:17:"phone-195x300.png";s:5:"width";i:195;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:10:"fiat_thumb";a:4:{s:4:"file";s:15:"phone-60x92.png";s:5:"width";i:60;s:6:"height";i:92;s:9:"mime-type";s:9:"image/png";}s:13:"alm-thumbnail";a:4:{s:4:"file";s:17:"phone-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1015, 229, '_wp_attached_file', '2016/07/case1.png'),
(1016, 229, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:491;s:6:"height";i:368;s:4:"file";s:17:"2016/07/case1.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"case1-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:17:"case1-300x225.png";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:9:"image/png";}s:10:"fiat_thumb";a:4:{s:4:"file";s:15:"case1-60x45.png";s:5:"width";i:60;s:6:"height";i:45;s:9:"mime-type";s:9:"image/png";}s:13:"alm-thumbnail";a:4:{s:4:"file";s:17:"case1-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1017, 230, '_wp_attached_file', '2016/07/case2.png'),
(1018, 230, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:491;s:6:"height";i:368;s:4:"file";s:17:"2016/07/case2.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"case2-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:17:"case2-300x225.png";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:9:"image/png";}s:10:"fiat_thumb";a:4:{s:4:"file";s:15:"case2-60x45.png";s:5:"width";i:60;s:6:"height";i:45;s:9:"mime-type";s:9:"image/png";}s:13:"alm-thumbnail";a:4:{s:4:"file";s:17:"case2-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1019, 231, '_wp_attached_file', '2016/07/case3.png'),
(1020, 231, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:491;s:6:"height";i:368;s:4:"file";s:17:"2016/07/case3.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"case3-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:17:"case3-300x225.png";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:9:"image/png";}s:10:"fiat_thumb";a:4:{s:4:"file";s:15:"case3-60x45.png";s:5:"width";i:60;s:6:"height";i:45;s:9:"mime-type";s:9:"image/png";}s:13:"alm-thumbnail";a:4:{s:4:"file";s:17:"case3-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1021, 223, 'field_57a4bb5d2b6c9', 'a:11:{s:3:"key";s:19:"field_57a4bb5d2b6c9";s:5:"label";s:12:"Editor Image";s:4:"name";s:12:"editor_image";s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:7:"toolbar";s:4:"full";s:12:"media_upload";s:3:"yes";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:5;}'),
(1024, 86, 'editor_image', '<img class="alignnone size-medium wp-image-149" src="http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/08/project-6-300x225.png" alt="project-6" width="300" height="225" /><img class="alignnone size-medium wp-image-149" src="http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/08/project-6-300x225.png" alt="project-6" width="300" height="225" />'),
(1025, 86, '_editor_image', 'field_57a4bb5d2b6c9'),
(1026, 223, 'field_57a4c333c0727', 'a:8:{s:3:"key";s:19:"field_57a4c333c0727";s:5:"label";s:17:"Link Project Page";s:4:"name";s:17:"link_project_page";s:4:"type";s:11:"link_picker";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:1;}'),
(1028, 223, '_at_widget', '1'),
(1030, 86, 'link_project_page', 'a:3:{s:3:"url";s:33:"http://futurify.nguyenbui.name.vn";s:5:"title";s:0:"";s:6:"target";s:6:"_blank";}'),
(1031, 86, '_link_project_page', 'field_57a4c333c0727'),
(1032, 86, '_at_widget', '1') ;
INSERT INTO `lrpmqdj9_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1034, 223, 'field_57a54b694717c', 'a:11:{s:3:"key";s:19:"field_57a54b694717c";s:5:"label";s:13:"Display Title";s:4:"name";s:13:"display_title";s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:111:"This field is displayed at the top of project detail page.\r\nIf it is blank, the project name will be displayed.";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:7:"toolbar";s:4:"full";s:12:"media_upload";s:3:"yes";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}'),
(1037, 223, 'rule', 'a:5:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:7:"project";s:8:"order_no";i:0;s:8:"group_no";i:0;}'),
(1038, 86, 'display_title', '<h1 class="black-title">SMART\r\nPROPOSITITION</h1>'),
(1039, 86, '_display_title', 'field_57a54b694717c'),
(1040, 232, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(1041, 232, '_edit_lock', '1470452240:1'),
(1042, 232, '_edit_last', '1'),
(1043, 232, '_at_widget', '1'),
(1044, 234, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(1045, 234, '_edit_lock', '1470452485:1'),
(1046, 234, '_edit_last', '1'),
(1047, 218, 'rule', 'a:5:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:37:"templates/page-blog-list-template.php";s:8:"order_no";i:0;s:8:"group_no";i:0;}'),
(1048, 218, 'rule', 'a:5:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:34:"templates/page-career-template.php";s:8:"order_no";i:0;s:8:"group_no";i:1;}'),
(1049, 218, '_at_widget', '1'),
(1050, 235, 'link', '2'),
(1051, 235, '_link', 'field_57a370e92c81d'),
(1052, 235, 'image', '37'),
(1053, 235, '_image', 'field_57a371a72c81e'),
(1054, 221, '_at_widget', '1'),
(1055, 221, 'link', '2'),
(1056, 221, '_link', 'field_57a370e92c81d'),
(1057, 221, 'image', '37'),
(1058, 221, '_image', 'field_57a371a72c81e'),
(1062, 124, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(1066, 123, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(1070, 122, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(1074, 116, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(1075, 124, '_wp_old_slug', 'video2__trashed'),
(1076, 123, '_wp_old_slug', 'video3__trashed'),
(1077, 122, '_wp_old_slug', 'video4__trashed'),
(1078, 116, '_wp_old_slug', 'video5__trashed'),
(1079, 124, '_wp_trash_meta_status', 'publish'),
(1080, 124, '_wp_trash_meta_time', '1470483292'),
(1081, 124, '_wp_desired_post_slug', 'video2'),
(1082, 123, '_wp_trash_meta_status', 'publish'),
(1083, 123, '_wp_trash_meta_time', '1470483295'),
(1084, 123, '_wp_desired_post_slug', 'video3'),
(1085, 122, '_wp_trash_meta_status', 'publish'),
(1086, 122, '_wp_trash_meta_time', '1470483297'),
(1087, 122, '_wp_desired_post_slug', 'video4'),
(1088, 116, '_wp_trash_meta_status', 'publish'),
(1089, 116, '_wp_trash_meta_time', '1470483300'),
(1090, 116, '_wp_desired_post_slug', 'video5'),
(1091, 198, 'field_57a5dfb98f28f', 'a:11:{s:3:"key";s:19:"field_57a5dfb98f28f";s:5:"label";s:12:"Image Mobile";s:4:"name";s:12:"image_mobile";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:11:"save_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:2:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:2;}'),
(1092, 198, 'rule', 'a:5:{s:5:"param";s:4:"page";s:8:"operator";s:2:"==";s:5:"value";s:2:"64";s:8:"order_no";i:0;s:8:"group_no";i:0;}'),
(1093, 198, '_at_widget', '1'),
(1094, 236, 'tittle', 'WE\'RE EXCITED TO LEARN MORE ABOUT YOU AND YOUR NEEDS'),
(1095, 236, '_tittle', 'field_57a34eaa52028'),
(1096, 236, 'link', '221'),
(1097, 236, '_link', 'field_57a3786ce83f3'),
(1098, 236, 'image_mobile', '37'),
(1099, 236, '_image_mobile', 'field_57a5dfb98f28f'),
(1100, 64, '_at_widget', '1'),
(1101, 64, 'image_mobile', '37'),
(1102, 64, '_image_mobile', 'field_57a5dfb98f28f'),
(1103, 237, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(1104, 237, '_edit_lock', '1470490074:1'),
(1105, 237, '_edit_last', '1'),
(1106, 238, '_vc_post_settings', 'a:1:{s:10:"vc_grid_id";a:0:{}}'),
(1107, 238, '_edit_lock', '1470489978:1'),
(1108, 238, '_edit_last', '1'),
(1109, 238, 'left_tag', '<span class="red-txt">'),
(1110, 238, 'right_tag', '</span>'),
(1111, 238, 'styling_content', ''),
(1112, 238, 'content-block', NULL),
(1113, 238, 'content-type', 'wrap'),
(1114, 238, 'block_content', ''),
(1115, 238, 'rich_editor', 'rich_editor'),
(1116, 238, 'html_editor', 'html_editor'),
(1117, 238, 'icon', '_red_bg_txt.png'),
(1118, 238, 'quicktag', ''),
(1119, 238, 'row', NULL),
(1120, 237, '_at_widget', '1') ;

#
# End of data contents of table `lrpmqdj9_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `lrpmqdj9_posts`
#

DROP TABLE IF EXISTS `lrpmqdj9_posts`;


#
# Table structure of table `lrpmqdj9_posts`
#

CREATE TABLE `lrpmqdj9_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=239 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `lrpmqdj9_posts`
#
INSERT INTO `lrpmqdj9_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(2, 1, '2016-07-17 17:36:10', '2016-07-17 17:36:10', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\r\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin\' caught in the rain.)</blockquote>\r\n...or something like this:\r\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\r\nAs a new WordPress user, you should go to <a href="http://futurify.nguyenbui.name.vn/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'ABOUT', '', 'publish', 'closed', 'open', '', 'about', '', '', '2016-08-04 16:32:40', '2016-08-04 16:32:40', '', 0, 'http://futurify.nguyenbui.name.vn/?page_id=2', 0, 'page', '', 0),
(4, 1, '2016-07-17 17:38:18', '2016-07-17 17:38:18', '<h1>SEND US A<br />MESSAGE.</h1>\r\n<p>[text* your-name placeholder "Type your full name*"]</p>\r\n<p>[email* your-email placeholder "Email address*"]</p>\r\n<p>[tel your-phone placeholder "Phone Number"]</p>\r\n<p>[text your-cpmpany placeholder "Company name*"]</p>\r\n<p>[textarea your-message placeholder "Tell us about you, your business and requirements of a new project you want to start with us!"]</p>\r\n<p><span class="service-choice">Service you\'re interested in</span> [radio service default:1 "Staffing" "MVP" "Customize"]</p>\r\n<p>[response]</p>\r\n<p>[submit "SEND TO US"]</p>\nFuturify "[your-subject]"\n[your-name] <duytan1008@gmail.com>\nFrom: [your-name] <[your-email]>\r\nSubject: [your-subject]\r\n\r\nMessage Body:\r\n[your-message]\r\n\r\n--\r\nThis e-mail was sent from a contact form on Futurify (http://futurify.nguyenbui.name.vn)\nduytan1008@gmail.com\nReply-To: [your-email]\n\n\n\n\nFuturify "[your-subject]"\nFuturify <duytan1008@gmail.com>\nMessage Body:\r\n[your-message]\r\n\r\n--\r\nThis e-mail was sent from a contact form on Futurify (http://futurify.nguyenbui.name.vn)\n[your-email]\nReply-To: duytan1008@gmail.com\n\n\n\nThank you for your message. It has been sent.\nThere was an error trying to send your message. Please try again later.\nOne or more fields have an error. Please check and try again.\nThere was an error trying to send your message. Please try again later.\nYou must accept the terms and conditions before sending your message.\nThe field is required.\nThe field is too long.\nThe field is too short.\nThe date format is incorrect.\nThe date is before the earliest one allowed.\nThe date is after the latest one allowed.\nThere was an unknown error uploading the file.\nYou are not allowed to upload files of this type.\nThe file is too big.\nThere was an error uploading the file.\nThe number format is invalid.\nThe number is smaller than the minimum allowed.\nThe number is larger than the maximum allowed.\nThe answer to the quiz is incorrect.\nYour entered code is incorrect.\nThe e-mail address entered is invalid.\nThe URL is invalid.\nThe telephone number is invalid.', 'Contact form 1', '', 'publish', 'closed', 'closed', '', 'contact-form-1', '', '', '2016-08-02 16:27:40', '2016-08-02 16:27:40', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=wpcf7_contact_form&#038;p=4', 0, 'wpcf7_contact_form', '', 0),
(5, 1, '2016-07-25 15:14:04', '2016-07-25 15:14:04', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\r\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin\' caught in the rain.)</blockquote>\r\n...or something like this:\r\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\r\nAs a new WordPress user, you should go to <a href="http://futurify.nguyenbui.name.vn/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'About', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2016-07-25 15:14:04', '2016-07-25 15:14:04', '', 2, 'http://futurify.nguyenbui.name.vn/index.php/2016/07/25/2-revision-v1/', 0, 'revision', '', 0),
(6, 1, '2016-07-25 15:14:25', '2016-07-25 15:14:25', '<div class="bl-our-project-des">\r\n<h2>FUTURIFY is one of the best design agencies</h2>\r\n<h2>I’ve worked with not only on a professional level, but personality wise as well.</h2>\r\n<h5>ACTIONAID VIETNAM’S TESTIMONAL</h5>\r\n</div>', 'PROJECTS', '', 'publish', 'closed', 'closed', '', 'projects', '', '', '2016-07-30 16:29:23', '2016-07-30 16:29:23', '', 0, 'http://futurify.nguyenbui.name.vn/?page_id=6', 0, 'page', '', 0),
(7, 1, '2016-07-25 15:14:25', '2016-07-25 15:14:25', '', 'PROJECTS', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2016-07-25 15:14:25', '2016-07-25 15:14:25', '', 6, 'http://futurify.nguyenbui.name.vn/index.php/2016/07/25/6-revision-v1/', 0, 'revision', '', 0),
(8, 1, '2016-07-25 15:14:46', '2016-07-25 15:14:46', '', 'SERVICES & PROCESS', '', 'publish', 'closed', 'closed', '', 'services-process', '', '', '2016-07-25 15:14:46', '2016-07-25 15:14:46', '', 0, 'http://futurify.nguyenbui.name.vn/?page_id=8', 0, 'page', '', 0),
(9, 1, '2016-07-25 15:14:46', '2016-07-25 15:14:46', '', 'SERVICES & PROCESS', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2016-07-25 15:14:46', '2016-07-25 15:14:46', '', 8, 'http://futurify.nguyenbui.name.vn/index.php/2016/07/25/8-revision-v1/', 0, 'revision', '', 0),
(10, 1, '2016-07-25 15:15:03', '2016-07-25 15:15:03', '<div class="bl-blog-list-title">\r\n<h1 class="black-title">SHARING IS CARING</h1>\r\nA place we share to each other, care of things around us. It\'s our pleasure to share culture, thoughts, interests in technology with you - our clients as well as the new visitors\r\n\r\n</div>', 'WE SHARE', '', 'publish', 'closed', 'closed', '', 'we-share', '', '', '2016-08-04 16:49:10', '2016-08-04 16:49:10', '', 0, 'http://futurify.nguyenbui.name.vn/?page_id=10', 0, 'page', '', 0),
(11, 1, '2016-07-25 15:15:03', '2016-07-25 15:15:03', '', 'WE SHARE', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2016-07-25 15:15:03', '2016-07-25 15:15:03', '', 10, 'http://futurify.nguyenbui.name.vn/index.php/2016/07/25/10-revision-v1/', 0, 'revision', '', 0),
(12, 1, '2016-07-25 15:15:14', '2016-07-25 15:15:14', '<div class="contact-paragraph">\r\n<h2 class="red-txt">HELLO</h2>\r\nWe always have good taste Vietnamese coffee.\r\nCome in our nest, have a cup of coffee and a talk with us.\r\nWork together. Do amazing projects.\r\nBring success to your business, we know how.\r\n</div>', 'CONTACT US', '', 'publish', 'closed', 'closed', '', 'contact-us', '', '', '2016-08-03 15:56:08', '2016-08-03 15:56:08', '', 0, 'http://futurify.nguyenbui.name.vn/?page_id=12', 0, 'page', '', 0),
(13, 1, '2016-07-25 15:15:14', '2016-07-25 15:15:14', '', 'CONTACT US', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2016-07-25 15:15:14', '2016-07-25 15:15:14', '', 12, 'http://futurify.nguyenbui.name.vn/index.php/2016/07/25/12-revision-v1/', 0, 'revision', '', 0),
(14, 1, '2016-07-25 15:15:38', '2016-07-25 15:15:38', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\r\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin\' caught in the rain.)</blockquote>\r\n...or something like this:\r\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\r\nAs a new WordPress user, you should go to <a href="http://futurify.nguyenbui.name.vn/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'ABOUT', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2016-07-25 15:15:38', '2016-07-25 15:15:38', '', 2, 'http://futurify.nguyenbui.name.vn/index.php/2016/07/25/2-revision-v1/', 0, 'revision', '', 0),
(15, 1, '2016-07-25 15:15:56', '0000-00-00 00:00:00', '', 'Home', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-07-25 15:15:56', '0000-00-00 00:00:00', '', 0, 'http://futurify.nguyenbui.name.vn/?p=15', 1, 'nav_menu_item', '', 0),
(16, 1, '2016-07-25 15:16:45', '2016-07-25 15:16:45', ' ', '', '', 'publish', 'closed', 'closed', '', '16', '', '', '2016-07-31 15:25:09', '2016-07-31 15:25:09', '', 0, 'http://futurify.nguyenbui.name.vn/?p=16', 1, 'nav_menu_item', '', 0),
(17, 1, '2016-07-25 15:16:45', '2016-07-25 15:16:45', ' ', '', '', 'publish', 'closed', 'closed', '', '17', '', '', '2016-07-31 15:25:09', '2016-07-31 15:25:09', '', 0, 'http://futurify.nguyenbui.name.vn/?p=17', 7, 'nav_menu_item', '', 0),
(18, 1, '2016-07-25 15:16:45', '2016-07-25 15:16:45', ' ', '', '', 'publish', 'closed', 'closed', '', '18', '', '', '2016-07-31 15:25:09', '2016-07-31 15:25:09', '', 0, 'http://futurify.nguyenbui.name.vn/?p=18', 2, 'nav_menu_item', '', 0),
(19, 1, '2016-07-25 15:16:45', '2016-07-25 15:16:45', ' ', '', '', 'publish', 'closed', 'closed', '', '19', '', '', '2016-07-31 15:25:09', '2016-07-31 15:25:09', '', 0, 'http://futurify.nguyenbui.name.vn/?p=19', 3, 'nav_menu_item', '', 0),
(20, 1, '2016-07-25 15:16:45', '2016-07-25 15:16:45', ' ', '', '', 'publish', 'closed', 'closed', '', '20', '', '', '2016-07-31 15:25:09', '2016-07-31 15:25:09', '', 0, 'http://futurify.nguyenbui.name.vn/?p=20', 6, 'nav_menu_item', '', 0),
(22, 1, '2016-07-25 15:33:47', '2016-07-25 15:33:47', '', 'Contact Fields', '', 'publish', 'closed', 'closed', '', 'acf_contact-fields', '', '', '2016-07-30 16:57:01', '2016-07-30 16:57:01', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=acf&#038;p=22', 0, 'acf', '', 0),
(23, 1, '2016-07-25 15:52:32', '2016-07-25 15:52:32', '<h1 class="black-title">STAFFING</h1>\r\nWanna develop a new idea or improve on the existing software? Although your organization have their internal development team or not, our honest, quick-witted and hard-working will help you to fulfill your needs to accomplish high-functioning products.', 'STAFFING', '', 'publish', 'closed', 'closed', '', 'staffing', '', '', '2016-08-01 14:11:20', '2016-08-01 14:11:20', '', 8, 'http://futurify.nguyenbui.name.vn/?page_id=23', 0, 'page', '', 0),
(24, 1, '2016-07-25 15:52:32', '2016-07-25 15:52:32', '', 'STAFFING', '', 'inherit', 'closed', 'closed', '', '23-revision-v1', '', '', '2016-07-25 15:52:32', '2016-07-25 15:52:32', '', 23, 'http://futurify.nguyenbui.name.vn/index.php/2016/07/25/23-revision-v1/', 0, 'revision', '', 0),
(25, 1, '2016-07-25 15:52:58', '2016-07-25 15:52:58', '<h1 class="black-title">MINIMUM\r\nVIABLE\r\nPRODUCT\r\n(MVP)</h1>\r\nWanna develop a new idea or improve on the existing software? Although your organization have their internal development team or not, our honest, quick-witted and hard-working will help you to fulfill your needs to accomplish high-functioning products.', 'MVP', '', 'publish', 'closed', 'closed', '', 'mvp', '', '', '2016-08-01 14:58:49', '2016-08-01 14:58:49', '', 8, 'http://futurify.nguyenbui.name.vn/?page_id=25', 0, 'page', '', 0),
(26, 1, '2016-07-25 15:52:58', '2016-07-25 15:52:58', '', 'MVP', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2016-07-25 15:52:58', '2016-07-25 15:52:58', '', 25, 'http://futurify.nguyenbui.name.vn/index.php/2016/07/25/25-revision-v1/', 0, 'revision', '', 0),
(27, 1, '2016-07-25 15:53:55', '2016-07-25 15:53:55', ' ', '', '', 'publish', 'closed', 'closed', '', '27', '', '', '2016-07-31 15:25:09', '2016-07-31 15:25:09', '', 8, 'http://futurify.nguyenbui.name.vn/?p=27', 5, 'nav_menu_item', '', 0),
(28, 1, '2016-07-25 15:53:55', '2016-07-25 15:53:55', ' ', '', '', 'publish', 'closed', 'closed', '', '28', '', '', '2016-07-31 15:25:09', '2016-07-31 15:25:09', '', 8, 'http://futurify.nguyenbui.name.vn/?p=28', 4, 'nav_menu_item', '', 0),
(34, 1, '2016-07-26 04:18:17', '2016-07-26 04:18:17', '', 'User Fields', '', 'publish', 'closed', 'closed', '', 'acf_user-fields', '', '', '2016-07-26 04:19:49', '2016-07-26 04:19:49', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=acf&#038;p=34', 0, 'acf', '', 0),
(36, 2, '2016-07-26 09:18:25', '2016-07-26 09:18:25', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium.\r\n\r\n<span class="h3">HEADNING TITLE</span>\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium sit amet quis magna. Aenean velit odio, elementum in tempus ut, vehicula eu diam. Pellentesque rhoncus aliquam mattis. Ut vulputate eros sed felis sodales nec vulputate justo hendrerit. Vivamus varius pretium ligula, a aliquam odio euismod sit amet. Quisque laoreet sem sit amet orci ullamcorper at ultricies metus viverra. Pellentesque arcu mauris, malesuada quis ornare accumsan, blandit sed diam.\r\n\r\n<img class="alignnone wp-image-182 size-full" src="http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/group-1.png" alt="group" width="1002" height="564" />\r\n\r\n<span class="h3">HEADNING TITLE</span>\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium sit amet quis magna. Aenean velit odio, elementum in tempus ut, vehicula eu diam. Pellentesque rhoncus aliquam mattis. Ut vulputate eros sed felis sodales nec vulputate justo hendrerit. Vivamus varius pretium ligula, a aliquam odio euismod sit amet. Quisque laoreet sem sit amet orci ullamcorper at ultricies metus viverra. Pellentesque arcu mauris, malesuada quis ornare accumsan, blandit sed diam.', 'TOP 10 BREAKING NEWS OF THE GIANTS', '', 'publish', 'open', 'open', '', 'top-10-breaking-news-of-the-giants', '', '', '2016-08-02 09:14:55', '2016-08-02 09:14:55', '', 0, 'http://futurify.nguyenbui.name.vn/?p=36', 0, 'post', '', 0),
(37, 2, '2016-07-26 09:17:54', '2016-07-26 09:17:54', '', 'blg-list-1', '', 'inherit', 'open', 'closed', '', 'blg-list-1', '', '', '2016-07-26 09:17:54', '2016-07-26 09:17:54', '', 36, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/blg-list-1.png', 0, 'attachment', 'image/png', 0),
(38, 2, '2016-07-26 09:18:25', '2016-07-26 09:18:25', '', 'TOP 10 BREAKING NEWS OF THE GIANTS', '', 'inherit', 'closed', 'closed', '', '36-revision-v1', '', '', '2016-07-26 09:18:25', '2016-07-26 09:18:25', '', 36, 'http://futurify.nguyenbui.name.vn/index.php/2016/07/26/36-revision-v1/', 0, 'revision', '', 0),
(39, 2, '2016-07-26 09:30:58', '2016-07-26 09:30:58', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium.\r\n\r\n<span class="h3">HEADNING TITLE</span>\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium sit amet quis magna. Aenean velit odio, elementum in tempus ut, vehicula eu diam. Pellentesque rhoncus aliquam mattis. Ut vulputate eros sed felis sodales nec vulputate justo hendrerit. Vivamus varius pretium ligula, a aliquam odio euismod sit amet. Quisque laoreet sem sit amet orci ullamcorper at ultricies metus viverra. Pellentesque arcu mauris, malesuada quis ornare accumsan, blandit sed diam.\r\n\r\n<img class="alignnone wp-image-182 size-full" src="http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/group-1.png" alt="group" width="1002" height="564" />\r\n\r\n<span class="h3">HEADNING TITLE</span>\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium sit amet quis magna. Aenean velit odio, elementum in tempus ut, vehicula eu diam. Pellentesque rhoncus aliquam mattis. Ut vulputate eros sed felis sodales nec vulputate justo hendrerit. Vivamus varius pretium ligula, a aliquam odio euismod sit amet. Quisque laoreet sem sit amet orci ullamcorper at ultricies metus viverra. Pellentesque arcu mauris, malesuada quis ornare accumsan, blandit sed diam.', 'TOP 10 BREAKING NEWS OF THE GIANTS', '', 'publish', 'open', 'open', '', 'top-10-breaking-news-of-the-giants-2', '', '', '2016-08-02 09:14:50', '2016-08-02 09:14:50', '', 0, 'http://futurify.nguyenbui.name.vn/?p=39', 0, 'post', '', 0),
(40, 2, '2016-07-26 09:30:43', '2016-07-26 09:30:43', '', 'group-4-copy-3', '', 'inherit', 'open', 'closed', '', 'group-4-copy-3', '', '', '2016-07-26 09:30:43', '2016-07-26 09:30:43', '', 39, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/group-4-copy-3.png', 0, 'attachment', 'image/png', 0),
(41, 2, '2016-07-26 09:30:58', '2016-07-26 09:30:58', '', 'TOP 10 BREAKING NEWS OF THE GIANTS', '', 'inherit', 'closed', 'closed', '', '39-revision-v1', '', '', '2016-07-26 09:30:58', '2016-07-26 09:30:58', '', 39, 'http://futurify.nguyenbui.name.vn/index.php/2016/07/26/39-revision-v1/', 0, 'revision', '', 0),
(42, 2, '2016-07-26 09:33:52', '2016-07-26 09:33:52', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium.\r\n\r\n&nbsp;\r\n\r\n<span class="h3">HEADNING TITLE</span>\r\n\r\n&nbsp;\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium sit amet quis magna. Aenean velit odio, elementum in tempus ut, vehicula eu diam. Pellentesque rhoncus aliquam mattis. Ut vulputate eros sed felis sodales nec vulputate justo hendrerit. Vivamus varius pretium ligula, a aliquam odio euismod sit amet. Quisque laoreet sem sit amet orci ullamcorper at ultricies metus viverra. Pellentesque arcu mauris, malesuada quis ornare accumsan, blandit sed diam.\r\n\r\n<img class="alignnone wp-image-182 size-full" src="http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/group-1.png" alt="group" width="1002" height="564" />\r\n\r\n&nbsp;\r\n\r\n<span class="h3">HEADNING TITLE</span>\r\n\r\n&nbsp;\r\n\r\n&nbsp;\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium sit amet quis magna. Aenean velit odio, elementum in tempus ut, vehicula eu diam. Pellentesque rhoncus aliquam mattis. Ut vulputate eros sed felis sodales nec vulputate justo hendrerit. Vivamus varius pretium ligula, a aliquam odio euismod sit amet. Quisque laoreet sem sit amet orci ullamcorper at ultricies metus viverra. Pellentesque arcu mauris, malesuada quis ornare accumsan, blandit sed diam.', 'TOP 10 BREAKING NEWS OF THE GIANTS', '', 'publish', 'open', 'open', '', 'top-10-breaking-news-of-the-giants-3', '', '', '2016-08-02 09:13:53', '2016-08-02 09:13:53', '', 0, 'http://futurify.nguyenbui.name.vn/?p=42', 0, 'post', '', 0),
(44, 2, '2016-07-26 09:33:47', '2016-07-26 09:33:47', '', 'group-4-copy-6@3x', '', 'inherit', 'open', 'closed', '', 'group-4-copy-63x', '', '', '2016-07-26 09:33:47', '2016-07-26 09:33:47', '', 42, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/group-4-copy-6@3x.png', 0, 'attachment', 'image/png', 0),
(45, 2, '2016-07-26 09:33:52', '2016-07-26 09:33:52', '', 'TOP 10 BREAKING NEWS OF THE GIANTS', '', 'inherit', 'closed', 'closed', '', '42-revision-v1', '', '', '2016-07-26 09:33:52', '2016-07-26 09:33:52', '', 42, 'http://futurify.nguyenbui.name.vn/index.php/2016/07/26/42-revision-v1/', 0, 'revision', '', 0),
(47, 3, '2016-07-26 09:39:43', '2016-07-26 09:39:43', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium.\r\n\r\n<span class="h3">HEADNING TITLE</span>\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium sit amet quis magna. Aenean velit odio, elementum in tempus ut, vehicula eu diam. Pellentesque rhoncus aliquam mattis. Ut vulputate eros sed felis sodales nec vulputate justo hendrerit. Vivamus varius pretium ligula, a aliquam odio euismod sit amet. Quisque laoreet sem sit amet orci ullamcorper at ultricies metus viverra. Pellentesque arcu mauris, malesuada quis ornare accumsan, blandit sed diam.\r\n\r\n<img class="alignnone wp-image-182 size-full" src="http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/group-1.png" alt="group" width="1002" height="564" />\r\n\r\n<span class="h3">HEADNING TITLE</span>\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium sit amet quis magna. Aenean velit odio, elementum in tempus ut, vehicula eu diam. Pellentesque rhoncus aliquam mattis. Ut vulputate eros sed felis sodales nec vulputate justo hendrerit. Vivamus varius pretium ligula, a aliquam odio euismod sit amet. Quisque laoreet sem sit amet orci ullamcorper at ultricies metus viverra. Pellentesque arcu mauris, malesuada quis ornare accumsan, blandit sed diam.', 'TECH CORNER: IBM WATSON DIALOG AND ASP.NET 101', '', 'publish', 'open', 'open', '', 'tech-corner-ibm-watson-dialog-and-asp-net-101', '', '', '2016-08-02 09:14:27', '2016-08-02 09:14:27', '', 0, 'http://futurify.nguyenbui.name.vn/?p=47', 0, 'post', '', 0),
(48, 3, '2016-07-26 09:39:31', '2016-07-26 09:39:31', '', '2@3x', '', 'inherit', 'open', 'closed', '', '23x', '', '', '2016-07-26 09:39:31', '2016-07-26 09:39:31', '', 47, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/2@3x.png', 0, 'attachment', 'image/png', 0),
(49, 3, '2016-07-26 09:39:43', '2016-07-26 09:39:43', '', 'TECH CORNER: IBM WATSON DIALOG AND ASP.NET 101', '', 'inherit', 'closed', 'closed', '', '47-revision-v1', '', '', '2016-07-26 09:39:43', '2016-07-26 09:39:43', '', 47, 'http://futurify.nguyenbui.name.vn/index.php/2016/07/26/47-revision-v1/', 0, 'revision', '', 0),
(50, 3, '2016-07-26 09:41:00', '2016-07-26 09:41:00', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium.\r\n\r\n&nbsp;\r\n\r\n<span class="h3">HEADNING TITLE</span>\r\n\r\n&nbsp;\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium sit amet quis magna. Aenean velit odio, elementum in tempus ut, vehicula eu diam. Pellentesque rhoncus aliquam mattis. Ut vulputate eros sed felis sodales nec vulputate justo hendrerit. Vivamus varius pretium ligula, a aliquam odio euismod sit amet. Quisque laoreet sem sit amet orci ullamcorper at ultricies metus viverra. Pellentesque arcu mauris, malesuada quis ornare accumsan, blandit sed diam.\r\n\r\n<img class="alignnone wp-image-182 size-full" src="http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/group-1.png" alt="group" width="1002" height="564" />\r\n\r\n&nbsp;\r\n\r\n<span class="h3">HEADNING TITLE</span>\r\n\r\n&nbsp;\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium sit amet quis magna. Aenean velit odio, elementum in tempus ut, vehicula eu diam. Pellentesque rhoncus aliquam mattis. Ut vulputate eros sed felis sodales nec vulputate justo hendrerit. Vivamus varius pretium ligula, a aliquam odio euismod sit amet. Quisque laoreet sem sit amet orci ullamcorper at ultricies metus viverra. Pellentesque arcu mauris, malesuada quis ornare accumsan, blandit sed diam.', 'TECH CORNER: IBM WATSON DIALOG AND ASP.NET 101', '', 'publish', 'open', 'open', '', 'tech-corner-ibm-watson-dialog-and-asp-net-101-2', '', '', '2016-08-02 09:12:31', '2016-08-02 09:12:31', '', 0, 'http://futurify.nguyenbui.name.vn/?p=50', 0, 'post', '', 0),
(51, 3, '2016-07-26 09:40:44', '2016-07-26 09:40:44', '', '3@3x', '', 'inherit', 'open', 'closed', '', '33x', '', '', '2016-07-26 09:40:44', '2016-07-26 09:40:44', '', 50, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/3@3x.png', 0, 'attachment', 'image/png', 0),
(52, 3, '2016-07-26 09:41:00', '2016-07-26 09:41:00', '', 'TECH CORNER: IBM WATSON DIALOG AND ASP.NET 101', '', 'inherit', 'closed', 'closed', '', '50-revision-v1', '', '', '2016-07-26 09:41:00', '2016-07-26 09:41:00', '', 50, 'http://futurify.nguyenbui.name.vn/index.php/2016/07/26/50-revision-v1/', 0, 'revision', '', 0),
(53, 3, '2016-07-26 09:42:16', '2016-07-26 09:42:16', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium.\r\n\r\n<span class="h3">HEADNING TITLE</span>\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium sit amet quis magna. Aenean velit odio, elementum in tempus ut, vehicula eu diam. Pellentesque rhoncus aliquam mattis. Ut vulputate eros sed felis sodales nec vulputate justo hendrerit. Vivamus varius pretium ligula, a aliquam odio euismod sit amet. Quisque laoreet sem sit amet orci ullamcorper at ultricies metus viverra. Pellentesque arcu mauris, malesuada quis ornare accumsan, blandit sed diam.\r\n\r\n<img class="alignnone wp-image-182 size-full" src="http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/group-1.png" alt="group" width="1002" height="564" />\r\n\r\n<span class="h3">HEADNING TITLE</span>\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium sit amet quis magna. Aenean velit odio, elementum in tempus ut, vehicula eu diam. Pellentesque rhoncus aliquam mattis. Ut vulputate eros sed felis sodales nec vulputate justo hendrerit. Vivamus varius pretium ligula, a aliquam odio euismod sit amet. Quisque laoreet sem sit amet orci ullamcorper at ultricies metus viverra. Pellentesque arcu mauris, malesuada quis ornare accumsan, blandit sed diam.', 'TECH CORNER: IBM WATSON DIALOG AND ASP.NET 101', '', 'publish', 'open', 'open', '', 'tech-corner-ibm-watson-dialog-and-asp-net-101-3', '', '', '2016-08-02 09:05:21', '2016-08-02 09:05:21', '', 0, 'http://futurify.nguyenbui.name.vn/?p=53', 0, 'post', '', 0),
(54, 3, '2016-07-26 09:42:00', '2016-07-26 09:42:00', '', 'group-4-copy-4@3x', '', 'inherit', 'open', 'closed', '', 'group-4-copy-43x', '', '', '2016-07-26 09:42:00', '2016-07-26 09:42:00', '', 53, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/group-4-copy-4@3x.png', 0, 'attachment', 'image/png', 0),
(55, 3, '2016-07-26 09:42:16', '2016-07-26 09:42:16', '', 'TECH CORNER: IBM WATSON DIALOG AND ASP.NET 101', '', 'inherit', 'closed', 'closed', '', '53-revision-v1', '', '', '2016-07-26 09:42:16', '2016-07-26 09:42:16', '', 53, 'http://futurify.nguyenbui.name.vn/index.php/2016/07/26/53-revision-v1/', 0, 'revision', '', 0),
(56, 1, '2016-08-04 16:37:17', '2016-08-04 16:37:17', '<div class="bl-blog-list-title">\n<h1 class="black-title">SHARING IS CARING</h1>\nA place we share to each other, care of things around us. It\'s our pleasure to share culture, thoughts, interests in technology with you - our clients as well as the new visitors\n\n</div>', 'WE SHARE', '', 'inherit', 'closed', 'closed', '', '10-autosave-v1', '', '', '2016-08-04 16:37:17', '2016-08-04 16:37:17', '', 10, 'http://futurify.nguyenbui.name.vn/index.php/2016/07/26/10-autosave-v1/', 0, 'revision', '', 0),
(57, 1, '2016-07-26 13:55:17', '2016-07-26 13:55:17', '[ajax_load_more post_type="post" posts_per_page="6" max_pages="3" container_type="div" css_classes="col-xs-12 col-sm-12 col-md-12"]', 'WE SHARE', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2016-07-26 13:55:17', '2016-07-26 13:55:17', '', 10, 'http://futurify.nguyenbui.name.vn/index.php/2016/07/26/10-revision-v1/', 0, 'revision', '', 0),
(58, 1, '2016-07-26 14:04:36', '2016-07-26 14:04:36', '[ajax_load_more post_type="post" posts_per_page="6" max_pages="3" container_type="div" css_classes="col-xs-12 col-sm-12 col-md-12" button_loading_label=""]', 'WE SHARE', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2016-07-26 14:04:36', '2016-07-26 14:04:36', '', 10, 'http://futurify.nguyenbui.name.vn/index.php/2016/07/26/10-revision-v1/', 0, 'revision', '', 0),
(59, 1, '2016-07-26 14:05:04', '2016-07-26 14:05:04', '[ajax_load_more post_type="post" posts_per_page="6" max_pages="3" container_type="div" css_classes="col-xs-12 col-sm-12 col-md-12" button_loading_label=" "]', 'WE SHARE', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2016-07-26 14:05:04', '2016-07-26 14:05:04', '', 10, 'http://futurify.nguyenbui.name.vn/index.php/2016/07/26/10-revision-v1/', 0, 'revision', '', 0),
(60, 1, '2016-07-26 14:08:06', '2016-07-26 14:08:06', '[ajax_load_more post_type="post" posts_per_page="6" max_pages="3" container_type="div" css_classes="col-xs-12 col-sm-12 col-md-12" button_loading_label="&amp;nbsp;"]', 'WE SHARE', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2016-07-26 14:08:06', '2016-07-26 14:08:06', '', 10, 'http://futurify.nguyenbui.name.vn/index.php/2016/07/26/10-revision-v1/', 0, 'revision', '', 0),
(61, 1, '2016-07-26 15:06:10', '2016-07-26 15:06:10', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium.\r\n\r\n&nbsp;\r\n\r\n<span class="h3">HEADNING TITLE</span>\r\n\r\n&nbsp;\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium sit amet quis magna. Aenean velit odio, elementum in tempus ut, vehicula eu diam. Pellentesque rhoncus aliquam mattis. Ut vulputate eros sed felis sodales nec vulputate justo hendrerit. Vivamus varius pretium ligula, a aliquam odio euismod sit amet. Quisque laoreet sem sit amet orci ullamcorper at ultricies metus viverra. Pellentesque arcu mauris, malesuada quis ornare accumsan, blandit sed diam.\r\n\r\n&nbsp;\r\n\r\n<img class="alignnone wp-image-182 size-full" src="http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/group-1.png" alt="group" width="1002" height="564" />\r\n\r\n&nbsp;\r\n\r\n<span class="h3">HEADNING TITLE</span>\r\n\r\n&nbsp;\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium sit amet quis magna. Aenean velit odio, elementum in tempus ut, vehicula eu diam. Pellentesque rhoncus aliquam mattis. Ut vulputate eros sed felis sodales nec vulputate justo hendrerit. Vivamus varius pretium ligula, a aliquam odio euismod sit amet. Quisque laoreet sem sit amet orci ullamcorper at ultricies metus viverra. Pellentesque arcu mauris, malesuada quis ornare accumsan, blandit sed diam.\r\n\r\n&nbsp;', 'TECH CORNER: IBM WATSON DIALOG AND ASP.NET 101', '', 'publish', 'open', 'open', '', 'tech-corner-ibm-watson-dialog-and-asp-net-101-4', '', '', '2016-08-02 15:26:57', '2016-08-02 15:26:57', '', 0, 'http://futurify.nguyenbui.name.vn/?p=61', 0, 'post', '', 0),
(62, 1, '2016-07-26 15:06:10', '2016-07-26 15:06:10', '', 'TECH CORNER: IBM WATSON DIALOG AND ASP.NET 101', '', 'inherit', 'closed', 'closed', '', '61-revision-v1', '', '', '2016-07-26 15:06:10', '2016-07-26 15:06:10', '', 61, 'http://futurify.nguyenbui.name.vn/index.php/2016/07/26/61-revision-v1/', 0, 'revision', '', 0),
(64, 1, '2016-07-28 15:48:09', '2016-07-28 15:48:09', '<div class="panel-content">\r\n<h3>Let\'s chat and create great works together!!!</h3>\r\nHello, my name is\r\n\r\n<input class="input-style" type="text" />\r\n\r\nReach me at this email\r\n\r\n<input class="input-style" type="email" />\r\n\r\nAnd have conversation of my concern about\r\n\r\n<input class="input-style" type="text" />\r\n\r\n</div>', 'HOME', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2016-08-06 13:02:33', '2016-08-06 13:02:33', '', 0, 'http://futurify.nguyenbui.name.vn/?page_id=64', 0, 'page', '', 0),
(65, 1, '2016-07-28 15:48:09', '2016-07-28 15:48:09', '', 'HOME', '', 'inherit', 'closed', 'closed', '', '64-revision-v1', '', '', '2016-07-28 15:48:09', '2016-07-28 15:48:09', '', 64, 'http://futurify.nguyenbui.name.vn/index.php/2016/07/28/64-revision-v1/', 0, 'revision', '', 0),
(69, 1, '2016-07-29 01:33:45', '2016-07-29 01:33:45', '', 'Home Video', '', 'publish', 'closed', 'closed', '', 'acf_home-video', '', '', '2016-07-31 08:30:02', '2016-07-31 08:30:02', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=acf&#038;p=69', 0, 'acf', '', 0),
(70, 1, '2016-07-29 14:58:33', '2016-07-29 14:58:33', '', 'Project 1', '', 'publish', 'closed', 'closed', '', 'project-1', '', '', '2016-07-29 14:58:33', '2016-07-29 14:58:33', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=project&#038;p=70', 9, 'project', '', 0),
(71, 1, '2016-07-29 14:58:22', '2016-07-29 14:58:22', '', 'project-10', '', 'inherit', 'open', 'closed', '', 'project-10', '', '', '2016-07-29 14:58:22', '2016-07-29 14:58:22', '', 70, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/project-10.png', 0, 'attachment', 'image/png', 0),
(72, 1, '2016-07-29 14:58:46', '2016-07-29 14:58:46', '', 'Project 2', '', 'publish', 'closed', 'closed', '', 'project-2', '', '', '2016-07-29 14:59:05', '2016-07-29 14:59:05', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=project&#038;p=72', 8, 'project', '', 0),
(73, 1, '2016-07-29 14:58:59', '2016-07-29 14:58:59', '', 'project-9', '', 'inherit', 'open', 'closed', '', 'project-9', '', '', '2016-07-29 14:58:59', '2016-07-29 14:58:59', '', 72, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/project-9.png', 0, 'attachment', 'image/png', 0),
(74, 1, '2016-07-29 15:08:43', '2016-07-29 15:08:43', '', 'Project 3', '', 'publish', 'closed', 'closed', '', 'project-3', '', '', '2016-07-29 15:08:43', '2016-07-29 15:08:43', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=project&#038;p=74', 7, 'project', '', 0),
(75, 1, '2016-07-29 15:08:40', '2016-07-29 15:08:40', '', 'project-8', '', 'inherit', 'open', 'closed', '', 'project-8', '', '', '2016-07-29 15:08:40', '2016-07-29 15:08:40', '', 74, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/project-8.png', 0, 'attachment', 'image/png', 0),
(76, 1, '2016-07-29 15:09:13', '2016-07-29 15:09:13', '', 'Project 4', '', 'publish', 'closed', 'closed', '', 'project-4', '', '', '2016-07-29 15:09:13', '2016-07-29 15:09:13', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=project&#038;p=76', 6, 'project', '', 0),
(77, 1, '2016-07-29 15:09:07', '2016-07-29 15:09:07', '', 'project-7', '', 'inherit', 'open', 'closed', '', 'project-7', '', '', '2016-07-29 15:09:07', '2016-07-29 15:09:07', '', 76, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/project-7.png', 0, 'attachment', 'image/png', 0),
(78, 1, '2016-07-29 15:09:36', '2016-07-29 15:09:36', '', 'Project 5', '', 'publish', 'closed', 'closed', '', 'project-5', '', '', '2016-07-29 15:09:48', '2016-07-29 15:09:48', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=project&#038;p=78', 5, 'project', '', 0),
(79, 1, '2016-07-29 15:09:45', '2016-07-29 15:09:45', '', 'project-5', '', 'inherit', 'open', 'closed', '', 'project-5-2', '', '', '2016-07-29 15:09:45', '2016-07-29 15:09:45', '', 78, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/project-5.png', 0, 'attachment', 'image/png', 0),
(80, 1, '2016-07-29 15:10:38', '2016-07-29 15:10:38', '', 'Project 6', '', 'publish', 'closed', 'closed', '', 'project-6', '', '', '2016-07-29 15:10:38', '2016-07-29 15:10:38', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=project&#038;p=80', 4, 'project', '', 0),
(81, 1, '2016-07-29 15:10:35', '2016-07-29 15:10:35', '', 'project-4', '', 'inherit', 'open', 'closed', '', 'project-4-2', '', '', '2016-07-29 15:10:35', '2016-07-29 15:10:35', '', 80, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/project-4.png', 0, 'attachment', 'image/png', 0),
(82, 1, '2016-07-29 15:10:53', '2016-07-29 15:10:53', '', 'Project 7', '', 'publish', 'closed', 'closed', '', 'project-7', '', '', '2016-07-29 15:10:53', '2016-07-29 15:10:53', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=project&#038;p=82', 2, 'project', '', 0),
(83, 1, '2016-07-29 15:10:51', '2016-07-29 15:10:51', '', 'project-3', '', 'inherit', 'open', 'closed', '', 'project-3-2', '', '', '2016-07-29 15:10:51', '2016-07-29 15:10:51', '', 82, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/project-3.png', 0, 'attachment', 'image/png', 0),
(84, 1, '2016-07-29 15:11:10', '2016-07-29 15:11:10', '', 'Project 8', '', 'publish', 'closed', 'closed', '', 'project-8', '', '', '2016-07-29 15:11:10', '2016-07-29 15:11:10', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=project&#038;p=84', 1, 'project', '', 0),
(85, 1, '2016-07-29 15:11:06', '2016-07-29 15:11:06', '', 'project-2', '', 'inherit', 'open', 'closed', '', 'project-2-2', '', '', '2016-07-29 15:11:06', '2016-07-29 15:11:06', '', 84, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/project-2.png', 0, 'attachment', 'image/png', 0),
(86, 1, '2016-07-29 15:11:37', '2016-07-29 15:11:37', '', 'Project 9', '', 'publish', 'closed', 'closed', '', 'project-9', '', '', '2016-08-06 07:55:10', '2016-08-06 07:55:10', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=project&#038;p=86', 0, 'project', '', 0),
(87, 1, '2016-07-29 15:11:24', '2016-07-29 15:11:24', '', 'project-1', '', 'inherit', 'open', 'closed', '', 'project-1-2', '', '', '2016-07-29 15:11:24', '2016-07-29 15:11:24', '', 86, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/project-1.png', 0, 'attachment', 'image/png', 0),
(88, 1, '2016-07-30 16:11:16', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2016-07-30 16:11:16', '0000-00-00 00:00:00', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=acf&p=88', 0, 'acf', '', 0),
(89, 1, '2016-07-30 16:17:25', '2016-07-30 16:17:25', '<div class="bl-our-project-content">\r\n<h2>“The FUTURIFY team refined our brand, created a rockin\'</h2>\r\n<h2>we\'re extremely proud of. We heart FUTURIFY.”</h2>\r\n<h2>style guide and brand book, and designed a web site that</h2>\r\n<h5>KONEKA’S TESTIMONAL</h5>\r\n</div>', 'Quote', '', 'publish', 'closed', 'closed', '', 'quote', '', '', '2016-07-30 16:17:25', '2016-07-30 16:17:25', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=project&#038;p=89', 3, 'project', '', 0),
(90, 1, '2016-07-30 16:28:54', '2016-07-30 16:28:54', '<div class="bl-our-project-des">\n<h2>FUTURIFY is one of the best design agencies</h2>\n<h2>I’ve worked with not only on a professional level, but personality wise as well.</h2>\n<h5>ACTIONAID VIETNAM’S TESTIMONAL</h5>\n</div>', 'PROJECTS', '', 'inherit', 'closed', 'closed', '', '6-autosave-v1', '', '', '2016-07-30 16:28:54', '2016-07-30 16:28:54', '', 6, 'http://futurify.nguyenbui.name.vn/index.php/2016/07/30/6-autosave-v1/', 0, 'revision', '', 0),
(91, 1, '2016-07-30 16:29:23', '2016-07-30 16:29:23', '<div class="bl-our-project-des">\r\n<h2>FUTURIFY is one of the best design agencies</h2>\r\n<h2>I’ve worked with not only on a professional level, but personality wise as well.</h2>\r\n<h5>ACTIONAID VIETNAM’S TESTIMONAL</h5>\r\n</div>', 'PROJECTS', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2016-07-30 16:29:23', '2016-07-30 16:29:23', '', 6, 'http://futurify.nguyenbui.name.vn/index.php/2016/07/30/6-revision-v1/', 0, 'revision', '', 0),
(92, 1, '2016-07-30 16:47:26', '2016-07-30 16:47:26', '', 'CONTACT US', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2016-07-30 16:47:26', '2016-07-30 16:47:26', '', 12, 'http://futurify.nguyenbui.name.vn/index.php/2016/07/30/12-revision-v1/', 0, 'revision', '', 0),
(93, 1, '2016-07-30 16:49:22', '2016-07-30 16:49:22', '', 'CONTACT US', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2016-07-30 16:49:22', '2016-07-30 16:49:22', '', 12, 'http://futurify.nguyenbui.name.vn/index.php/2016/07/30/12-revision-v1/', 0, 'revision', '', 0),
(94, 1, '2016-07-30 16:59:16', '2016-07-30 16:59:16', '', 'CONTACT US', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2016-07-30 16:59:16', '2016-07-30 16:59:16', '', 12, 'http://futurify.nguyenbui.name.vn/index.php/2016/07/30/12-revision-v1/', 0, 'revision', '', 0),
(95, 1, '2016-07-30 17:00:31', '2016-07-30 17:00:31', '', 'CONTACT US', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2016-07-30 17:00:31', '2016-07-30 17:00:31', '', 12, 'http://futurify.nguyenbui.name.vn/index.php/2016/07/30/12-revision-v1/', 0, 'revision', '', 0),
(96, 1, '2016-07-30 17:01:02', '2016-07-30 17:01:02', '', 'CONTACT US', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2016-07-30 17:01:02', '2016-07-30 17:01:02', '', 12, 'http://futurify.nguyenbui.name.vn/index.php/2016/07/30/12-revision-v1/', 0, 'revision', '', 0),
(97, 1, '2016-07-30 17:02:49', '2016-07-30 17:02:49', '', 'CONTACT US', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2016-07-30 17:02:49', '2016-07-30 17:02:49', '', 12, 'http://futurify.nguyenbui.name.vn/index.php/2016/07/30/12-revision-v1/', 0, 'revision', '', 0),
(98, 1, '2016-07-31 03:59:30', '2016-07-31 03:59:30', '', 'John Doe', '', 'publish', 'closed', 'closed', '', 'member1', '', '', '2016-08-02 15:11:29', '2016-08-02 15:11:29', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=member&#038;p=98', 12, 'member', '', 0),
(99, 1, '2016-07-31 03:59:24', '2016-07-31 03:59:24', '', 'team-people', '', 'inherit', 'open', 'closed', '', 'team-people', '', '', '2016-07-31 03:59:24', '2016-07-31 03:59:24', '', 98, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/team-people.png', 0, 'attachment', 'image/png', 0),
(100, 1, '2016-07-31 04:00:29', '2016-07-31 04:00:29', '', 'Tri Ho', '', 'publish', 'closed', 'closed', '', 'member2', '', '', '2016-08-02 15:12:39', '2016-08-02 15:12:39', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=member&#038;p=100', 11, 'member', '', 0),
(101, 1, '2016-07-31 04:04:13', '2016-07-31 04:04:13', '', 'Lizz Nguyen', '', 'publish', 'closed', 'closed', '', 'member3', '', '', '2016-08-02 15:13:06', '2016-08-02 15:13:06', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=member&#038;p=101', 10, 'member', '', 0),
(102, 1, '2016-07-31 04:04:06', '2016-07-31 04:04:06', '', '0F0C1AF0-536D-4B4E-8856-0323C452BE54', '', 'inherit', 'open', 'closed', '', '0f0c1af0-536d-4b4e-8856-0323c452be54', '', '', '2016-07-31 04:04:06', '2016-07-31 04:04:06', '', 101, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/0F0C1AF0-536D-4B4E-8856-0323C452BE54.png', 0, 'attachment', 'image/png', 0),
(103, 1, '2016-07-31 04:04:06', '2016-07-31 04:04:06', '', '1CEA7C56-2503-4399-99F4-BDF36BB8035D', '', 'inherit', 'open', 'closed', '', '1cea7c56-2503-4399-99f4-bdf36bb8035d', '', '', '2016-07-31 04:04:06', '2016-07-31 04:04:06', '', 101, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/1CEA7C56-2503-4399-99F4-BDF36BB8035D.png', 0, 'attachment', 'image/png', 0),
(104, 1, '2016-07-31 04:04:06', '2016-07-31 04:04:06', '', '7C9E320B-01DC-4E64-B2F5-E064D8B79E35', '', 'inherit', 'open', 'closed', '', '7c9e320b-01dc-4e64-b2f5-e064d8b79e35', '', '', '2016-07-31 04:04:06', '2016-07-31 04:04:06', '', 101, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/7C9E320B-01DC-4E64-B2F5-E064D8B79E35.png', 0, 'attachment', 'image/png', 0),
(105, 1, '2016-07-31 04:04:07', '2016-07-31 04:04:07', '', '28B6543B-5ED4-4B44-8A79-6715CC92381E', '', 'inherit', 'open', 'closed', '', '28b6543b-5ed4-4b44-8a79-6715cc92381e', '', '', '2016-07-31 04:04:07', '2016-07-31 04:04:07', '', 101, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/28B6543B-5ED4-4B44-8A79-6715CC92381E.png', 0, 'attachment', 'image/png', 0),
(106, 1, '2016-07-31 04:04:29', '2016-07-31 04:04:29', '', 'Nguyen Bui', '', 'publish', 'closed', 'closed', '', 'member4', '', '', '2016-08-02 15:13:57', '2016-08-02 15:13:57', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=member&#038;p=106', 8, 'member', '', 0),
(107, 1, '2016-07-31 04:04:43', '2016-07-31 04:04:43', '', 'Lina Vo', '', 'publish', 'closed', 'closed', '', 'member5', '', '', '2016-08-02 15:14:27', '2016-08-02 15:14:27', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=member&#038;p=107', 7, 'member', '', 0),
(108, 1, '2016-07-31 04:08:09', '2016-07-31 04:08:09', '', 'Nguyen Ly', '', 'publish', 'closed', 'closed', '', 'member6', '', '', '2016-08-02 15:17:03', '2016-08-02 15:17:03', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=member&#038;p=108', 6, 'member', '', 0) ;
INSERT INTO `lrpmqdj9_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(109, 1, '2016-07-31 04:08:28', '2016-07-31 04:08:28', '', 'Jenny Tran', '', 'publish', 'closed', 'closed', '', 'member7', '', '', '2016-08-02 15:14:45', '2016-08-02 15:14:45', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=member&#038;p=109', 5, 'member', '', 0),
(110, 1, '2016-07-31 04:08:40', '2016-07-31 04:08:40', '', 'Maria Truong', '', 'publish', 'closed', 'closed', '', 'member7-2', '', '', '2016-08-02 15:15:46', '2016-08-02 15:15:46', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=member&#038;p=110', 3, 'member', '', 0),
(111, 1, '2016-07-31 04:08:51', '2016-07-31 04:08:51', '', 'Tin De', '', 'publish', 'closed', 'closed', '', 'member8', '', '', '2016-08-02 15:16:34', '2016-08-02 15:16:34', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=member&#038;p=111', 2, 'member', '', 0),
(112, 1, '2016-07-31 04:09:04', '2016-07-31 04:09:04', '', 'Chikato Nguyen', '', 'publish', 'closed', 'closed', '', 'member9', '', '', '2016-08-02 15:16:13', '2016-08-02 15:16:13', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=member&#038;p=112', 0, 'member', '', 0),
(113, 1, '2016-07-31 04:11:05', '2016-07-31 04:11:05', '<div class="team-content">\r\n\r\nWe are a team of honest, responsible and passionate engineers who strive for greatness of products and services to empower your business success.\r\n\r\n</div>', 'Quote1', '', 'publish', 'closed', 'closed', '', 'quote1', '', '', '2016-07-31 04:11:05', '2016-07-31 04:11:05', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=member&#038;p=113', 1, 'member', '', 0),
(114, 1, '2016-07-31 04:11:33', '2016-07-31 04:11:33', '<div class="team-content team-red">\r\n\r\nFuturify is not only where we work but also where we share, laugh, collaborate, debate, nap, drink, eat and code. It’s where we feel like home. We work together as team to make you successful.\r\n\r\n</div>', 'Quote2', '', 'publish', 'closed', 'closed', '', 'quote2', '', '', '2016-07-31 04:11:33', '2016-07-31 04:11:33', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=member&#038;p=114', 9, 'member', '', 0),
(115, 1, '2016-07-31 05:31:07', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2016-07-31 05:31:07', '0000-00-00 00:00:00', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=home-video&p=115', 0, 'home-video', '', 0) ;
INSERT INTO `lrpmqdj9_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(116, 1, '2016-07-31 05:41:09', '2016-07-31 05:41:09', '', 'Video5', '', 'trash', 'closed', 'closed', '', 'video5__trashed', '', '', '2016-08-06 11:35:00', '2016-08-06 11:35:00', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=home-video&#038;p=116', 0, 'home-video', '', 0),
(117, 1, '2016-07-31 05:38:51', '2016-07-31 05:38:51', '', 'video-1', '', 'inherit', 'open', 'closed', '', 'video-1', '', '', '2016-07-31 05:38:51', '2016-07-31 05:38:51', '', 116, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/video-1.mp4', 0, 'attachment', 'video/mp4', 0),
(118, 1, '2016-07-31 05:39:26', '2016-07-31 05:39:26', '', 'video-2', '', 'inherit', 'open', 'closed', '', 'video-2', '', '', '2016-07-31 05:39:26', '2016-07-31 05:39:26', '', 116, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/video-2.mp4', 0, 'attachment', 'video/mp4', 0),
(119, 1, '2016-07-31 05:39:26', '2016-07-31 05:39:26', '', 'video-3', '', 'inherit', 'open', 'closed', '', 'video-3', '', '', '2016-07-31 05:39:26', '2016-07-31 05:39:26', '', 116, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/video-3.mp4', 0, 'attachment', 'video/mp4', 0),
(120, 1, '2016-07-31 05:39:27', '2016-07-31 05:39:27', '', 'video-4', '', 'inherit', 'open', 'closed', '', 'video-4', '', '', '2016-07-31 05:39:27', '2016-07-31 05:39:27', '', 116, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/video-4.mp4', 0, 'attachment', 'video/mp4', 0),
(121, 1, '2016-07-31 05:40:55', '2016-07-31 05:40:55', '', 'video-5', '', 'inherit', 'open', 'closed', '', 'video-5', '', '', '2016-07-31 05:40:55', '2016-07-31 05:40:55', '', 116, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/video-5.mp4', 0, 'attachment', 'video/mp4', 0),
(122, 1, '2016-07-31 05:52:06', '2016-07-31 05:52:06', '', 'Video4', '', 'trash', 'closed', 'closed', '', 'video4__trashed', '', '', '2016-08-06 11:34:57', '2016-08-06 11:34:57', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=home-video&#038;p=122', 0, 'home-video', '', 0),
(123, 1, '2016-07-31 05:52:20', '2016-07-31 05:52:20', '', 'Video3', '', 'trash', 'closed', 'closed', '', 'video3__trashed', '', '', '2016-08-06 11:34:55', '2016-08-06 11:34:55', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=home-video&#038;p=123', 0, 'home-video', '', 0),
(124, 1, '2016-07-31 05:52:35', '2016-07-31 05:52:35', '', 'Video2', '', 'trash', 'closed', 'closed', '', 'video2__trashed', '', '', '2016-08-06 11:34:52', '2016-08-06 11:34:52', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=home-video&#038;p=124', 0, 'home-video', '', 0),
(125, 1, '2016-07-31 05:52:55', '2016-07-31 05:52:55', '<div class="caption-content">\r\n<h2>OUR MISSION</h2>\r\nWe offer remote world-class engineers and build reliable, scalable and measurable solutions to help you grow and succeed\r\n\r\n</div>', 'Video1', '', 'publish', 'closed', 'closed', '', 'video1', '', '', '2016-07-31 08:28:10', '2016-07-31 08:28:10', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=home-video&#038;p=125', 0, 'home-video', '', 0),
(126, 1, '2016-07-31 08:27:10', '2016-07-31 08:27:10', '<div class="caption-content">\n<h2>OUR MISSION</h2>\nWe offer remote world-class engineers and build reliable, scalable and measurable solutions to help you grow and succeed\n\n</div>', 'Video1', '', 'inherit', 'closed', 'closed', '', '125-autosave-v1', '', '', '2016-07-31 08:27:10', '2016-07-31 08:27:10', '', 125, 'http://futurify.nguyenbui.name.vn/index.php/2016/07/31/125-autosave-v1/', 0, 'revision', '', 0),
(127, 1, '2016-07-31 08:27:35', '2016-07-31 08:27:35', '<div class="caption-content">\r\n<h2>OUR MISSION</h2>\r\nWe offer remote world-class engineers and build reliable, scalable and measurable solutions to help you grow and succeed\r\n\r\n</div>', 'Caption Template', '', 'publish', 'closed', 'closed', '', 'caption-template', '', '', '2016-07-31 08:27:35', '2016-07-31 08:27:35', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=tinymcetemplates&#038;p=127', 0, 'tinymcetemplates', '', 0),
(128, 1, '2016-07-31 08:27:35', '2016-07-31 08:27:35', '<div class="caption-content">\r\n<h2>OUR MISSION</h2>\r\nWe offer remote world-class engineers and build reliable, scalable and measurable solutions to help you grow and succeed\r\n\r\n</div>', 'Caption Template', '', 'inherit', 'closed', 'closed', '', '127-revision-v1', '', '', '2016-07-31 08:27:35', '2016-07-31 08:27:35', '', 127, 'http://futurify.nguyenbui.name.vn/index.php/2016/07/31/127-revision-v1/', 0, 'revision', '', 0),
(129, 1, '2016-07-31 08:38:11', '2016-07-31 08:38:11', '<h1 class="black-title">THE FUTURIFY STORIES</h1>', 'Heading Black Title', '', 'publish', 'closed', 'closed', '', 'heading-title', '', '', '2016-07-31 08:38:51', '2016-07-31 08:38:51', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=tinymcetemplates&#038;p=129', 0, 'tinymcetemplates', '', 0),
(130, 1, '2016-07-31 08:38:11', '2016-07-31 08:38:11', '<h1 class="black-title">THE FUTURIFY STORIES</h1>', 'Heading Title', '', 'inherit', 'closed', 'closed', '', '129-revision-v1', '', '', '2016-07-31 08:38:11', '2016-07-31 08:38:11', '', 129, 'http://futurify.nguyenbui.name.vn/index.php/2016/07/31/129-revision-v1/', 0, 'revision', '', 0),
(131, 1, '2016-07-31 08:38:20', '2016-07-31 08:38:20', '<h1 class="black-title">THE FUTURIFY STORIES</h1>', 'Heading Black Title', '', 'inherit', 'closed', 'closed', '', '129-revision-v1', '', '', '2016-07-31 08:38:20', '2016-07-31 08:38:20', '', 129, 'http://futurify.nguyenbui.name.vn/index.php/2016/07/31/129-revision-v1/', 0, 'revision', '', 0),
(132, 1, '2016-08-01 13:27:37', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2016-08-01 13:27:37', '0000-00-00 00:00:00', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=staff&p=132', 0, 'staff', '', 0),
(133, 1, '2016-08-01 13:29:50', '2016-08-01 13:29:50', '', 'Process', '', 'publish', 'closed', 'closed', '', 'acf_process', '', '', '2016-08-01 13:32:40', '2016-08-01 13:32:40', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=acf&#038;p=133', 0, 'acf', '', 0),
(134, 1, '2016-08-01 13:35:48', '2016-08-01 13:35:48', 'We offer world-class engineers who work as Part-time (Pay as you go) or Full-time (Monthly subscription) remote staffs. Our talented engineers will work closely with your team to not only finish the assigned tasks, but also drive workflow right away.', 'MODELS', '', 'publish', 'closed', 'closed', '', 'models', '', '', '2016-08-01 13:35:48', '2016-08-01 13:35:48', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=staff&#038;p=134', 0, 'staff', '', 0),
(135, 1, '2016-08-01 13:34:41', '2016-08-01 13:34:41', '', 'line-models', '', 'inherit', 'open', 'closed', '', 'line-models', '', '', '2016-08-01 13:34:41', '2016-08-01 13:34:41', '', 134, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/08/line-models.png', 0, 'attachment', 'image/png', 0),
(136, 1, '2016-08-01 13:35:23', '2016-08-01 13:35:23', '', 'red-models', '', 'inherit', 'open', 'closed', '', 'red-models', '', '', '2016-08-01 13:35:23', '2016-08-01 13:35:23', '', 134, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/08/red-models.png', 0, 'attachment', 'image/png', 0),
(137, 1, '2016-08-01 13:37:11', '2016-08-01 13:37:11', '<p>We offer world-class engineers who work as Part-time (Pay as you go) or Full-time (Monthly subscription) remote staffs. Our talented engineers will work closely with your team to not only finish the assigned tasks, but also drive workflow right away.</p>', 'TALENTED ENGINEERS', '', 'publish', 'closed', 'closed', '', 'talented-engineers', '', '', '2016-08-01 13:37:11', '2016-08-01 13:37:11', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=staff&#038;p=137', 1, 'staff', '', 0),
(138, 1, '2016-08-01 13:36:26', '2016-08-01 13:36:26', '', 'line-star-talented', '', 'inherit', 'open', 'closed', '', 'line-star-talented', '', '', '2016-08-01 13:36:26', '2016-08-01 13:36:26', '', 137, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/08/line-star-talented.png', 0, 'attachment', 'image/png', 0),
(139, 1, '2016-08-01 13:36:43', '2016-08-01 13:36:43', '', 'red-star-talented', '', 'inherit', 'open', 'closed', '', 'red-star-talented', '', '', '2016-08-01 13:36:43', '2016-08-01 13:36:43', '', 137, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/08/red-star-talented.png', 0, 'attachment', 'image/png', 0),
(140, 1, '2016-08-01 13:39:37', '2016-08-01 13:39:37', 'Our developers operate on these 3 attributes\r\n\r\nWe offer world-class engineers who work as Part-time (Pay as you go) or Full-time (Monthly subscription) remote staffs. Our talented engineers will work closely with your team to not only finish the assigned tasks, but also drive workflow right away.\r\n\r\n<img class="img-responsive" src="http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/08/project-6.png" alt="staff-img" width="322" height="242" />', 'TECHNOLOGIES & TOOLS', '', 'publish', 'closed', 'closed', '', 'technologies-tools', '', '', '2016-08-01 14:01:19', '2016-08-01 14:01:19', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=staff&#038;p=140', 2, 'staff', '', 0),
(141, 1, '2016-08-01 13:38:44', '2016-08-01 13:38:44', '', 'line-gear', '', 'inherit', 'open', 'closed', '', 'line-gear', '', '', '2016-08-01 13:38:44', '2016-08-01 13:38:44', '', 140, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/08/line-gear.png', 0, 'attachment', 'image/png', 0),
(142, 1, '2016-08-01 13:38:59', '2016-08-01 13:38:59', '', 'red-gear', '', 'inherit', 'open', 'closed', '', 'red-gear', '', '', '2016-08-01 13:38:59', '2016-08-01 13:38:59', '', 140, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/08/red-gear.png', 0, 'attachment', 'image/png', 0),
(143, 1, '2016-08-01 13:40:41', '2016-08-01 13:40:41', '<p>We offer world-class engineers who work as Part-time (Pay as you go) or Full-time (Monthly subscription) remote staffs. Our talented engineers will work closely with your team to not only finish the assigned tasks, but also drive workflow right away.</p>', 'UP - TO - DATE', '', 'publish', 'closed', 'closed', '', 'up-to-date', '', '', '2016-08-01 13:40:41', '2016-08-01 13:40:41', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=staff&#038;p=143', 3, 'staff', '', 0),
(144, 1, '2016-08-01 13:40:26', '2016-08-01 13:40:26', '', 'line-repeat', '', 'inherit', 'open', 'closed', '', 'line-repeat', '', '', '2016-08-01 13:40:26', '2016-08-01 13:40:26', '', 143, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/08/line-repeat.png', 0, 'attachment', 'image/png', 0),
(145, 1, '2016-08-01 13:40:37', '2016-08-01 13:40:37', '', 'red-repeat', '', 'inherit', 'open', 'closed', '', 'red-repeat', '', '', '2016-08-01 13:40:37', '2016-08-01 13:40:37', '', 143, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/08/red-repeat.png', 0, 'attachment', 'image/png', 0),
(146, 1, '2016-08-01 13:41:29', '2016-08-01 13:41:29', '<p>We offer world-class engineers who work as Part-time (Pay as you go) or Full-time (Monthly subscription) remote staffs. Our talented engineers will work closely with your team to not only finish the assigned tasks, but also drive workflow right away.</p>', 'WHICH MODEL IS SUITABLE FOR YOUR BUSINESS?', '', 'publish', 'closed', 'closed', '', 'which-model-is-suitable-for-your-business', '', '', '2016-08-01 13:41:29', '2016-08-01 13:41:29', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=staff&#038;p=146', 4, 'staff', '', 0),
(147, 1, '2016-08-01 13:41:17', '2016-08-01 13:41:17', '', 'line-hand', '', 'inherit', 'open', 'closed', '', 'line-hand', '', '', '2016-08-01 13:41:17', '2016-08-01 13:41:17', '', 146, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/08/line-hand.png', 0, 'attachment', 'image/png', 0),
(148, 1, '2016-08-01 13:41:26', '2016-08-01 13:41:26', '', 'red-hand', '', 'inherit', 'open', 'closed', '', 'red-hand', '', '', '2016-08-01 13:41:26', '2016-08-01 13:41:26', '', 146, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/08/red-hand.png', 0, 'attachment', 'image/png', 0),
(149, 1, '2016-08-01 13:58:25', '2016-08-01 13:58:25', '', 'project-6', '', 'inherit', 'open', 'closed', '', 'project-6-2', '', '', '2016-08-01 13:58:25', '2016-08-01 13:58:25', '', 140, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/08/project-6.png', 0, 'attachment', 'image/png', 0),
(151, 1, '2016-08-01 14:00:16', '2016-08-01 14:00:16', 'Our developers operate on these 3 attributes\n\nWe offer world-class engineers who work as Part-time (Pay as you go) or Full-time (Monthly subscription) remote staffs. Our talented engineers will work closely with your team to not only finish the assigned tasks, but also drive workflow right away.\n\n<img class="img-responsive" src="http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/08/project-6.png" alt="staff-img" width="322" height="242" />\n<img class="img-responsive" src="&lt;?php echo get_bloginfo(\'template_url\').\'/img/content/our_project/project-6.png\'?&gt;" alt="staff-img" />', 'TECHNOLOGIES & TOOLS', '', 'inherit', 'closed', 'closed', '', '140-autosave-v1', '', '', '2016-08-01 14:00:16', '2016-08-01 14:00:16', '', 140, 'http://futurify.nguyenbui.name.vn/index.php/2016/08/01/140-autosave-v1/', 0, 'revision', '', 0),
(152, 1, '2016-08-01 14:09:14', '2016-08-01 14:09:14', '<h1 class="black-title">STAFFING</h1>\r\nWanna develop a new idea or improve on the existing software? Although your organization have their internal development team or not, our honest, quick-witted and hard-working will help you to fulfill your needs to accomplish high-functioning products.', 'STAFFING', '', 'inherit', 'closed', 'closed', '', '23-revision-v1', '', '', '2016-08-01 14:09:14', '2016-08-01 14:09:14', '', 23, 'http://futurify.nguyenbui.name.vn/index.php/2016/08/01/23-revision-v1/', 0, 'revision', '', 0),
(153, 1, '2016-08-01 14:25:01', '2016-08-01 14:25:01', '<h1 class="black-title">MINIMUM<br>VIABLE PRODUCT (MVP)</h1>\n                    <p>Wanna develop a new idea or improve on the existing software? Although your organization have their internal development team or not, our honest, quick-witted and hard-working will help you to fulfill your needs to accomplish high-functioning products. </p>', 'MVP', '', 'inherit', 'closed', 'closed', '', '25-autosave-v1', '', '', '2016-08-01 14:25:01', '2016-08-01 14:25:01', '', 25, 'http://futurify.nguyenbui.name.vn/index.php/2016/08/01/25-autosave-v1/', 0, 'revision', '', 0),
(154, 1, '2016-08-01 14:25:28', '2016-08-01 14:25:28', '<h1 class="black-title">MINIMUM\r\nVIABLE\r\nPRODUCT\r\n(MVP)</h1>\r\nWanna develop a new idea or improve on the existing software? Although your organization have their internal development team or not, our honest, quick-witted and hard-working will help you to fulfill your needs to accomplish high-functioning products.', 'MVP', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2016-08-01 14:25:28', '2016-08-01 14:25:28', '', 25, 'http://futurify.nguyenbui.name.vn/index.php/2016/08/01/25-revision-v1/', 0, 'revision', '', 0),
(155, 1, '2016-08-01 14:28:15', '2016-08-01 14:28:15', 'We offer the affordable cost for passionate, committed and serious entrepreneurs who think long term relationship with their customers as well as their development', '$7000', '', 'publish', 'closed', 'closed', '', '7000', '', '', '2016-08-01 14:28:15', '2016-08-01 14:28:15', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=mvp&#038;p=155', 0, 'mvp', '', 0),
(156, 1, '2016-08-01 14:27:26', '2016-08-01 14:27:26', '', 'line-tag', '', 'inherit', 'open', 'closed', '', 'line-tag', '', '', '2016-08-01 14:27:26', '2016-08-01 14:27:26', '', 155, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/08/line-tag.png', 0, 'attachment', 'image/png', 0),
(157, 1, '2016-08-01 14:27:59', '2016-08-01 14:27:59', '', 'red-tag', '', 'inherit', 'open', 'closed', '', 'red-tag', '', '', '2016-08-01 14:27:59', '2016-08-01 14:27:59', '', 155, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/08/red-tag.png', 0, 'attachment', 'image/png', 0),
(158, 1, '2016-08-01 14:38:39', '2016-08-01 14:38:39', '<span class="red-text-16">Our development schedule is designed to fix 6 weeks </span>\r\n<span class="red-text-16">perfectly in order to build a reliable, innovative and scalable </span>\r\n\r\nWeek 1: requirement gathering, system architecture design and preliminary research\r\n\r\nWeek 2 - 3 (Iteration #1): implement core functionalities\r\n\r\nWeek 4 - 5 (Iteration #2): improve and implement the remaining features\r\n\r\nWeek 6: launch and maintenance', '6 WEEKS', '', 'publish', 'closed', 'closed', '', '6-weeks', '', '', '2016-08-01 14:38:45', '2016-08-01 14:38:45', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=mvp&#038;p=158', 1, 'mvp', '', 0),
(160, 1, '2016-08-01 14:36:28', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2016-08-01 14:36:28', '0000-00-00 00:00:00', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=mvp&p=160', 0, 'mvp', '', 0),
(161, 1, '2016-08-01 14:36:38', '2016-08-01 14:36:38', '', 'red-browser', '', 'inherit', 'open', 'closed', '', 'red-browser', '', '', '2016-08-01 14:36:38', '2016-08-01 14:36:38', '', 160, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/08/red-browser.png', 0, 'attachment', 'image/png', 0),
(162, 1, '2016-08-01 14:37:22', '2016-08-01 14:37:22', '', 'line-calendar', '', 'inherit', 'open', 'closed', '', 'line-calendar', '', '', '2016-08-01 14:37:22', '2016-08-01 14:37:22', '', 158, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/08/line-calendar.png', 0, 'attachment', 'image/png', 0),
(163, 1, '2016-08-01 14:46:14', '2016-08-01 14:46:14', '<p>1 leader who is strong, decisive, open minded, know to deal in truth and would be a process guru. This leader understand clients needs and gather information to transfer to team members.  </p>\r\n                            <p>1 Designer with creative mind, co-operative to work closely with other members and patient to adjust their design to finalize the best one.</p>\r\n                            <p>2 developers with passion in programming, desire to improve skills, logical thinker to figure out solution to problems. Their important traits help them implement MVP\'s functionalities. </p>\r\n                            <p>1 Qa with analytical thinking, strong communication skill, willing to ask question, technical ability and have a point of view of the end user in order to test functionalities as well as review bugs</p>', '5 PEOPLE', '', 'publish', 'closed', 'closed', '', '5-people', '', '', '2016-08-01 14:46:14', '2016-08-01 14:46:14', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=mvp&#038;p=163', 2, 'mvp', '', 0),
(164, 1, '2016-08-01 14:45:40', '2016-08-01 14:45:40', '', 'line-tshirt', '', 'inherit', 'open', 'closed', '', 'line-tshirt', '', '', '2016-08-01 14:45:40', '2016-08-01 14:45:40', '', 163, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/08/line-tshirt.png', 0, 'attachment', 'image/png', 0),
(165, 1, '2016-08-01 14:45:54', '2016-08-01 14:45:54', '', 'red-tshirt', '', 'inherit', 'open', 'closed', '', 'red-tshirt', '', '', '2016-08-01 14:45:54', '2016-08-01 14:45:54', '', 163, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/08/red-tshirt.png', 0, 'attachment', 'image/png', 0),
(166, 1, '2016-08-01 14:49:09', '2016-08-01 14:49:09', 'Expertise in Agile Development allow us to build the best MVP for eager startups. We evaluate what client want, we have feature breakdown, we define project scope and then release client\'s MVP', '4 STEPS DEVELOPMENT  METHOD', '', 'publish', 'closed', 'closed', '', '4-steps-development-method', '', '', '2016-08-01 14:49:09', '2016-08-01 14:49:09', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=mvp&#038;p=166', 3, 'mvp', '', 0),
(167, 1, '2016-08-01 14:48:45', '2016-08-01 14:48:45', '', 'red-steps', '', 'inherit', 'open', 'closed', '', 'red-steps', '', '', '2016-08-01 14:48:45', '2016-08-01 14:48:45', '', 166, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/08/red-steps.png', 0, 'attachment', 'image/png', 0),
(168, 1, '2016-08-01 14:49:05', '2016-08-01 14:49:05', '', 'line-steps', '', 'inherit', 'open', 'closed', '', 'line-steps', '', '', '2016-08-01 14:49:05', '2016-08-01 14:49:05', '', 166, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/08/line-steps.png', 0, 'attachment', 'image/png', 0),
(169, 1, '2016-08-01 14:50:46', '2016-08-01 14:50:46', 'To build a relationship with client, we offer a trial for all clients who want to start a project with us. We\'re ready to build your trust as well as your success. Your success is our core standard to grow', '3 STEPS TO WRITE RELIABLE CODES (TDD)', '', 'publish', 'closed', 'closed', '', '3-steps-to-write-reliable-codes-tdd', '', '', '2016-08-01 14:50:46', '2016-08-01 14:50:46', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=mvp&#038;p=169', 4, 'mvp', '', 0),
(170, 1, '2016-08-01 14:50:04', '2016-08-01 14:50:04', '', 'line-browser', '', 'inherit', 'open', 'closed', '', 'line-browser', '', '', '2016-08-01 14:50:04', '2016-08-01 14:50:04', '', 169, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/08/line-browser.png', 0, 'attachment', 'image/png', 0),
(171, 1, '2016-08-01 14:50:15', '2016-08-01 14:50:15', '', 'red-browser', '', 'inherit', 'open', 'closed', '', 'red-browser-2', '', '', '2016-08-01 14:50:15', '2016-08-01 14:50:15', '', 169, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/08/red-browser-1.png', 0, 'attachment', 'image/png', 0),
(172, 1, '2016-08-01 14:52:06', '2016-08-01 14:52:06', 'Our 2 developers cross check code of each other to ensure high coding standard', '2 PEOPLES CROSS CHECK CODE', '', 'publish', 'closed', 'closed', '', '2-peoples-cross-check-code', '', '', '2016-08-01 14:52:06', '2016-08-01 14:52:06', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=mvp&#038;p=172', 5, 'mvp', '', 0),
(173, 1, '2016-08-01 14:51:24', '2016-08-01 14:51:24', '', 'red-magnifying', '', 'inherit', 'open', 'closed', '', 'red-magnifying', '', '', '2016-08-01 14:51:24', '2016-08-01 14:51:24', '', 172, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/08/red-magnifying.png', 0, 'attachment', 'image/png', 0),
(174, 1, '2016-08-01 14:51:43', '2016-08-01 14:51:43', '', 'line-magnifying', '', 'inherit', 'open', 'closed', '', 'line-magnifying', '', '', '2016-08-01 14:51:43', '2016-08-01 14:51:43', '', 172, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/08/line-magnifying.png', 0, 'attachment', 'image/png', 0),
(175, 1, '2016-08-01 14:53:25', '2016-08-01 14:53:25', 'Build simple, efficient and scalable applications such as QFit, vSmartSell, Reeting are some of our success stories. Measure exactly the success of your MVP by using lean analytic approaches. Learn fast and thorough from success and failures to improve.', 'BEST MVP', '', 'publish', 'closed', 'closed', '', 'best-mvp', '', '', '2016-08-01 14:53:25', '2016-08-01 14:53:25', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=mvp&#038;p=175', 6, 'mvp', '', 0),
(176, 1, '2016-08-01 14:52:58', '2016-08-01 14:52:58', '', 'line-star', '', 'inherit', 'open', 'closed', '', 'line-star', '', '', '2016-08-01 14:52:58', '2016-08-01 14:52:58', '', 175, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/08/line-star.png', 0, 'attachment', 'image/png', 0),
(177, 1, '2016-08-01 14:53:10', '2016-08-01 14:53:10', '', 'red-star', '', 'inherit', 'open', 'closed', '', 'red-star', '', '', '2016-08-01 14:53:10', '2016-08-01 14:53:10', '', 175, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/08/red-star.png', 0, 'attachment', 'image/png', 0),
(178, 1, '2016-08-02 17:46:42', '2016-08-02 17:46:42', '<div class="team-content main-title">\r\n\r\nFUTURIFY MEANS THE “FUTURE” THAT WE “REFINE” TO ACHIEVE GREATNESS\r\nAND SUCCESS.\r\n\r\n</div>', 'Quote3', '', 'publish', 'closed', 'closed', '', 'quote3', '', '', '2016-08-02 17:46:42', '2016-08-02 17:46:42', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=member&#038;p=178', 4, 'member', '', 0),
(179, 1, '2016-08-02 08:32:57', '2016-08-02 08:32:57', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium.\n\n&nbsp;\n\n<span class="h3">HEADNING TITLE</span>\n\n&nbsp;\n\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium sit amet quis magna. Aenean velit odio, elementum in tempus ut, vehicula eu diam. Pellentesque rhoncus aliquam mattis. Ut vulputate eros sed felis sodales nec vulputate justo hendrerit. Vivamus varius pretium ligula, a aliquam odio euismod sit amet. Quisque laoreet sem sit amet orci ullamcorper at ultricies metus viverra. Pellentesque arcu mauris, malesuada quis ornare accumsan, blandit sed diam.\n\n&nbsp;\n\n<img class="alignnone wp-image-182 size-full" src="http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/group-1.png" alt="group" width="1002" height="564" />\n\n&nbsp;\n\n&nbsp;', 'TECH CORNER: IBM WATSON DIALOG AND ASP.NET 101', '', 'inherit', 'closed', 'closed', '', '61-autosave-v1', '', '', '2016-08-02 08:32:57', '2016-08-02 08:32:57', '', 61, 'http://futurify.nguyenbui.name.vn/index.php/2016/08/02/61-autosave-v1/', 0, 'revision', '', 0),
(180, 1, '2016-08-02 08:27:55', '2016-08-02 08:27:55', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium.\r\n\r\n<span class="h2">HEADNING TITLE</span>\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium sit amet quis magna. Aenean velit odio, elementum in tempus ut, vehicula eu diam. Pellentesque rhoncus aliquam mattis. Ut vulputate eros sed felis sodales nec vulputate justo hendrerit. Vivamus varius pretium ligula, a aliquam odio euismod sit amet. Quisque laoreet sem sit amet orci ullamcorper at ultricies metus viverra. Pellentesque arcu mauris, malesuada quis ornare accumsan, blandit sed diam.', 'TECH CORNER: IBM WATSON DIALOG AND ASP.NET 101', '', 'inherit', 'closed', 'closed', '', '61-revision-v1', '', '', '2016-08-02 08:27:55', '2016-08-02 08:27:55', '', 61, 'http://futurify.nguyenbui.name.vn/index.php/2016/08/02/61-revision-v1/', 0, 'revision', '', 0),
(181, 1, '2016-08-02 08:29:05', '2016-08-02 08:29:05', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium.\r\n\r\n<span class="h3">HEADNING TITLE</span>\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium sit amet quis magna. Aenean velit odio, elementum in tempus ut, vehicula eu diam. Pellentesque rhoncus aliquam mattis. Ut vulputate eros sed felis sodales nec vulputate justo hendrerit. Vivamus varius pretium ligula, a aliquam odio euismod sit amet. Quisque laoreet sem sit amet orci ullamcorper at ultricies metus viverra. Pellentesque arcu mauris, malesuada quis ornare accumsan, blandit sed diam.', 'TECH CORNER: IBM WATSON DIALOG AND ASP.NET 101', '', 'inherit', 'closed', 'closed', '', '61-revision-v1', '', '', '2016-08-02 08:29:05', '2016-08-02 08:29:05', '', 61, 'http://futurify.nguyenbui.name.vn/index.php/2016/08/02/61-revision-v1/', 0, 'revision', '', 0),
(182, 1, '2016-08-02 08:32:11', '2016-08-02 08:32:11', '', 'group', '', 'inherit', 'open', 'closed', '', 'group', '', '', '2016-08-02 08:32:11', '2016-08-02 08:32:11', '', 61, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/group-1.png', 0, 'attachment', 'image/png', 0),
(183, 1, '2016-08-02 08:33:21', '2016-08-02 08:33:21', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium.\r\n\r\n&nbsp;\r\n\r\n<span class="h3">HEADNING TITLE</span>\r\n\r\n&nbsp;\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium sit amet quis magna. Aenean velit odio, elementum in tempus ut, vehicula eu diam. Pellentesque rhoncus aliquam mattis. Ut vulputate eros sed felis sodales nec vulputate justo hendrerit. Vivamus varius pretium ligula, a aliquam odio euismod sit amet. Quisque laoreet sem sit amet orci ullamcorper at ultricies metus viverra. Pellentesque arcu mauris, malesuada quis ornare accumsan, blandit sed diam.\r\n\r\n&nbsp;\r\n\r\n<img class="alignnone wp-image-182 size-full" src="http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/group-1.png" alt="group" width="1002" height="564" />\r\n\r\n&nbsp;\r\n\r\n<span class="h3">HEADNING TITLE</span>\r\n\r\n&nbsp;\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium sit amet quis magna. Aenean velit odio, elementum in tempus ut, vehicula eu diam. Pellentesque rhoncus aliquam mattis. Ut vulputate eros sed felis sodales nec vulputate justo hendrerit. Vivamus varius pretium ligula, a aliquam odio euismod sit amet. Quisque laoreet sem sit amet orci ullamcorper at ultricies metus viverra. Pellentesque arcu mauris, malesuada quis ornare accumsan, blandit sed diam.\r\n\r\n&nbsp;', 'TECH CORNER: IBM WATSON DIALOG AND ASP.NET 101', '', 'inherit', 'closed', 'closed', '', '61-revision-v1', '', '', '2016-08-02 08:33:21', '2016-08-02 08:33:21', '', 61, 'http://futurify.nguyenbui.name.vn/index.php/2016/08/02/61-revision-v1/', 0, 'revision', '', 0),
(184, 1, '2016-08-02 09:05:21', '2016-08-02 09:05:21', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium.\r\n\r\n<span class="h3">HEADNING TITLE</span>\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium sit amet quis magna. Aenean velit odio, elementum in tempus ut, vehicula eu diam. Pellentesque rhoncus aliquam mattis. Ut vulputate eros sed felis sodales nec vulputate justo hendrerit. Vivamus varius pretium ligula, a aliquam odio euismod sit amet. Quisque laoreet sem sit amet orci ullamcorper at ultricies metus viverra. Pellentesque arcu mauris, malesuada quis ornare accumsan, blandit sed diam.\r\n\r\n<img class="alignnone wp-image-182 size-full" src="http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/group-1.png" alt="group" width="1002" height="564" />\r\n\r\n<span class="h3">HEADNING TITLE</span>\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium sit amet quis magna. Aenean velit odio, elementum in tempus ut, vehicula eu diam. Pellentesque rhoncus aliquam mattis. Ut vulputate eros sed felis sodales nec vulputate justo hendrerit. Vivamus varius pretium ligula, a aliquam odio euismod sit amet. Quisque laoreet sem sit amet orci ullamcorper at ultricies metus viverra. Pellentesque arcu mauris, malesuada quis ornare accumsan, blandit sed diam.', 'TECH CORNER: IBM WATSON DIALOG AND ASP.NET 101', '', 'inherit', 'closed', 'closed', '', '53-revision-v1', '', '', '2016-08-02 09:05:21', '2016-08-02 09:05:21', '', 53, 'http://futurify.nguyenbui.name.vn/index.php/2016/08/02/53-revision-v1/', 0, 'revision', '', 0),
(185, 1, '2016-08-02 09:12:31', '2016-08-02 09:12:31', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium.\r\n\r\n&nbsp;\r\n\r\n<span class="h3">HEADNING TITLE</span>\r\n\r\n&nbsp;\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium sit amet quis magna. Aenean velit odio, elementum in tempus ut, vehicula eu diam. Pellentesque rhoncus aliquam mattis. Ut vulputate eros sed felis sodales nec vulputate justo hendrerit. Vivamus varius pretium ligula, a aliquam odio euismod sit amet. Quisque laoreet sem sit amet orci ullamcorper at ultricies metus viverra. Pellentesque arcu mauris, malesuada quis ornare accumsan, blandit sed diam.\r\n\r\n<img class="alignnone wp-image-182 size-full" src="http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/group-1.png" alt="group" width="1002" height="564" />\r\n\r\n&nbsp;\r\n\r\n<span class="h3">HEADNING TITLE</span>\r\n\r\n&nbsp;\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium sit amet quis magna. Aenean velit odio, elementum in tempus ut, vehicula eu diam. Pellentesque rhoncus aliquam mattis. Ut vulputate eros sed felis sodales nec vulputate justo hendrerit. Vivamus varius pretium ligula, a aliquam odio euismod sit amet. Quisque laoreet sem sit amet orci ullamcorper at ultricies metus viverra. Pellentesque arcu mauris, malesuada quis ornare accumsan, blandit sed diam.', 'TECH CORNER: IBM WATSON DIALOG AND ASP.NET 101', '', 'inherit', 'closed', 'closed', '', '50-revision-v1', '', '', '2016-08-02 09:12:31', '2016-08-02 09:12:31', '', 50, 'http://futurify.nguyenbui.name.vn/index.php/2016/08/02/50-revision-v1/', 0, 'revision', '', 0),
(186, 1, '2016-08-02 09:13:53', '2016-08-02 09:13:53', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium.\r\n\r\n&nbsp;\r\n\r\n<span class="h3">HEADNING TITLE</span>\r\n\r\n&nbsp;\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium sit amet quis magna. Aenean velit odio, elementum in tempus ut, vehicula eu diam. Pellentesque rhoncus aliquam mattis. Ut vulputate eros sed felis sodales nec vulputate justo hendrerit. Vivamus varius pretium ligula, a aliquam odio euismod sit amet. Quisque laoreet sem sit amet orci ullamcorper at ultricies metus viverra. Pellentesque arcu mauris, malesuada quis ornare accumsan, blandit sed diam.\r\n\r\n<img class="alignnone wp-image-182 size-full" src="http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/group-1.png" alt="group" width="1002" height="564" />\r\n\r\n&nbsp;\r\n\r\n<span class="h3">HEADNING TITLE</span>\r\n\r\n&nbsp;\r\n\r\n&nbsp;\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium sit amet quis magna. Aenean velit odio, elementum in tempus ut, vehicula eu diam. Pellentesque rhoncus aliquam mattis. Ut vulputate eros sed felis sodales nec vulputate justo hendrerit. Vivamus varius pretium ligula, a aliquam odio euismod sit amet. Quisque laoreet sem sit amet orci ullamcorper at ultricies metus viverra. Pellentesque arcu mauris, malesuada quis ornare accumsan, blandit sed diam.', 'TOP 10 BREAKING NEWS OF THE GIANTS', '', 'inherit', 'closed', 'closed', '', '42-revision-v1', '', '', '2016-08-02 09:13:53', '2016-08-02 09:13:53', '', 42, 'http://futurify.nguyenbui.name.vn/index.php/2016/08/02/42-revision-v1/', 0, 'revision', '', 0),
(187, 1, '2016-08-02 09:14:12', '2016-08-02 09:14:12', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium.\n\n&nbsp;\n\n<span class="h3">HEADNING TITLE</span>\n\n&nbsp;\n\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium sit amet quis magna. Aenean velit odio, elementum in tempus ut, vehicula eu diam. Pellentesque rhoncus aliquam mattis. Ut vulputate eros sed felis sodales nec vulputate justo hendrerit. Vivamus varius pretium ligula, a aliquam odio euismod sit amet. Quisque laoreet sem sit amet orci ullamcorper at ultricies metus viverra. Pellentesque arcu mauris, malesuada quis ornare accumsan, blandit sed diam.\n\n<img class="alignnone wp-image-182 size-full" src="http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/group-1.png" alt="group" width="1002" height="564" />\n\n&nbsp;\n\n<span class="h3">HEADNING TITLE</span>\n\n&nbsp;\n\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium sit amet quis magna. Aenean velit odio, elementum in tempus ut, vehicula eu diam. Pellentesque rhoncus aliquam mattis. Ut vulputate eros sed felis sodales nec vulputate justo hendrerit. Vivamus varius pretium ligula, a aliquam odio euismod sit amet. Quisque laoreet sem sit amet orci ullamcorper at ultricies metus viverra. Pellentesque arcu mauris, malesuada quis ornare accumsan, blandit sed diam.', 'TECH CORNER: IBM WATSON DIALOG AND ASP.NET 101', '', 'inherit', 'closed', 'closed', '', '50-autosave-v1', '', '', '2016-08-02 09:14:12', '2016-08-02 09:14:12', '', 50, 'http://futurify.nguyenbui.name.vn/index.php/2016/08/02/50-autosave-v1/', 0, 'revision', '', 0),
(188, 1, '2016-08-02 09:14:27', '2016-08-02 09:14:27', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium.\r\n\r\n<span class="h3">HEADNING TITLE</span>\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium sit amet quis magna. Aenean velit odio, elementum in tempus ut, vehicula eu diam. Pellentesque rhoncus aliquam mattis. Ut vulputate eros sed felis sodales nec vulputate justo hendrerit. Vivamus varius pretium ligula, a aliquam odio euismod sit amet. Quisque laoreet sem sit amet orci ullamcorper at ultricies metus viverra. Pellentesque arcu mauris, malesuada quis ornare accumsan, blandit sed diam.\r\n\r\n<img class="alignnone wp-image-182 size-full" src="http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/group-1.png" alt="group" width="1002" height="564" />\r\n\r\n<span class="h3">HEADNING TITLE</span>\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium sit amet quis magna. Aenean velit odio, elementum in tempus ut, vehicula eu diam. Pellentesque rhoncus aliquam mattis. Ut vulputate eros sed felis sodales nec vulputate justo hendrerit. Vivamus varius pretium ligula, a aliquam odio euismod sit amet. Quisque laoreet sem sit amet orci ullamcorper at ultricies metus viverra. Pellentesque arcu mauris, malesuada quis ornare accumsan, blandit sed diam.', 'TECH CORNER: IBM WATSON DIALOG AND ASP.NET 101', '', 'inherit', 'closed', 'closed', '', '47-revision-v1', '', '', '2016-08-02 09:14:27', '2016-08-02 09:14:27', '', 47, 'http://futurify.nguyenbui.name.vn/index.php/2016/08/02/47-revision-v1/', 0, 'revision', '', 0),
(189, 1, '2016-08-02 09:14:50', '2016-08-02 09:14:50', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium.\r\n\r\n<span class="h3">HEADNING TITLE</span>\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium sit amet quis magna. Aenean velit odio, elementum in tempus ut, vehicula eu diam. Pellentesque rhoncus aliquam mattis. Ut vulputate eros sed felis sodales nec vulputate justo hendrerit. Vivamus varius pretium ligula, a aliquam odio euismod sit amet. Quisque laoreet sem sit amet orci ullamcorper at ultricies metus viverra. Pellentesque arcu mauris, malesuada quis ornare accumsan, blandit sed diam.\r\n\r\n<img class="alignnone wp-image-182 size-full" src="http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/group-1.png" alt="group" width="1002" height="564" />\r\n\r\n<span class="h3">HEADNING TITLE</span>\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium sit amet quis magna. Aenean velit odio, elementum in tempus ut, vehicula eu diam. Pellentesque rhoncus aliquam mattis. Ut vulputate eros sed felis sodales nec vulputate justo hendrerit. Vivamus varius pretium ligula, a aliquam odio euismod sit amet. Quisque laoreet sem sit amet orci ullamcorper at ultricies metus viverra. Pellentesque arcu mauris, malesuada quis ornare accumsan, blandit sed diam.', 'TOP 10 BREAKING NEWS OF THE GIANTS', '', 'inherit', 'closed', 'closed', '', '39-revision-v1', '', '', '2016-08-02 09:14:50', '2016-08-02 09:14:50', '', 39, 'http://futurify.nguyenbui.name.vn/index.php/2016/08/02/39-revision-v1/', 0, 'revision', '', 0),
(190, 1, '2016-08-02 09:14:55', '2016-08-02 09:14:55', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium.\r\n\r\n<span class="h3">HEADNING TITLE</span>\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium sit amet quis magna. Aenean velit odio, elementum in tempus ut, vehicula eu diam. Pellentesque rhoncus aliquam mattis. Ut vulputate eros sed felis sodales nec vulputate justo hendrerit. Vivamus varius pretium ligula, a aliquam odio euismod sit amet. Quisque laoreet sem sit amet orci ullamcorper at ultricies metus viverra. Pellentesque arcu mauris, malesuada quis ornare accumsan, blandit sed diam.\r\n\r\n<img class="alignnone wp-image-182 size-full" src="http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/group-1.png" alt="group" width="1002" height="564" />\r\n\r\n<span class="h3">HEADNING TITLE</span>\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium sit amet quis magna. Aenean velit odio, elementum in tempus ut, vehicula eu diam. Pellentesque rhoncus aliquam mattis. Ut vulputate eros sed felis sodales nec vulputate justo hendrerit. Vivamus varius pretium ligula, a aliquam odio euismod sit amet. Quisque laoreet sem sit amet orci ullamcorper at ultricies metus viverra. Pellentesque arcu mauris, malesuada quis ornare accumsan, blandit sed diam.', 'TOP 10 BREAKING NEWS OF THE GIANTS', '', 'inherit', 'closed', 'closed', '', '36-revision-v1', '', '', '2016-08-02 09:14:55', '2016-08-02 09:14:55', '', 36, 'http://futurify.nguyenbui.name.vn/index.php/2016/08/02/36-revision-v1/', 0, 'revision', '', 0),
(191, 1, '2016-08-02 15:11:14', '2016-08-02 15:11:14', '', 'Member Fields', '', 'publish', 'closed', 'closed', '', 'acf_member-fields', '', '', '2016-08-02 17:44:27', '2016-08-02 17:44:27', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=acf&#038;p=191', 0, 'acf', '', 0) ;
INSERT INTO `lrpmqdj9_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(192, 1, '2016-08-02 15:22:16', '2016-08-02 15:22:16', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium.\r\n\r\n&nbsp;\r\n\r\n<span class="h3">HEADNING TITLE</span>\r\n\r\n&nbsp;\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium sit amet quis magna. Aenean velit odio, elementum in tempus ut, vehicula eu diam. Pellentesque rhoncus aliquam mattis. Ut vulputate eros sed felis sodales nec vulputate justo hendrerit. Vivamus varius pretium ligula, a aliquam odio euismod sit amet. Quisque laoreet sem sit amet orci ullamcorper at ultricies metus viverra. Pellentesque arcu mauris, malesuada quis ornare accumsan, blandit sed diam.\r\n\r\n&nbsp;\r\n\r\n<img class="alignnone wp-image-182 size-full" src="http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07group-1-768x432.png" alt="group" width="1002" height="564" />\r\n\r\n&nbsp;\r\n\r\n<span class="h3">HEADNING TITLE</span>\r\n\r\n&nbsp;\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium sit amet quis magna. Aenean velit odio, elementum in tempus ut, vehicula eu diam. Pellentesque rhoncus aliquam mattis. Ut vulputate eros sed felis sodales nec vulputate justo hendrerit. Vivamus varius pretium ligula, a aliquam odio euismod sit amet. Quisque laoreet sem sit amet orci ullamcorper at ultricies metus viverra. Pellentesque arcu mauris, malesuada quis ornare accumsan, blandit sed diam.\r\n\r\n&nbsp;', 'TECH CORNER: IBM WATSON DIALOG AND ASP.NET 101', '', 'inherit', 'closed', 'closed', '', '61-revision-v1', '', '', '2016-08-02 15:22:16', '2016-08-02 15:22:16', '', 61, 'http://futurify.nguyenbui.name.vn/index.php/2016/08/02/61-revision-v1/', 0, 'revision', '', 0),
(193, 1, '2016-08-02 15:26:57', '2016-08-02 15:26:57', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium.\r\n\r\n&nbsp;\r\n\r\n<span class="h3">HEADNING TITLE</span>\r\n\r\n&nbsp;\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium sit amet quis magna. Aenean velit odio, elementum in tempus ut, vehicula eu diam. Pellentesque rhoncus aliquam mattis. Ut vulputate eros sed felis sodales nec vulputate justo hendrerit. Vivamus varius pretium ligula, a aliquam odio euismod sit amet. Quisque laoreet sem sit amet orci ullamcorper at ultricies metus viverra. Pellentesque arcu mauris, malesuada quis ornare accumsan, blandit sed diam.\r\n\r\n&nbsp;\r\n\r\n<img class="alignnone wp-image-182 size-full" src="http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/group-1.png" alt="group" width="1002" height="564" />\r\n\r\n&nbsp;\r\n\r\n<span class="h3">HEADNING TITLE</span>\r\n\r\n&nbsp;\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id. Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit, et lacinia ipsum quam nec dui. Quisque nec mauris sit amet elit iaculis pretium sit amet quis magna. Aenean velit odio, elementum in tempus ut, vehicula eu diam. Pellentesque rhoncus aliquam mattis. Ut vulputate eros sed felis sodales nec vulputate justo hendrerit. Vivamus varius pretium ligula, a aliquam odio euismod sit amet. Quisque laoreet sem sit amet orci ullamcorper at ultricies metus viverra. Pellentesque arcu mauris, malesuada quis ornare accumsan, blandit sed diam.\r\n\r\n&nbsp;', 'TECH CORNER: IBM WATSON DIALOG AND ASP.NET 101', '', 'inherit', 'closed', 'closed', '', '61-revision-v1', '', '', '2016-08-02 15:26:57', '2016-08-02 15:26:57', '', 61, 'http://futurify.nguyenbui.name.vn/index.php/2016/08/02/61-revision-v1/', 0, 'revision', '', 0),
(194, 1, '2016-08-02 17:41:51', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2016-08-02 17:41:51', '0000-00-00 00:00:00', '', 0, 'http://futurify.nguyenbui.name.vn/?p=194', 0, 'post', '', 0),
(195, 1, '2016-08-02 17:44:44', '2016-08-02 17:44:44', '<div class="bl-our-project-button-more">\r\n<div id="btn-project-more">\r\n<h5>JOIN US</h5>\r\nYour avatar will be here!\r\n\r\n</div>\r\n</div>', 'Join us', '', 'publish', 'closed', 'closed', '', 'join-us', '', '', '2016-08-02 17:44:44', '2016-08-02 17:44:44', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=member&#038;p=195', 13, 'member', '', 0),
(196, 1, '2016-08-03 15:56:00', '2016-08-03 15:56:00', '<div class="contact-paragraph">\n<h2 class="red-txt">HELLO</h2>\nWe always have good taste Vietnamese coffee.\nCome in our nest, have a cup of coffee and a talk with us.\nWork together. Do amazing projects.\nBring success to your business, we know how.\n	<?', 'CONTACT US', '', 'inherit', 'closed', 'closed', '', '12-autosave-v1', '', '', '2016-08-03 15:56:00', '2016-08-03 15:56:00', '', 12, 'http://futurify.nguyenbui.name.vn/index.php/2016/08/03/12-autosave-v1/', 0, 'revision', '', 0),
(197, 1, '2016-08-03 15:56:08', '2016-08-03 15:56:08', '<div class="contact-paragraph">\r\n<h2 class="red-txt">HELLO</h2>\r\nWe always have good taste Vietnamese coffee.\r\nCome in our nest, have a cup of coffee and a talk with us.\r\nWork together. Do amazing projects.\r\nBring success to your business, we know how.\r\n</div>', 'CONTACT US', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2016-08-03 15:56:08', '2016-08-03 15:56:08', '', 12, 'http://futurify.nguyenbui.name.vn/index.php/2016/08/03/12-revision-v1/', 0, 'revision', '', 0),
(198, 1, '2016-08-04 14:19:45', '2016-08-04 14:19:45', '', 'Home Page', '', 'publish', 'closed', 'closed', '', 'acf_home-page', '', '', '2016-08-06 13:02:08', '2016-08-06 13:02:08', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=acf&#038;p=198', 0, 'acf', '', 0),
(199, 1, '2016-08-04 14:20:42', '2016-08-04 14:20:42', '', 'home-introdution-img', '', 'inherit', 'open', 'closed', '', 'home-introdution-img', '', '', '2016-08-04 14:20:42', '2016-08-04 14:20:42', '', 64, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/home-introdution-img.png', 0, 'attachment', 'image/png', 0),
(200, 1, '2016-08-04 14:21:39', '2016-08-04 14:21:39', '<form class="panel-content">\r\n<h3>Let\'s chat and create great works together!!!</h3>\r\nHello, my name is\r\n\r\n<input class="input-style" type="text" />\r\n\r\nReach me at this email\r\n\r\n<input class="input-style" type="email" />\r\n\r\nAnd have conversation of my concern about\r\n\r\n<input class="input-style" type="text" />\r\n<div class="form-btn"></div>\r\n</form>', 'HOME', '', 'inherit', 'closed', 'closed', '', '64-revision-v1', '', '', '2016-08-04 14:21:39', '2016-08-04 14:21:39', '', 64, 'http://futurify.nguyenbui.name.vn/index.php/64-revision-v1/', 0, 'revision', '', 0),
(201, 1, '2016-08-04 15:11:04', '2016-08-04 15:11:04', '', 'About Page', '', 'publish', 'closed', 'closed', '', 'acf_about-page', '', '', '2016-08-04 16:41:51', '2016-08-04 16:41:51', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=acf&#038;p=201', 0, 'acf', '', 0),
(202, 1, '2016-08-04 15:28:09', '2016-08-04 15:28:09', '', 'About2', '', 'trash', 'closed', 'closed', '', 'acf_about2__trashed', '', '', '2016-08-04 15:28:42', '2016-08-04 15:28:42', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=acf&#038;p=202', 0, 'acf', '', 0),
(203, 1, '2016-08-04 15:45:54', '2016-08-04 15:45:54', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\r\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin\' caught in the rain.)</blockquote>\r\n...or something like this:\r\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\r\nAs a new WordPress user, you should go to <a href="http://futurify.nguyenbui.name.vn/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'ABOUT', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2016-08-04 15:45:54', '2016-08-04 15:45:54', '', 2, 'http://futurify.nguyenbui.name.vn/index.php/2-revision-v1/', 0, 'revision', '', 0),
(204, 1, '2016-08-04 15:56:39', '2016-08-04 15:56:39', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\r\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin\' caught in the rain.)</blockquote>\r\n...or something like this:\r\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\r\nAs a new WordPress user, you should go to <a href="http://futurify.nguyenbui.name.vn/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'ABOUT', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2016-08-04 15:56:39', '2016-08-04 15:56:39', '', 2, 'http://futurify.nguyenbui.name.vn/index.php/2-revision-v1/', 0, 'revision', '', 0),
(205, 1, '2016-08-04 15:57:00', '2016-08-04 15:57:00', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\r\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin\' caught in the rain.)</blockquote>\r\n...or something like this:\r\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\r\nAs a new WordPress user, you should go to <a href="http://futurify.nguyenbui.name.vn/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'ABOUT', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2016-08-04 15:57:00', '2016-08-04 15:57:00', '', 2, 'http://futurify.nguyenbui.name.vn/index.php/2-revision-v1/', 0, 'revision', '', 0),
(206, 1, '2016-08-04 15:57:13', '2016-08-04 15:57:13', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\r\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin\' caught in the rain.)</blockquote>\r\n...or something like this:\r\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\r\nAs a new WordPress user, you should go to <a href="http://futurify.nguyenbui.name.vn/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'ABOUT', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2016-08-04 15:57:13', '2016-08-04 15:57:13', '', 2, 'http://futurify.nguyenbui.name.vn/index.php/2-revision-v1/', 0, 'revision', '', 0),
(207, 1, '2016-08-04 15:59:40', '2016-08-04 15:59:40', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\r\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin\' caught in the rain.)</blockquote>\r\n...or something like this:\r\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\r\nAs a new WordPress user, you should go to <a href="http://futurify.nguyenbui.name.vn/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'ABOUT', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2016-08-04 15:59:40', '2016-08-04 15:59:40', '', 2, 'http://futurify.nguyenbui.name.vn/index.php/2-revision-v1/', 0, 'revision', '', 0),
(208, 1, '2016-08-04 16:00:37', '2016-08-04 16:00:37', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\r\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin\' caught in the rain.)</blockquote>\r\n...or something like this:\r\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\r\nAs a new WordPress user, you should go to <a href="http://futurify.nguyenbui.name.vn/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'ABOUT', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2016-08-04 16:00:37', '2016-08-04 16:00:37', '', 2, 'http://futurify.nguyenbui.name.vn/index.php/2-revision-v1/', 0, 'revision', '', 0),
(209, 1, '2016-08-04 16:11:55', '2016-08-04 16:11:55', '', 'main-people', '', 'inherit', 'open', 'closed', '', 'main-people', '', '', '2016-08-04 16:11:55', '2016-08-04 16:11:55', '', 2, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/main-people.png', 0, 'attachment', 'image/png', 0),
(210, 1, '2016-08-04 16:13:42', '2016-08-04 16:13:42', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\r\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin\' caught in the rain.)</blockquote>\r\n...or something like this:\r\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\r\nAs a new WordPress user, you should go to <a href="http://futurify.nguyenbui.name.vn/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'ABOUT', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2016-08-04 16:13:42', '2016-08-04 16:13:42', '', 2, 'http://futurify.nguyenbui.name.vn/index.php/2-revision-v1/', 0, 'revision', '', 0),
(211, 1, '2016-08-04 16:16:20', '2016-08-04 16:16:20', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\r\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin\' caught in the rain.)</blockquote>\r\n...or something like this:\r\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\r\nAs a new WordPress user, you should go to <a href="http://futurify.nguyenbui.name.vn/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'ABOUT', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2016-08-04 16:16:20', '2016-08-04 16:16:20', '', 2, 'http://futurify.nguyenbui.name.vn/index.php/2-revision-v1/', 0, 'revision', '', 0),
(212, 1, '2016-08-04 16:20:55', '2016-08-04 16:20:55', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\r\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin\' caught in the rain.)</blockquote>\r\n...or something like this:\r\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\r\nAs a new WordPress user, you should go to <a href="http://futurify.nguyenbui.name.vn/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'ABOUT', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2016-08-04 16:20:55', '2016-08-04 16:20:55', '', 2, 'http://futurify.nguyenbui.name.vn/index.php/2-revision-v1/', 0, 'revision', '', 0),
(213, 1, '2016-08-04 16:24:40', '2016-08-04 16:24:40', '', 'group-copy', '', 'inherit', 'open', 'closed', '', 'group-copy', '', '', '2016-08-04 16:24:40', '2016-08-04 16:24:40', '', 2, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/group-copy.png', 0, 'attachment', 'image/png', 0),
(214, 1, '2016-08-04 16:25:04', '2016-08-04 16:25:04', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\r\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin\' caught in the rain.)</blockquote>\r\n...or something like this:\r\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\r\nAs a new WordPress user, you should go to <a href="http://futurify.nguyenbui.name.vn/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'ABOUT', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2016-08-04 16:25:04', '2016-08-04 16:25:04', '', 2, 'http://futurify.nguyenbui.name.vn/index.php/2-revision-v1/', 0, 'revision', '', 0),
(215, 1, '2016-08-04 16:32:40', '2016-08-04 16:32:40', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\r\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin\' caught in the rain.)</blockquote>\r\n...or something like this:\r\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\r\nAs a new WordPress user, you should go to <a href="http://futurify.nguyenbui.name.vn/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'ABOUT', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2016-08-04 16:32:40', '2016-08-04 16:32:40', '', 2, 'http://futurify.nguyenbui.name.vn/index.php/2-revision-v1/', 0, 'revision', '', 0),
(216, 1, '2016-08-04 16:35:22', '2016-08-04 16:35:22', '', 'WE SHARE', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2016-08-04 16:35:22', '2016-08-04 16:35:22', '', 10, 'http://futurify.nguyenbui.name.vn/index.php/10-revision-v1/', 0, 'revision', '', 0),
(217, 1, '2016-08-04 16:37:40', '2016-08-04 16:37:40', '<div class="bl-blog-list-title">\r\n<h1 class="black-title">SHARING IS CARING</h1>\r\nA place we share to each other, care of things around us. It\'s our pleasure to share culture, thoughts, interests in technology with you - our clients as well as the new visitors\r\n\r\n</div>', 'WE SHARE', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2016-08-04 16:37:40', '2016-08-04 16:37:40', '', 10, 'http://futurify.nguyenbui.name.vn/index.php/10-revision-v1/', 0, 'revision', '', 0) ;
INSERT INTO `lrpmqdj9_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(218, 1, '2016-08-04 16:48:04', '2016-08-04 16:48:04', '', 'We Share Page', '', 'publish', 'closed', 'closed', '', 'acf_we-share-page', '', '', '2016-08-06 07:18:30', '2016-08-06 07:18:30', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=acf&#038;p=218', 0, 'acf', '', 0),
(219, 1, '2016-08-04 16:49:10', '2016-08-04 16:49:10', '<div class="bl-blog-list-title">\r\n<h1 class="black-title">SHARING IS CARING</h1>\r\nA place we share to each other, care of things around us. It\'s our pleasure to share culture, thoughts, interests in technology with you - our clients as well as the new visitors\r\n\r\n</div>', 'WE SHARE', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2016-08-04 16:49:10', '2016-08-04 16:49:10', '', 10, 'http://futurify.nguyenbui.name.vn/index.php/10-revision-v1/', 0, 'revision', '', 0),
(221, 1, '2016-08-04 16:58:33', '2016-08-04 16:58:33', '', 'CAREER', '', 'publish', 'closed', 'closed', '', 'career', '', '', '2016-08-06 07:19:40', '2016-08-06 07:19:40', '', 0, 'http://futurify.nguyenbui.name.vn/?page_id=221', 0, 'page', '', 0),
(222, 1, '2016-08-04 16:58:33', '2016-08-04 16:58:33', '', 'Career', '', 'inherit', 'closed', 'closed', '', '221-revision-v1', '', '', '2016-08-04 16:58:33', '2016-08-04 16:58:33', '', 221, 'http://futurify.nguyenbui.name.vn/index.php/221-revision-v1/', 0, 'revision', '', 0),
(223, 1, '2016-08-04 17:00:19', '2016-08-04 17:00:19', '', 'Case Study Page', '', 'publish', 'closed', 'closed', '', 'acf_case-study-page', '', '', '2016-08-06 02:32:58', '2016-08-06 02:32:58', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=acf&#038;p=223', 0, 'acf', '', 0),
(224, 1, '2016-08-04 17:15:40', '2016-08-04 17:15:40', '<form class="panel-content">\r\n<h3>Let\'s chat and create great works together!!!</h3>\r\nHello, my name is\r\n\r\n<input class="input-style" type="text" />\r\n\r\nReach me at this email\r\n\r\n<input class="input-style" type="email" />\r\n\r\nAnd have conversation of my concern about\r\n\r\n<input class="input-style" type="text" />\r\n<div class="form-btn"><button class="btn-play1"> </button></div>\r\n</form>', 'HOME', '', 'inherit', 'closed', 'closed', '', '64-revision-v1', '', '', '2016-08-04 17:15:40', '2016-08-04 17:15:40', '', 64, 'http://futurify.nguyenbui.name.vn/index.php/64-revision-v1/', 0, 'revision', '', 0),
(225, 1, '2016-08-04 17:18:16', '2016-08-04 17:18:16', '<form class="panel-content">\r\n<h3>Let\'s chat and create great works together!!!</h3>\r\nHello, my name is\r\n\r\n<input class="input-style" type="text" />\r\n\r\nReach me at this email\r\n\r\n<input class="input-style" type="email" />\r\n\r\nAnd have conversation of my concern about\r\n\r\n<input class="input-style" type="text" />\r\n<div class="form-btn"></div>\r\n</form>', 'HOME', '', 'inherit', 'closed', 'closed', '', '64-revision-v1', '', '', '2016-08-04 17:18:16', '2016-08-04 17:18:16', '', 64, 'http://futurify.nguyenbui.name.vn/index.php/64-revision-v1/', 0, 'revision', '', 0),
(226, 1, '2016-08-04 17:20:17', '2016-08-04 17:20:17', '<div class="panel-content">\r\n<h3>Let\'s chat and create great works together!!!</h3>\r\nHello, my name is\r\n\r\n<input class="input-style" type="text" />\r\n\r\nReach me at this email\r\n\r\n<input class="input-style" type="email" />\r\n\r\nAnd have conversation of my concern about\r\n\r\n<input class="input-style" type="text" />\r\n\r\n</div>', 'HOME', '', 'inherit', 'closed', 'closed', '', '64-revision-v1', '', '', '2016-08-04 17:20:17', '2016-08-04 17:20:17', '', 64, 'http://futurify.nguyenbui.name.vn/index.php/64-revision-v1/', 0, 'revision', '', 0),
(227, 1, '2016-08-05 15:28:28', '2016-08-05 15:28:28', '', 'CAREER', '', 'inherit', 'closed', 'closed', '', '221-revision-v1', '', '', '2016-08-05 15:28:28', '2016-08-05 15:28:28', '', 221, 'http://futurify.nguyenbui.name.vn/index.php/221-revision-v1/', 0, 'revision', '', 0),
(228, 1, '2016-08-05 15:50:59', '2016-08-05 15:50:59', '', 'phone', '', 'inherit', 'open', 'closed', '', 'phone', '', '', '2016-08-05 15:50:59', '2016-08-05 15:50:59', '', 86, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/phone.png', 0, 'attachment', 'image/png', 0),
(229, 1, '2016-08-05 15:51:58', '2016-08-05 15:51:58', '', 'case1', '', 'inherit', 'open', 'closed', '', 'case1', '', '', '2016-08-05 15:51:58', '2016-08-05 15:51:58', '', 86, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/case1.png', 0, 'attachment', 'image/png', 0),
(230, 1, '2016-08-05 15:51:59', '2016-08-05 15:51:59', '', 'case2', '', 'inherit', 'open', 'closed', '', 'case2', '', '', '2016-08-05 15:51:59', '2016-08-05 15:51:59', '', 86, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/case2.png', 0, 'attachment', 'image/png', 0),
(231, 1, '2016-08-05 15:51:59', '2016-08-05 15:51:59', '', 'case3', '', 'inherit', 'open', 'closed', '', 'case3', '', '', '2016-08-05 15:51:59', '2016-08-05 15:51:59', '', 86, 'http://futurify.nguyenbui.name.vn/wp-content/uploads/2016/07/case3.png', 0, 'attachment', 'image/png', 0),
(232, 1, '2016-08-06 02:59:31', '2016-08-06 02:59:31', '<span class="red-text">“The FUTURIFY team refined our brand, created a rockin’ style guide and brand book, and designed a web site that we’re extremely proud of.”</span>', 'Text with Red Background', '', 'publish', 'closed', 'closed', '', 'text-with-red-background', '', '', '2016-08-06 02:59:31', '2016-08-06 02:59:31', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=tinymcetemplates&#038;p=232', 0, 'tinymcetemplates', '', 0),
(233, 1, '2016-08-06 02:59:31', '2016-08-06 02:59:31', '<span class="red-text">“The FUTURIFY team refined our brand, created a rockin’ style guide and brand book, and designed a web site that we’re extremely proud of.”</span>', 'Text with Red Background', '', 'inherit', 'closed', 'closed', '', '232-revision-v1', '', '', '2016-08-06 02:59:31', '2016-08-06 02:59:31', '', 232, 'http://futurify.nguyenbui.name.vn/index.php/232-revision-v1/', 0, 'revision', '', 0),
(234, 1, '2016-08-06 03:01:10', '0000-00-00 00:00:00', '<h2><span class="red-text">“The FUTURIFY team refined our brand, created a rockin’ style guide and brand book, and designed a web site that we’re extremely proud of.”</span></h2>', 'Quote', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-08-06 03:01:10', '2016-08-06 03:01:10', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=tinymcetemplates&#038;p=234', 0, 'tinymcetemplates', '', 0),
(235, 1, '2016-08-06 07:19:40', '2016-08-06 07:19:40', '', 'CAREER', '', 'inherit', 'closed', 'closed', '', '221-revision-v1', '', '', '2016-08-06 07:19:40', '2016-08-06 07:19:40', '', 221, 'http://futurify.nguyenbui.name.vn/index.php/221-revision-v1/', 0, 'revision', '', 0),
(236, 1, '2016-08-06 13:02:33', '2016-08-06 13:02:33', '<div class="panel-content">\r\n<h3>Let\'s chat and create great works together!!!</h3>\r\nHello, my name is\r\n\r\n<input class="input-style" type="text" />\r\n\r\nReach me at this email\r\n\r\n<input class="input-style" type="email" />\r\n\r\nAnd have conversation of my concern about\r\n\r\n<input class="input-style" type="text" />\r\n\r\n</div>', 'HOME', '', 'inherit', 'closed', 'closed', '', '64-revision-v1', '', '', '2016-08-06 13:02:33', '2016-08-06 13:02:33', '', 64, 'http://futurify.nguyenbui.name.vn/index.php/64-revision-v1/', 0, 'revision', '', 0),
(237, 1, '2016-08-06 13:24:02', '0000-00-00 00:00:00', '', 'Red Background Text', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-08-06 13:24:02', '2016-08-06 13:24:02', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=vecb_editor_buttons&#038;p=237', 0, 'vecb_editor_buttons', '', 0),
(238, 1, '2016-08-06 13:28:37', '2016-08-06 13:28:37', '', 'Red Background Text', '', 'publish', 'closed', 'closed', '', 'red-background-text', '', '', '2016-08-06 13:28:37', '2016-08-06 13:28:37', '', 0, 'http://futurify.nguyenbui.name.vn/?post_type=vecb_editor_buttons&#038;p=238', 0, 'vecb_editor_buttons', '', 0) ;

#
# End of data contents of table `lrpmqdj9_posts`
# --------------------------------------------------------



#
# Delete any existing table `lrpmqdj9_term_relationships`
#

DROP TABLE IF EXISTS `lrpmqdj9_term_relationships`;


#
# Table structure of table `lrpmqdj9_term_relationships`
#

CREATE TABLE `lrpmqdj9_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `lrpmqdj9_term_relationships`
#
INSERT INTO `lrpmqdj9_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(16, 2, 0),
(17, 2, 0),
(18, 2, 0),
(19, 2, 0),
(20, 2, 0),
(27, 2, 0),
(28, 2, 0),
(36, 1, 0),
(36, 5, 0),
(39, 1, 0),
(39, 5, 0),
(42, 1, 0),
(42, 5, 0),
(47, 1, 0),
(47, 3, 0),
(50, 1, 0),
(50, 3, 0),
(50, 4, 0),
(53, 1, 0),
(53, 3, 0),
(53, 5, 0),
(61, 1, 0),
(61, 5, 0) ;

#
# End of data contents of table `lrpmqdj9_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `lrpmqdj9_term_taxonomy`
#

DROP TABLE IF EXISTS `lrpmqdj9_term_taxonomy`;


#
# Table structure of table `lrpmqdj9_term_taxonomy`
#

CREATE TABLE `lrpmqdj9_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `lrpmqdj9_term_taxonomy`
#
INSERT INTO `lrpmqdj9_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 7),
(2, 2, 'nav_menu', '', 0, 7),
(3, 3, 'post_tag', '', 0, 3),
(4, 4, 'post_tag', '', 0, 1),
(5, 5, 'post_tag', '', 0, 5) ;

#
# End of data contents of table `lrpmqdj9_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `lrpmqdj9_termmeta`
#

DROP TABLE IF EXISTS `lrpmqdj9_termmeta`;


#
# Table structure of table `lrpmqdj9_termmeta`
#

CREATE TABLE `lrpmqdj9_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `lrpmqdj9_termmeta`
#

#
# End of data contents of table `lrpmqdj9_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `lrpmqdj9_terms`
#

DROP TABLE IF EXISTS `lrpmqdj9_terms`;


#
# Table structure of table `lrpmqdj9_terms`
#

CREATE TABLE `lrpmqdj9_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `lrpmqdj9_terms`
#
INSERT INTO `lrpmqdj9_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Home Menu', 'home-menu', 0),
(3, 'TECH CORNER', 'tech-corner', 0),
(4, 'OUR CULTURE', 'our-culture', 0),
(5, 'TECH MASHUP', 'tech-mashup', 0) ;

#
# End of data contents of table `lrpmqdj9_terms`
# --------------------------------------------------------



#
# Delete any existing table `lrpmqdj9_usermeta`
#

DROP TABLE IF EXISTS `lrpmqdj9_usermeta`;


#
# Table structure of table `lrpmqdj9_usermeta`
#

CREATE TABLE `lrpmqdj9_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `lrpmqdj9_usermeta`
#
INSERT INTO `lrpmqdj9_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'true'),
(10, 1, 'lrpmqdj9_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(11, 1, 'lrpmqdj9_user_level', '10'),
(12, 1, 'dismissed_wp_pointers', 'vc_pointers_frontend_editor,vc_pointers_backend_editor,addtoany_settings_pointer'),
(13, 1, 'show_welcome_panel', '1'),
(14, 1, 'session_tokens', 'a:7:{s:64:"47898c10972d126c03d450d0383d6b4fd2d3cc44705b9ce739492f09d108ed74";a:4:{s:10:"expiration";i:1470748286;s:2:"ip";s:3:"::1";s:2:"ua";s:135:"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/56.3.120 Chrome/50.3.2661.120 Safari/537.36";s:5:"login";i:1469538686;}s:64:"77f37fc3337292dda7b66efe71aa2b68f792d6c111329b7cdc1d3cdafa58e283";a:4:{s:10:"expiration";i:1471367660;s:2:"ip";s:3:"::1";s:2:"ua";s:135:"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/56.3.120 Chrome/50.3.2661.120 Safari/537.36";s:5:"login";i:1470158060;}s:64:"ab03bd6df8e25e3a3905d7849bf606a4c8d1bf7ab18abee388f93f1296826f13";a:4:{s:10:"expiration";i:1471367724;s:2:"ip";s:3:"::1";s:2:"ua";s:135:"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/56.3.120 Chrome/50.3.2661.120 Safari/537.36";s:5:"login";i:1470158124;}s:64:"dc7e2aeff75396b8420710943425bc0b1264a302d3ec4ff683c124ba6a4daa34";a:4:{s:10:"expiration";i:1471367736;s:2:"ip";s:3:"::1";s:2:"ua";s:135:"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/56.3.120 Chrome/50.3.2661.120 Safari/537.36";s:5:"login";i:1470158136;}s:64:"d533b1e6ff2c7920a8bf4d731eea1ee9dbca571e93fafab7cc34fb3a1dda9e89";a:4:{s:10:"expiration";i:1470491864;s:2:"ip";s:3:"::1";s:2:"ua";s:135:"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/56.3.120 Chrome/50.3.2661.120 Safari/537.36";s:5:"login";i:1470319064;}s:64:"8006e7505825dd7f3ae326c7e27b1c14332181c8481d02ea0a9cbd9f86ad2cd2";a:4:{s:10:"expiration";i:1470583136;s:2:"ip";s:3:"::1";s:2:"ua";s:135:"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/56.3.120 Chrome/50.3.2661.120 Safari/537.36";s:5:"login";i:1470410336;}s:64:"ee50d2f60ed05d827a06c651fe0e8ae5d0f0c9fc0e0f5a55670a3d643e2126c8";a:4:{s:10:"expiration";i:1471626683;s:2:"ip";s:3:"::1";s:2:"ua";s:135:"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/56.3.120 Chrome/50.3.2661.120 Safari/537.36";s:5:"login";i:1470417083;}}'),
(15, 1, 'lrpmqdj9_dashboard_quick_press_last_post_id', '194'),
(16, 1, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:15:"title-attribute";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}'),
(17, 1, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:"add-post_tag";}'),
(18, 1, 'nav_menu_recently_edited', '2'),
(19, 2, 'nickname', 'joey'),
(20, 2, 'first_name', 'Joey'),
(21, 2, 'last_name', 'Nguyen'),
(22, 2, 'description', ''),
(23, 2, 'rich_editing', 'true'),
(24, 2, 'comment_shortcuts', 'false'),
(25, 2, 'admin_color', 'fresh'),
(26, 2, 'use_ssl', '0'),
(27, 2, 'show_admin_bar_front', 'true'),
(28, 2, 'lrpmqdj9_capabilities', 'a:1:{s:6:"author";b:1;}'),
(29, 2, 'lrpmqdj9_user_level', '2'),
(30, 2, 'dismissed_wp_pointers', ''),
(31, 2, 'session_tokens', 'a:2:{s:64:"496fc88c682f20a1cbf9facdf8533a9ef84e06ddf797913e96385e7c19769542";a:4:{s:10:"expiration";i:1471367850;s:2:"ip";s:3:"::1";s:2:"ua";s:135:"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/56.3.120 Chrome/50.3.2661.120 Safari/537.36";s:5:"login";i:1470158250;}s:64:"f60fabb60c25549ad72019ddd935ad7b9c04c13503061796f96879fd15447c7d";a:4:{s:10:"expiration";i:1470331065;s:2:"ip";s:3:"::1";s:2:"ua";s:135:"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/56.3.120 Chrome/50.3.2661.120 Safari/537.36";s:5:"login";i:1470158265;}}'),
(32, 2, 'lrpmqdj9_dashboard_quick_press_last_post_id', '30'),
(33, 1, 'meta-box-order_post', 'a:4:{s:15:"acf_after_title";s:0:"";s:4:"side";s:48:"submitdiv,tagsdiv-post_tag,categorydiv,formatdiv";s:6:"normal";s:103:"acf_22,postexcerpt,trackbacksdiv,postcustom,postimagediv,commentstatusdiv,commentsdiv,slugdiv,authordiv";s:8:"advanced";s:0:"";}'),
(34, 1, 'screen_layout_post', '2'),
(35, 2, 'meta-box-order_post', 'a:4:{s:15:"acf_after_title";s:0:"";s:4:"side";s:48:"submitdiv,tagsdiv-post_tag,formatdiv,categorydiv";s:6:"normal";s:88:"acf_22,acf_34,postexcerpt,trackbacksdiv,postcustom,postimagediv,commentstatusdiv,slugdiv";s:8:"advanced";s:0:"";}'),
(36, 2, 'screen_layout_post', '2'),
(37, 2, 'lrpmqdj9_user-settings', 'libraryContent=browse'),
(38, 2, 'lrpmqdj9_user-settings-time', '1469524702'),
(39, 3, 'nickname', 'david'),
(40, 3, 'first_name', 'David'),
(41, 3, 'last_name', 'Doan'),
(42, 3, 'description', ''),
(43, 3, 'rich_editing', 'true'),
(44, 3, 'comment_shortcuts', 'false'),
(45, 3, 'admin_color', 'fresh'),
(46, 3, 'use_ssl', '0'),
(47, 3, 'show_admin_bar_front', 'true'),
(48, 3, 'lrpmqdj9_capabilities', 'a:1:{s:6:"author";b:1;}'),
(49, 3, 'lrpmqdj9_user_level', '2'),
(50, 3, 'position', ''),
(51, 3, '_position', 'field_5796e48c6a441'),
(52, 3, 'dismissed_wp_pointers', ''),
(53, 3, 'session_tokens', 'a:1:{s:64:"22f7186f731f3c373f64a4728db1e5cf77b4c66ca038414bc15b937ee18c3e06";a:4:{s:10:"expiration";i:1470331033;s:2:"ip";s:3:"::1";s:2:"ua";s:135:"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/56.3.120 Chrome/50.3.2661.120 Safari/537.36";s:5:"login";i:1470158233;}}'),
(54, 3, 'lrpmqdj9_dashboard_quick_press_last_post_id', '46'),
(55, 3, 'meta-box-order_post', 'a:4:{s:15:"acf_after_title";s:0:"";s:4:"side";s:48:"submitdiv,tagsdiv-post_tag,formatdiv,categorydiv";s:6:"normal";s:88:"acf_22,acf_34,postexcerpt,trackbacksdiv,postcustom,commentstatusdiv,slugdiv,postimagediv";s:8:"advanced";s:0:"";}'),
(56, 3, 'screen_layout_post', '2'),
(57, 3, 'lrpmqdj9_user-settings', 'libraryContent=browse'),
(58, 3, 'lrpmqdj9_user-settings-time', '1469525979'),
(59, 1, 'lrpmqdj9_user-settings', 'libraryContent=browse&editor=tinymce&hidetb=1&advImgDetails=show'),
(60, 1, 'lrpmqdj9_user-settings-time', '1470331221'),
(61, 1, 'meta-box-order_member', 'a:4:{s:15:"acf_after_title";s:15:"acf_191,acf_133";s:4:"side";s:22:"postimagediv,submitdiv";s:6:"normal";s:28:"acf_69,acf_34,acf_22,slugdiv";s:8:"advanced";s:0:"";}'),
(62, 1, 'screen_layout_member', '2'),
(63, 1, 'addthis_ignore_notices', 'true'),
(64, 1, 'meta-box-order_page', 'a:4:{s:15:"acf_after_title";s:51:"acf_223,acf_198,postimagediv,acf_191,acf_133,acf_69";s:4:"side";s:23:"submitdiv,pageparentdiv";s:6:"normal";s:120:"acf_218,acf_201,wpb_visual_composer,acf_34,acf_22,postcustom,commentstatusdiv,commentsdiv,slugdiv,authordiv,revisionsdiv";s:8:"advanced";s:9:"at_widget";}'),
(65, 1, 'screen_layout_page', '2'),
(66, 1, 'itsec-settings-view', 'list') ;

#
# End of data contents of table `lrpmqdj9_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `lrpmqdj9_users`
#

DROP TABLE IF EXISTS `lrpmqdj9_users`;


#
# Table structure of table `lrpmqdj9_users`
#

CREATE TABLE `lrpmqdj9_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `lrpmqdj9_users`
#
INSERT INTO `lrpmqdj9_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$B4PyJm./kXYL0zO1WLV48d6yDGOh3h.', 'admin', 'duytan1008@gmail.com', '', '2016-07-17 17:36:10', '1470158193:$P$BshzOeoAj3GEJFQrQtNX1r3DEEKSCy.', 0, 'admin'),
(2, 'joey', '$P$BiNbkc4j/lzY9ON5eoSFM2iKz1NqDx1', 'joey', 'joey@gmail.com', '', '2016-07-26 03:38:30', '1469504311:$P$Bq8VLipdlCFWbh2xQO8rj/gCPnh2lA.', 0, 'Joey Nguyen'),
(3, 'david', '$P$B8Er06QGw0q5Hn/JP9Jf.gzNKdbxsf.', 'david', 'david@gmail.com', '', '2016-07-26 09:20:03', '1469524805:$P$BAvquKnYPbKL99N9GZC/iO.aVwAjcd0', 0, 'David Doan') ;

#
# End of data contents of table `lrpmqdj9_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

